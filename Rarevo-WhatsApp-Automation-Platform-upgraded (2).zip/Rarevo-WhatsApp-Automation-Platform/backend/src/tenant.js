// Multi-business (multi-tenant) context.
//
// A "business" is one of the agency's clients. Every request/job/webhook that
// touches tenant data runs inside runInBusiness(id, fn). db.js reads the id
// from AsyncLocalStorage and, for every query made inside that context, switches
// the Postgres session to the RLS-restricted role `forgechat_tenant` with
// `app.business_id` set — so the database itself guarantees one business can
// never read or write another business's rows (see migration 058).
//
// Code running OUTSIDE a business context is "platform level" (auth, the
// businesses dashboard, webhook routing, schedulers). Keep it to that.

const { AsyncLocalStorage } = require('async_hooks');
const { normalizeBusinessRole, effectiveBusinessActions, ACTIONS } = require('./permissions');

const als = new AsyncLocalStorage();

function getBusinessId() {
  const s = als.getStore();
  return s ? s.businessId : null;
}

function normaliseId(id) {
  const n = Number(id);
  return Number.isInteger(n) && n > 0 ? n : null;
}

/** Run fn with every DB call scoped to `businessId`. */
function runInBusiness(businessId, fn) {
  const id = normaliseId(businessId);
  if (!id) throw new Error(`runInBusiness: invalid business id "${businessId}"`);
  return als.run({ businessId: id }, fn);
}

/** Run fn at platform level even when called from inside a business context. */
function runAsPlatform(fn) {
  return als.exit(fn);
}

/**
 * Run fn once per active business, each inside its own context. Errors in one
 * business never stop the others. Used by schedulers.
 */
async function forEachActiveBusiness(fn, { onlyIfExists } = {}) {
  const pool = require('./db');
  const { rows } = await runAsPlatform(() => pool.query(
    `SELECT id FROM coexistence.businesses
      WHERE deleted_at IS NULL AND status IN ('onboarding','active')
        ${onlyIfExists ? `AND EXISTS (${onlyIfExists})` : ''} ORDER BY id`
  ));
  for (const { id } of rows) {
    try {
      await runInBusiness(id, () => fn(id));
    } catch (err) {
      console.error(`[tenant] job failed for business ${id}:`, err.message);
    }
  }
}

/**
 * Express middleware (after authMiddleware): picks the business the caller is
 * working in from the X-Business-Id header (or ?businessId= for EventSource,
 * which cannot send headers), checks they may access it, then runs the rest of
 * the request inside that business context.
 */
function tenantMiddleware() {
  const pool = require('./db');
  return async (req, res, next) => {
    try {
      const id = normaliseId(req.headers['x-business-id'] || req.query.businessId);
      if (!id) {
        return res.status(400).json({ error: 'No business selected', code: 'BUSINESS_REQUIRED' });
      }
      const { rows } = await runAsPlatform(() => pool.query(
        `SELECT id, name, slug, status FROM coexistence.businesses WHERE id = $1 AND deleted_at IS NULL`, [id]
      ));
      const biz = rows[0];
      if (!biz || biz.status === 'archived') {
        return res.status(404).json({ error: 'Business not found', code: 'BUSINESS_NOT_FOUND' });
      }
      if (req.user?.role !== 'admin') {
        // Looked up on EVERY request (never cached in the token), so removing a member from a
        // business or changing their role/permissions takes effect on their very next call.
        const m = await runAsPlatform(() => pool.query(
          `SELECT role, permissions FROM coexistence.business_members WHERE business_id = $1 AND user_id = $2`,
          [id, req.user?.id]
        ));
        if (m.rows.length === 0) {
          return res.status(403).json({ error: 'You do not have access to this business', code: 'BUSINESS_FORBIDDEN' });
        }
        req.businessRole = normalizeBusinessRole(m.rows[0].role);
        req.businessActions = effectiveBusinessActions(m.rows[0].role, m.rows[0].permissions);
      } else {
        req.businessRole = 'platform_admin';
        req.businessActions = new Set(ACTIONS); // platform admins hold every action in every business
      }
      req.business = biz;
      als.run({ businessId: biz.id }, next);
    } catch (err) {
      console.error('[tenant] middleware error:', err.message);
      res.status(500).json({ error: 'Failed to resolve business' });
    }
  };
}

module.exports = {
  getBusinessId,
  runInBusiness,
  runAsPlatform,
  forEachActiveBusiness,
  tenantMiddleware,
};
