const { Pool } = require('pg');

function buildPool() {
  const connectionString = process.env.DATABASE_URL;
  if (connectionString) {
    return new Pool({
      connectionString,
      ssl: process.env.POSTGRES_SSL === 'true' ? { rejectUnauthorized: false } : false,
      max: 20,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
      application_name: 'forgecrm-backend',
    });
  }

  // Fallback to individual env vars (Docker Compose pattern)
  return new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_NAME || 'postgres',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '',
    ssl: process.env.POSTGRES_SSL === 'true' ? { rejectUnauthorized: false } : false,
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 5000,
    application_name: 'forgecrm-backend',
  });
}

const pool = buildPool();

// ── Multi-business context ────────────────────────────────────────────────
// When a business context is active (tenant.js), every query/connection first
// switches the session to the RLS-restricted role and sets app.business_id, and
// switches back before the connection returns to the pool. Outside a context
// queries run as the normal owner role ("platform level").
const { getBusinessId } = require('./tenant');
const rawConnect = pool.connect.bind(pool);
const rawQuery = pool.query.bind(pool);

async function connectScoped(businessId) {
  const client = await rawConnect();
  try {
    // businessId is validated to be a positive integer by tenant.js.
    await client.query(`SET ROLE forgechat_tenant; SET app.business_id = '${Number(businessId)}'`);
  } catch (err) {
    client.release(true);
    throw err;
  }
  const origRelease = client.release.bind(client);
  let released = false;
  client.release = (destroy) => {
    if (released) return;
    released = true;
    if (destroy) return origRelease(destroy);
    client.query('RESET ROLE; RESET app.business_id').then(
      () => origRelease(),
      () => origRelease(true) // e.g. aborted transaction: drop the connection
    );
  };
  return client;
}

pool.connect = function patchedConnect(cb) {
  const bid = getBusinessId();
  if (!bid || typeof cb === 'function') return rawConnect(cb);
  return connectScoped(bid);
};

pool.query = function patchedQuery(text, values, cb) {
  const bid = getBusinessId();
  if (!bid || typeof values === 'function' || typeof cb === 'function') {
    return rawQuery(text, values, cb);
  }
  return (async () => {
    const client = await connectScoped(bid);
    try {
      return await client.query(text, values);
    } finally {
      client.release();
    }
  })();
};


pool.on('error', (err) => {
  console.error('[DB] Unexpected pool error:', err.message);
});

module.exports = pool;
