// Single place that changes who can open which business, with which role and permission overrides.
//
// Used by the Team page (set a member's businesses) and the business "Team access" dialog (set a
// business's members). Both previously deleted and re-inserted every membership as 'agent', which
// silently reset roles. This service instead diffs against the existing rows, so:
//   * unchanged memberships are left alone (role + overrides preserved),
//   * every add / role change / permission change / removal is written to business_audit_log
//     inside the same transaction as the change itself.
//
// Callers must run it inside BEGIN/COMMIT on a platform-level client (no business context).

const { normalizeBusinessRole, cleanOverrides, DEFAULT_BUSINESS_ROLE } = require('../permissions');

const sameList = (a, b) => JSON.stringify([...a].sort()) === JSON.stringify([...b].sort());

/** Turn one raw request item into { role, grant, revoke }, falling back to the existing row. */
function buildSpec(raw, existing) {
  const existingRole = existing ? normalizeBusinessRole(existing.role) : null;
  const role = raw && raw.role ? normalizeBusinessRole(raw.role) : (existingRole || DEFAULT_BUSINESS_ROLE);
  const overridesGiven = raw && (raw.grant !== undefined || raw.revoke !== undefined);
  let overrides;
  if (overridesGiven) overrides = cleanOverrides(raw);
  else if (existing && role === existingRole) overrides = cleanOverrides(existing.permissions); // keep
  else overrides = { grant: [], revoke: [] };                                                    // role changed → start from the preset
  return { role, ...overrides };
}

/**
 * @param client   pg client inside a transaction (platform context)
 * @param scope    { by: 'user', id }     → desired is a Map<businessId, rawSpec>
 *                 { by: 'business', id } → desired is a Map<userId, rawSpec>
 * @param desired  Map of key → raw spec ({ role?, grant?, revoke? }); a key missing from the map is REMOVED.
 * @returns { added: n, changed: n, removed: n }
 */
async function syncMemberships(client, scope, desired, { actorId }) {
  const byUser = scope.by === 'user';
  const fixedCol = byUser ? 'user_id' : 'business_id';
  const keyCol = byUser ? 'business_id' : 'user_id';

  const { rows: existingRows } = await client.query(
    `SELECT business_id, user_id, role, permissions FROM coexistence.business_members WHERE ${fixedCol} = $1`, [scope.id]);
  const existing = new Map(existingRows.map(r => [Number(r[keyCol]), r]));

  // Only real targets: live businesses for a user; non-admin users for a business.
  const keys = [...desired.keys()];
  let valid = new Set();
  if (keys.length) {
    const { rows } = byUser
      ? await client.query(`SELECT id FROM coexistence.businesses WHERE id = ANY($1::bigint[]) AND deleted_at IS NULL`, [keys])
      : await client.query(`SELECT id FROM coexistence.forgecrm_users WHERE id = ANY($1::bigint[]) AND role <> 'admin'`, [keys]);
    valid = new Set(rows.map(r => Number(r.id)));
  }

  const out = { added: 0, changed: 0, removed: 0 };
  const audit = async (businessId, action, details) => {
    await client.query(
      `INSERT INTO coexistence.business_audit_log (business_id, user_id, action, details) VALUES ($1,$2,$3,$4)`,
      [businessId, actorId || null, action, JSON.stringify(details)]);
  };

  for (const key of keys) {
    if (!valid.has(key)) continue;
    const prev = existing.get(key);
    const spec = buildSpec(desired.get(key), prev);
    const businessId = byUser ? key : scope.id;
    const userId = byUser ? scope.id : key;

    if (!prev) {
      await client.query(
        `INSERT INTO coexistence.business_members (business_id, user_id, role, permissions) VALUES ($1,$2,$3,$4)
         ON CONFLICT (business_id, user_id) DO UPDATE SET role = EXCLUDED.role, permissions = EXCLUDED.permissions`,
        [businessId, userId, spec.role, JSON.stringify({ grant: spec.grant, revoke: spec.revoke })]);
      out.added++;
      await audit(businessId, 'member.added', { userId, role: spec.role, grant: spec.grant, revoke: spec.revoke });
      continue;
    }

    const before = { role: normalizeBusinessRole(prev.role), ...cleanOverrides(prev.permissions) };
    const unchanged = before.role === spec.role && sameList(before.grant, spec.grant) && sameList(before.revoke, spec.revoke)
      && prev.role === spec.role; // legacy 'agent' → 'support_agent' also gets normalised in place
    if (unchanged) continue;
    await client.query(
      `UPDATE coexistence.business_members SET role = $3, permissions = $4 WHERE business_id = $1 AND user_id = $2`,
      [businessId, userId, spec.role, JSON.stringify({ grant: spec.grant, revoke: spec.revoke })]);
    const semantic = !(before.role === spec.role && sameList(before.grant, spec.grant) && sameList(before.revoke, spec.revoke));
    if (semantic) {
      out.changed++;
      await audit(businessId, 'member.access_changed', { userId, from: before, to: { role: spec.role, grant: spec.grant, revoke: spec.revoke } });
    }
  }

  for (const [key, prev] of existing) {
    if (desired.has(key) && valid.has(key)) continue;
    if (desired.has(key) && !valid.has(key)) continue; // invalid target requested → leave the old row untouched
    const businessId = byUser ? key : scope.id;
    const userId = byUser ? scope.id : key;
    await client.query(`DELETE FROM coexistence.business_members WHERE business_id = $1 AND user_id = $2`, [businessId, userId]);
    out.removed++;
    await audit(businessId, 'member.removed', { userId, role: normalizeBusinessRole(prev.role) });
  }
  return out;
}

/** Parse the request body of the Team / Members APIs into a desired Map. Accepts the new shape
 *  (assignments / members: [{ businessId|userId, role, grant, revoke }]) and the legacy `businessIds: [..]`. */
function parseDesired(body, keyName /* 'businessId' | 'userId' */) {
  const map = new Map();
  const add = (k, raw) => { const n = Number(k); if (Number.isInteger(n) && n > 0) map.set(n, raw || {}); };
  const list = body.assignments ?? body.members;
  if (Array.isArray(list)) for (const it of list) add(it?.[keyName], it);
  else if (Array.isArray(body.businessIds)) for (const id of body.businessIds) add(id, {});
  return map;
}

const hasAssignments = (body) => Array.isArray(body?.assignments) || Array.isArray(body?.members) || Array.isArray(body?.businessIds);

module.exports = { syncMemberships, parseDesired, hasAssignments, buildSpec };
