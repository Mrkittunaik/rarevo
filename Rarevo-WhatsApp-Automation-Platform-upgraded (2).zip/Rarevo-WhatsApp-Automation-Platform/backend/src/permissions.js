// Centralised role → page-access map.
//
// Two roles ship today:
//   - admin     : full access (every page + Settings tabs, user management).
//   - bda_sales : "Sales" user — sees only their assigned chats/contacts.
// 'viewer' is kept as a legacy fallback.
//
// Page keys are stable strings used in three places:
//   - this map
//   - the frontend Sidebar / page guard
//   - server-side requirePermission(page) middleware
//
// "admin-settings:<tab>" entries gate individual tabs within Admin Settings.

const PAGES = [
  'home', 'chats', 'records', 'contacts', 'pipelines', 'bulk-message', 'template-builder',
  'chatbot-builder', 'media-library', 'about',
  'admin-settings:general', 'admin-settings:tags', 'admin-settings:category',
  'admin-settings:fields', 'admin-settings:whatsapp-accounts',
  'admin-settings:users', 'admin-settings:mcp',
];

const ROLE_PAGE_DEFAULTS = {
  admin: PAGES.slice(),           // everything
  bda_sales: [
    'home', 'chats', 'records', 'contacts', 'pipelines', 'about',
    'admin-settings:general',     // only the General tab in user settings
  ],
  viewer: ['home', 'about'],      // legacy fallback
};

// Returns the set of pages a user can access given their role plus any
// per-user grant/revoke overrides stored in users.permissions JSONB.
//   permissions = { grant: ["template-builder"], revoke: ["admin-settings:general"] }
function effectivePages(user) {
  const base = ROLE_PAGE_DEFAULTS[user?.role] || [];
  const overrides = user?.permissions || {};
  const grant = Array.isArray(overrides.grant) ? overrides.grant : [];
  const revoke = new Set(Array.isArray(overrides.revoke) ? overrides.revoke : []);
  const out = new Set(base);
  grant.forEach(p => out.add(p));
  revoke.forEach(p => out.delete(p));
  return out;
}

function hasPermission(user, page) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  return effectivePages(user).has(page);
}

function isAdmin(user) {
  return user?.role === 'admin';
}


// ───────────────────────────────────────────────────────────────────────────
// Business-level ACTION permissions
//
// The page map above decides which *screens* a user may open (user-level).
// These decide which *actions* a team member may perform INSIDE one business
// (business-level — a person can be a Supervisor in one business and a Support
// Agent in another). Platform admins implicitly hold every action everywhere.
// Enforced server-side by requireAction()/requireAnyAction() in middleware/access.js.
// ───────────────────────────────────────────────────────────────────────────
const ACTION_GROUPS = [
  { key: 'dashboard', label: 'Dashboard', actions: [
    ['dashboard.view', 'View business dashboard'], ['analytics.view', 'View analytics'] ] },
  { key: 'chats', label: 'Chats', actions: [
    ['chats.view', 'View conversations'], ['chats.reply', 'Reply to customers'],
    ['chats.assign', 'Assign conversations / tags'], ['chats.close', 'Close conversations'] ] },
  { key: 'customers', label: 'Customers', actions: [
    ['customers.view', 'View customers & records'], ['customers.edit', 'Create / edit customers'],
    ['customers.archive', 'Delete or archive customers'], ['customers.export', 'Export customer data'] ] },
  { key: 'automations', label: 'Automations', actions: [
    ['automations.view', 'View automations'], ['automations.edit', 'Create / edit automations'],
    ['automations.toggle', 'Activate / pause automations'] ] },
  { key: 'agents', label: 'AI agents', actions: [
    ['agents.view', 'View agents'], ['agents.edit', 'Create / edit agents'], ['agents.logs', 'View AI execution logs'] ] },
  { key: 'campaigns', label: 'Campaigns', actions: [
    ['campaigns.view', 'View campaigns'], ['campaigns.create', 'Create campaigns'],
    ['campaigns.approve', 'Approve campaigns'], ['campaigns.send', 'Send campaigns'] ] },
  { key: 'reports', label: 'Reports & usage', actions: [
    ['reports.view', 'View reports'], ['reports.export', 'Export reports'], ['usage.view', 'View message usage'] ] },
  { key: 'settings', label: 'Business settings', actions: [
    ['settings.view', 'View settings'], ['settings.edit', 'Edit business settings'],
    ['whatsapp.connect', 'Connect WhatsApp'], ['integrations.manage', 'Manage integrations'],
    ['limits.edit', 'Change usage limits'] ] },
  { key: 'monitoring', label: 'Monitoring', actions: [
    ['errors.view', 'View error logs'], ['errors.resolve', 'Resolve / assign errors'] ] },
];

const ACTIONS = ACTION_GROUPS.flatMap(g => g.actions.map(([key]) => key));
const ACTION_SET = new Set(ACTIONS);

// Role presets. Administrators can customise any member via grant/revoke overrides.
const BUSINESS_ROLE_PRESETS = {
  business_manager: {
    label: 'Business Manager',
    description: 'Runs the business: settings, WhatsApp connection, automations, agents, campaigns, customers and reports. Cannot change usage limits.',
    actions: ACTIONS.filter(a => a !== 'limits.edit'),
  },
  supervisor: {
    label: 'Supervisor',
    description: 'Oversees the team: reports, errors, conversations assignment, read access to automations and agents.',
    actions: ['dashboard.view', 'analytics.view', 'chats.view', 'chats.assign', 'chats.close',
      'customers.view', 'customers.export', 'automations.view', 'agents.view', 'agents.logs',
      'campaigns.view', 'reports.view', 'reports.export', 'usage.view', 'settings.view',
      'errors.view', 'errors.resolve'],
  },
  support_agent: {
    label: 'Support Agent',
    description: 'Handles customer conversations: reply, assign, close, edit customer details and tags.',
    actions: ['dashboard.view', 'chats.view', 'chats.reply', 'chats.assign', 'chats.close',
      'customers.view', 'customers.edit'],
  },
  campaign_manager: {
    label: 'Campaign Manager',
    description: 'Creates and sends campaigns and reviews campaign reports.',
    actions: ['dashboard.view', 'customers.view', 'campaigns.view', 'campaigns.create', 'campaigns.send',
      'reports.view', 'usage.view'],
  },
  analyst: {
    label: 'Analyst',
    description: 'Read-only access to dashboards, customer records and reports.',
    actions: ['dashboard.view', 'analytics.view', 'customers.view', 'automations.view', 'agents.view',
      'campaigns.view', 'reports.view', 'usage.view'],
  },
};

// Roles written before this model existed. They map onto presets (see migration 063).
const LEGACY_ROLE_ALIASES = { manager: 'business_manager', agent: 'support_agent' };
const BUSINESS_ROLES = Object.keys(BUSINESS_ROLE_PRESETS);
const DEFAULT_BUSINESS_ROLE = 'support_agent';

function normalizeBusinessRole(role) {
  const r = LEGACY_ROLE_ALIASES[role] || role;
  return BUSINESS_ROLE_PRESETS[r] ? r : DEFAULT_BUSINESS_ROLE;
}

/** Keep only known action names; returns { grant: string[], revoke: string[] }. */
function cleanOverrides(o) {
  const pick = (arr) => [...new Set((Array.isArray(arr) ? arr : []).filter(a => ACTION_SET.has(a)))];
  const grant = pick(o?.grant);
  const revoke = pick(o?.revoke).filter(a => !grant.includes(a)); // grant wins if both are sent
  return { grant, revoke };
}

/** The set of actions a member holds in one business = preset + grants − revokes. */
function effectiveBusinessActions(role, overrides) {
  const out = new Set(BUSINESS_ROLE_PRESETS[normalizeBusinessRole(role)].actions);
  const { grant, revoke } = cleanOverrides(overrides);
  grant.forEach(a => out.add(a));
  revoke.forEach(a => out.delete(a));
  return out;
}

/** Diff a desired action set against a role preset → the minimal grant/revoke overrides. */
function overridesFromActions(role, desired) {
  const base = new Set(BUSINESS_ROLE_PRESETS[normalizeBusinessRole(role)].actions);
  const want = new Set([...(desired || [])].filter(a => ACTION_SET.has(a)));
  return {
    grant: ACTIONS.filter(a => want.has(a) && !base.has(a)),
    revoke: ACTIONS.filter(a => !want.has(a) && base.has(a)),
  };
}

/** Everything the UI needs to render role pickers and permission checklists. */
function permissionCatalog() {
  return {
    groups: ACTION_GROUPS.map(g => ({ key: g.key, label: g.label, actions: g.actions.map(([key, label]) => ({ key, label })) })),
    roles: BUSINESS_ROLES.map(key => ({ key, ...BUSINESS_ROLE_PRESETS[key] })),
    defaultRole: DEFAULT_BUSINESS_ROLE,
  };
}

/** True when `have` (a Set of actions) satisfies the action (string) or any of the actions (array). */
function holdsAny(have, needed) {
  const list = Array.isArray(needed) ? needed : [needed];
  return list.some(a => have.has(a));
}

module.exports = {
  PAGES,
  ROLE_PAGE_DEFAULTS,
  effectivePages,
  hasPermission,
  isAdmin,
  ACTIONS,
  ACTION_GROUPS,
  BUSINESS_ROLE_PRESETS,
  BUSINESS_ROLES,
  DEFAULT_BUSINESS_ROLE,
  LEGACY_ROLE_ALIASES,
  normalizeBusinessRole,
  cleanOverrides,
  effectiveBusinessActions,
  overridesFromActions,
  permissionCatalog,
  holdsAny,
};
