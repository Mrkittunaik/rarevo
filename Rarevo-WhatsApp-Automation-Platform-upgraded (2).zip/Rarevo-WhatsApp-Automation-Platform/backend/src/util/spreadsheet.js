// Helpers for building spreadsheets safely.

// ── spreadsheet safety ─────────────────────────────────────────────────────
// Customer-controlled text starting with = + - @ (or tab/CR) can run as a formula when the
// file is opened in Excel. Prefix such values with an apostrophe so they stay plain text.
function safeCell(v) {
  if (v == null) return '';
  if (typeof v !== 'string') return v;
  const s = v.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, ''); // strip control chars XML can't hold
  return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
}

// ── timezone: turn a real instant into a Date whose UTC fields are the local wall time,
//    so Excel (which has no timezone) displays the business-local time in a true date cell.
function makeLocalizer(tz) {
  const fmt = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  });
  return (d) => {
    if (!d) return null;
    const dt = d instanceof Date ? d : new Date(d);
    if (Number.isNaN(dt.getTime())) return null;
    const p = Object.fromEntries(fmt.formatToParts(dt).map(x => [x.type, x.value]));
    return new Date(Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second));
  };
}

module.exports = { safeCell, makeLocalizer };
