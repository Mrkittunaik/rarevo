// Timezone helpers shared by every route that hands a zone name to PostgreSQL.
//
// Browsers (especially on Windows) can report legacy IANA names such as
// "Asia/Calcutta". JavaScript's Intl accepts them, but PostgreSQL may not, which
// turns into `time zone "Asia/Calcutta" not recognized` and a 500 error.
// Always pass user-supplied zones through safeTz() before using them in SQL.

const ALIASES = {
  'Asia/Calcutta': 'Asia/Kolkata',
  'Asia/Katmandu': 'Asia/Kathmandu',
  'Asia/Saigon': 'Asia/Ho_Chi_Minh',
  'Asia/Rangoon': 'Asia/Yangon',
  'Asia/Dacca': 'Asia/Dhaka',
  'Asia/Thimbu': 'Asia/Thimphu',
  'Asia/Macao': 'Asia/Macau',
  'Asia/Ujung_Pandang': 'Asia/Makassar',
  'Asia/Ulan_Bator': 'Asia/Ulaanbaatar',
  'Europe/Kiev': 'Europe/Kyiv',
  'America/Buenos_Aires': 'America/Argentina/Buenos_Aires',
  'Pacific/Samoa': 'Pacific/Pago_Pago',
};

const DEFAULT_TZ = 'Asia/Kolkata';

function safeTz(tz, fallback = DEFAULT_TZ) {
  const raw = String(tz || '').trim();
  if (!raw) return fallback;
  const name = ALIASES[raw] || raw;
  try { new Intl.DateTimeFormat('en', { timeZone: name }); return name; } catch { return fallback; }
}

module.exports = { safeTz, DEFAULT_TZ, ALIASES };
