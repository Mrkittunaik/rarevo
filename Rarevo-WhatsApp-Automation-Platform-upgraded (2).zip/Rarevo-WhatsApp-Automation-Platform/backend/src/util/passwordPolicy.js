// Password policy shared by first-run setup, team members, admin-created users and self-service change.
// Deliberately simple and predictable: length + not-a-known-default + not derived from the login email.

const MIN_LENGTH = 8;
const MAX_LENGTH = 128; // bcrypt only uses the first 72 bytes; cap input to avoid abuse

// Passwords that ship in docs/defaults or top every breach list. Compared case-insensitively.
const KNOWN_WEAK = new Set([
  'rarevo@123', 'rarevo123', 'rarevo@1234', 'forgechat', 'forgecrm', 'admin123', 'admin@123', 'admin1234',
  'password', 'password1', 'password123', 'passw0rd', '12345678', '123456789', '1234567890',
  'qwerty123', 'qwertyuiop', 'iloveyou', 'welcome123', 'letmein123', 'changeme', 'changeme123',
]);

/** Returns a human-readable problem string, or null when the password is acceptable. */
function passwordProblem(password, { email = '' } = {}) {
  const p = String(password ?? '');
  if (p.length < MIN_LENGTH) return `Password must be at least ${MIN_LENGTH} characters`;
  if (p.length > MAX_LENGTH) return `Password must be at most ${MAX_LENGTH} characters`;
  if (KNOWN_WEAK.has(p.toLowerCase())) return 'That password is too common or is a known default — choose another';
  const local = String(email).split('@')[0].toLowerCase();
  if (local.length >= 4 && p.toLowerCase().includes(local)) return 'Password must not contain the login email name';
  if (/^(.)\1+$/.test(p)) return 'Password must not be a single repeated character';
  return null;
}

/** True when this exact password is one we ship or document (used to flag accounts that never changed it). */
function isKnownDefaultPassword(password) {
  return KNOWN_WEAK.has(String(password ?? '').toLowerCase());
}

module.exports = { passwordProblem, isKnownDefaultPassword, MIN_LENGTH, MAX_LENGTH };
