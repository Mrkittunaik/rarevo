// What can the signed-in user do in the CURRENT business?  (X-Business-Id selects the business.)
// The UI uses this to hide actions the backend would refuse anyway. It is a convenience only —
// every action is still enforced server-side by requireAction().
const { Router } = require('express');
const { isAdmin, ACTIONS } = require('../permissions');

const router = Router();

router.get('/me/permissions', (req, res) => {
  const admin = isAdmin(req.user);
  res.json({
    businessId: req.business?.id ? Number(req.business.id) : null,
    role: admin ? 'platform_admin' : req.businessRole,
    actions: admin ? ACTIONS : [...(req.businessActions || [])],
  });
});

module.exports = { router };
