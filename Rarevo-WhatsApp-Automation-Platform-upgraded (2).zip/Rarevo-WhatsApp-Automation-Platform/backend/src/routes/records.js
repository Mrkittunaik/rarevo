// Conversation records — every customer who has messaged (or been messaged), with
// name, number, first/last time and counts, filterable by Today / Yesterday / 7d / 30d / All.
// Runs inside the business context (RLS) like Chats/Contacts.
//
//   GET /records?range=today|yesterday|7d|30d|all &q= &page= &pageSize= &tz=Asia/Kolkata

const { Router } = require('express');
const pool = require('../db');
const { requirePermission, requireAction, buildWaScope } = require('../middleware/access');

const router = Router();

const { safeTz } = require('../util/timezone');
const validTz = (tz) => safeTz(tz);

// Start of "today" in the viewer's timezone, as timestamptz.
const TODAY = `(date_trunc('day', NOW() AT TIME ZONE $1) AT TIME ZONE $1)`;
const RANGES = {
  today:     `a.last_at >= ${TODAY}`,
  yesterday: `a.last_at >= ${TODAY} - INTERVAL '1 day' AND a.last_at < ${TODAY}`,
  '7d':      `a.last_at >= ${TODAY} - INTERVAL '6 days'`,
  '30d':     `a.last_at >= ${TODAY} - INTERVAL '29 days'`,
  all:       'TRUE',
};

const AGG = `
  SELECT h.wa_number, h.contact_number, MIN(h.timestamp) AS first_at, MAX(h.timestamp) AS last_at,
         COUNT(*)::int AS msgs,
         COUNT(*) FILTER (WHERE h.direction='incoming')::int AS inbound,
         COUNT(*) FILTER (WHERE h.direction='outgoing')::int AS outbound
    FROM coexistence.chat_history h GROUP BY h.wa_number, h.contact_number`;

router.get('/records', requireAction('customers.view'), requirePermission('records'), async (req, res) => {
  try {
    const tz = validTz(String(req.query.tz || 'Asia/Kolkata'));
    const range = RANGES[req.query.range] ? req.query.range : 'today';
    const pageSize = Math.min(500, Math.max(1, parseInt(req.query.pageSize, 10) || 50));
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const q = String(req.query.q || '').trim();

    const params = [tz];
    let search = '';
    if (q) {
      params.push(`%${q.replace(/[%_\\]/g, m => '\\' + m)}%`);
      search = ` AND (a.contact_number ILIKE $${params.length} OR c.name ILIKE $${params.length} OR c.profile_name ILIKE $${params.length})`;
    }
    // Non-admin team members only see customers on their assigned WhatsApp numbers / contacts.
    const scope = await buildWaScope(req, 'a', params.length + 1);
    if (scope.sql) { search += ` AND ${scope.sql}`; params.push(...scope.params); }
    const scopeC = await buildWaScope(req, 'a', 2);
    const base = `FROM (${AGG}) a
      LEFT JOIN coexistence.contacts c ON c.wa_number = a.wa_number AND c.contact_number = a.contact_number`;

    const [counts, total, list] = await Promise.all([
      pool.query(`SELECT
          COUNT(*) FILTER (WHERE ${RANGES.today})::int AS today,
          COUNT(*) FILTER (WHERE ${RANGES.yesterday})::int AS yesterday,
          COUNT(*) FILTER (WHERE ${RANGES['7d']})::int AS d7,
          COUNT(*) FILTER (WHERE ${RANGES['30d']})::int AS d30,
          COUNT(*)::int AS "all",
          COUNT(*) FILTER (WHERE a.first_at >= ${TODAY})::int AS new_today,
          COUNT(*) FILTER (WHERE a.first_at >= ${TODAY} - INTERVAL '1 day' AND a.first_at < ${TODAY})::int AS new_yesterday
        FROM (${AGG}) a${scopeC.sql ? ` WHERE ${scopeC.sql}` : ''}`, [tz, ...scopeC.params]),
      pool.query(`SELECT COUNT(*)::int AS n ${base} WHERE ${RANGES[range]}${search}`, params),
      pool.query(
        `SELECT a.*, COALESCE(NULLIF(c.name,''), c.profile_name) AS name, lm.message_body, lm.message_type, lm.direction AS last_direction
           ${base}
           LEFT JOIN LATERAL (
             SELECT message_body, message_type, direction FROM coexistence.chat_history h
              WHERE h.wa_number = a.wa_number AND h.contact_number = a.contact_number
              ORDER BY h.timestamp DESC LIMIT 1) lm ON TRUE
          WHERE ${RANGES[range]}${search}
          ORDER BY a.last_at DESC
          LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`, params),
    ]);

    const c = counts.rows[0];
    res.json({
      counts: { today: c.today, yesterday: c.yesterday, '7d': c.d7, '30d': c.d30, all: c.all, newToday: c.new_today, newYesterday: c.new_yesterday },
      total: total.rows[0].n, page, pageSize,
      items: list.rows.map(r => ({
        waNumber: r.wa_number, contactNumber: r.contact_number, name: r.name || null,
        firstAt: r.first_at, lastAt: r.last_at, messages: r.msgs, inbound: r.inbound, outbound: r.outbound,
        lastMessage: r.message_body || (r.message_type && r.message_type !== 'text' ? `[${r.message_type}]` : ''),
        lastDirection: r.last_direction,
      })),
    });
  } catch (err) {
    console.error('[records] error:', err.message);
    res.status(500).json({ error: 'Failed to load records' });
  }
});

module.exports = { router };
