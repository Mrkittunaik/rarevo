// Admin dashboard → Team. The admin creates a member's email + password and picks
// which businesses that member may open. Members see/open ONLY those businesses
// (enforced by business_members checks in tenant.js and routes/businesses.js).
//
//   GET    /permissions/catalog   action list, role presets (any signed-in user)
//   GET    /team          members + their per-business assignments
//   POST   /team          { name, email, password, assignments: [{ businessId, role, grant?, revoke? }] }
//                         (legacy { businessIds: [] } still accepted)
//   PUT    /team/:id      { name?, email?, password?, isActive?, assignments? | businessIds? }
//   DELETE /team/:id
//
// Roles are per business (Business Manager, Supervisor, Support Agent, Campaign Manager, Analyst), with
// optional grant/revoke overrides per member. Every change is audited; password changes and
// deactivation sign the member out everywhere immediately (token_version).

const { Router } = require('express');
const bcrypt = require('bcryptjs');
const pool = require('../db');
const { adminOnly, auditLog } = require('../middleware/access');
const { authMiddleware } = require('../auth');
const { permissionCatalog, normalizeBusinessRole, cleanOverrides } = require('../permissions');
const { passwordProblem } = require('../util/passwordPolicy');
const { syncMemberships, parseDesired, hasAssignments } = require('../services/memberAccess');

const router = Router();
const MEMBER_ROLE = 'bda_sales'; // regular (non-admin) team member

const bad = (msg) => { const e = new Error(msg); e.expose = true; return e; };

function validateCreds({ email, password }, { requirePassword }) {
  if (email !== undefined && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim())) throw bad('Enter a valid email');
  if (requirePassword && !password) throw bad('Password is required');
  if (password !== undefined && password !== '') {
    const problem = passwordProblem(password, { email });
    if (problem) throw bad(problem);
  }
}

async function loadMembers(where = '', params = []) {
  const { rows } = await pool.query(
    `SELECT u.id, u.email, u.display_name, u.is_active, u.last_login_at, u.created_at, u.must_change_password,
            COALESCE((SELECT json_agg(json_build_object('businessId', m.business_id, 'role', m.role, 'permissions', m.permissions)
                                      ORDER BY m.business_id)
                        FROM coexistence.business_members m WHERE m.user_id = u.id), '[]') AS assignments
       FROM coexistence.forgecrm_users u WHERE u.role <> 'admin' ${where} ORDER BY u.created_at DESC`, params);
  return rows.map(r => {
    const assignments = (r.assignments || []).map(a => ({
      businessId: Number(a.businessId), role: normalizeBusinessRole(a.role), ...cleanOverrides(a.permissions),
    }));
    return {
      id: Number(r.id), email: r.email, name: r.display_name, isActive: r.is_active,
      lastLoginAt: r.last_login_at, createdAt: r.created_at, mustChangePassword: !!r.must_change_password,
      assignments, businessIds: assignments.map(a => a.businessId),
    };
  });
}

router.get('/permissions/catalog', authMiddleware, (req, res) => res.json(permissionCatalog()));

router.get('/team', adminOnly, async (req, res) => {
  try { res.json(await loadMembers()); }
  catch (err) { console.error('[team] list:', err.message); res.status(500).json({ error: 'Failed to load team' }); }
});

router.post('/team', adminOnly, async (req, res) => {
  const client = await pool.connect();
  try {
    const { name, email, password } = req.body || {};
    if (!String(name || '').trim()) throw bad('Name is required');
    validateCreds({ email, password }, { requirePassword: true });
    const mail = String(email).trim().toLowerCase();
    const hash = await bcrypt.hash(String(password), 10);
    await client.query('BEGIN');
    // must_change_password: the admin chose this password, so the member is nudged to pick their own.
    const { rows } = await client.query(
      `INSERT INTO coexistence.forgecrm_users (username, email, password, display_name, role, created_by, must_change_password)
       VALUES ($1,$1,$2,$3,$4,$5,TRUE) RETURNING id`, [mail, hash, String(name).trim(), MEMBER_ROLE, req.user.id]);
    const sync = await syncMemberships(client, { by: 'user', id: rows[0].id }, parseDesired(req.body || {}, 'businessId'), { actorId: req.user.id });
    await client.query('COMMIT');
    await auditLog({ actor: req.user, action: 'team.create', targetType: 'user', targetId: rows[0].id,
      payload: { email: mail, assignments: sync.added } });
    res.status(201).json((await loadMembers('AND u.id = $1', [rows[0].id]))[0]);
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    if (err.code === '23505') return res.status(409).json({ error: 'That email is already in use' });
    if (err.expose) return res.status(400).json({ error: err.message });
    console.error('[team] create:', err.message);
    res.status(500).json({ error: 'Failed to create team member' });
  } finally { client.release(); }
});

router.put('/team/:id', adminOnly, async (req, res) => {
  const client = await pool.connect();
  try {
    const id = Number(req.params.id);
    const { rows: ex } = await client.query(`SELECT role FROM coexistence.forgecrm_users WHERE id = $1`, [id]);
    if (!ex[0]) return res.status(404).json({ error: 'Member not found' });
    if (ex[0].role === 'admin') return res.status(400).json({ error: 'Admins are not managed here' });
    const b = req.body || {};
    validateCreds({ email: b.email, password: b.password }, { requirePassword: false });
    const sets = []; const params = [];
    const set = (frag, v) => { params.push(v); sets.push(frag.replace('$$', `$${params.length}`)); };
    if (b.name !== undefined) { if (!String(b.name).trim()) throw bad('Name is required'); set('display_name = $$', String(b.name).trim()); }
    if (b.email !== undefined) { const m = String(b.email).trim().toLowerCase(); set('email = $$', m); set('username = $$', m); }
    if (b.password) {
      set('password = $$', await bcrypt.hash(String(b.password), 10));
      sets.push('password_changed_at = NOW()', 'must_change_password = TRUE');
      sets.push('token_version = token_version + 1');           // signs the member out everywhere
    }
    if (b.isActive !== undefined) {
      set('is_active = $$', !!b.isActive);
      if (!b.isActive) sets.push('token_version = token_version + 1'); // disabled → existing sessions die at once
    }
    // The same column may not be assigned twice in one UPDATE.
    const seenCols = new Set(); const dedup = sets.filter(f => { const c = f.split('=')[0].trim(); if (seenCols.has(c)) return false; seenCols.add(c); return true; });
    await client.query('BEGIN');
    if (dedup.length) {
      params.push(id);
      await client.query(`UPDATE coexistence.forgecrm_users SET ${dedup.join(', ')}, updated_at = NOW() WHERE id = $${params.length}`, params);
    }
    let sync = null;
    if (hasAssignments(b)) sync = await syncMemberships(client, { by: 'user', id }, parseDesired(b, 'businessId'), { actorId: req.user.id });
    await client.query('COMMIT');
    await auditLog({ actor: req.user, action: 'team.update', targetType: 'user', targetId: id,
      payload: { fields: Object.keys(b).filter(k => k !== 'password'), passwordChanged: !!b.password,
        access: sync ? { added: sync.added, changed: sync.changed, removed: sync.removed } : undefined } });
    res.json((await loadMembers('AND u.id = $1', [id]))[0]);
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    if (err.code === '23505') return res.status(409).json({ error: 'That email is already in use' });
    if (err.expose) return res.status(400).json({ error: err.message });
    console.error('[team] update:', err.message);
    res.status(500).json({ error: 'Failed to update team member' });
  } finally { client.release(); }
});

router.delete('/team/:id', adminOnly, async (req, res) => {
  try {
    const { rowCount } = await pool.query(
      `DELETE FROM coexistence.forgecrm_users WHERE id = $1 AND role <> 'admin'`, [Number(req.params.id)]);
    if (!rowCount) return res.status(404).json({ error: 'Member not found' });
    await auditLog({ actor: req.user, action: 'team.delete', targetType: 'user', targetId: req.params.id, payload: {} });
    res.json({ ok: true });
  } catch (err) { console.error('[team] delete:', err.message); res.status(500).json({ error: 'Failed to delete member' }); }
});

module.exports = { router };
