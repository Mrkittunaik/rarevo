// External CRM connection — READ-ONLY.
//
// Rarevo does not ship its own CRM screen any more. Instead each business can be
// connected to the Rarevo CRM (or any external CRM) with generated credentials:
//
//   adminRouter (under authMiddleware, platform level)
//     GET    /businesses/:id/crm-connection          status + credentials
//     POST   /businesses/:id/crm-connection          connect (generate) / regenerate
//     DELETE /businesses/:id/crm-connection          disconnect (credentials deleted)
//
//   apiRouter (mounted on /api/crm/v1, own header auth, GET only)
//     Authorization: Bearer <API key>      X-Api-Password: <API password>
//     GET /ping, /summary, /contacts, /contacts/:number, /contacts/:number/messages

const { Router } = require('express');
const crypto = require('crypto');
const pool = require('../db');
const { encrypt, decrypt, hashApiKey } = require('../util/crypto');
const { runInBusiness } = require('../tenant');

const adminRouter = Router();
const apiRouter = Router();

/* ------------------------------ helpers -------------------------------- */

function baseUrl(req) {
  const b = process.env.PUBLIC_BASE_URL
    || `${(req.headers['x-forwarded-proto'] || req.protocol || 'https').toString().split(',')[0]}://${req.headers['x-forwarded-host'] || req.get('host')}`;
  return String(b).replace(/\/+$/, '');
}

function generateCredentials() {
  const key = 'rvk_live_' + crypto.randomBytes(24).toString('base64url');
  const secret = crypto.randomBytes(18).toString('base64url');
  return { key, secret };
}

async function loadBusiness(req, res, { needManager = false } = {}) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: 'Invalid business id' }); return null; }
  const { rows } = await pool.query('SELECT * FROM coexistence.businesses WHERE id=$1 AND deleted_at IS NULL', [id]);
  if (!rows[0]) { res.status(404).json({ error: 'Business not found' }); return null; }
  let role = null;
  if (req.user?.role === 'admin') role = 'business_manager';
  else {
    const m = await pool.query('SELECT role FROM coexistence.business_members WHERE business_id=$1 AND user_id=$2', [id, req.user?.id]);
    role = m.rows[0] ? require('../permissions').normalizeBusinessRole(m.rows[0].role) : null;
  }
  if (!role || (needManager && role !== 'business_manager')) {
    res.status(403).json({ error: 'You do not have access to this business' }); return null;
  }
  return rows[0];
}

async function audit(businessId, userId, action) {
  try {
    await pool.query(
      `INSERT INTO coexistence.business_audit_log (business_id, user_id, action, details) VALUES ($1,$2,$3,'{}')`,
      [businessId, userId || null, action]);
  } catch (e) { console.error('[crm] audit failed:', e.message); }
}

function shape(req, row) {
  if (!row) return { connected: false };
  return {
    connected: row.is_active,
    apiUrl: `${baseUrl(req)}/api/crm/v1`,
    apiKey: decrypt(row.key_encrypted),
    apiPassword: decrypt(row.secret_encrypted),
    keyPrefix: row.key_prefix, keyLast4: row.key_last4,
    connectedAt: row.connected_at, rotatedAt: row.rotated_at,
    lastUsedAt: row.last_used_at, requestCount: Number(row.request_count || 0),
  };
}

/* ------------------------------ admin side ------------------------------ */

adminRouter.get('/businesses/:id/crm-connection', async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const { rows } = await pool.query('SELECT * FROM coexistence.crm_connections WHERE business_id=$1', [b.id]);
    res.json(shape(req, rows[0]));
  } catch (err) {
    console.error('[crm] get error:', err.message);
    res.status(500).json({ error: 'Failed to load CRM connection' });
  }
});

// Connect (first time) or regenerate (rotate) the credentials.
adminRouter.post('/businesses/:id/crm-connection', async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const { key, secret } = generateCredentials();
    const { rows: prev } = await pool.query('SELECT 1 FROM coexistence.crm_connections WHERE business_id=$1', [b.id]);
    const { rows } = await pool.query(
      `INSERT INTO coexistence.crm_connections
         (business_id, key_prefix, key_last4, key_hash, key_encrypted, secret_hash, secret_encrypted, connected_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (business_id) DO UPDATE SET
         key_prefix=EXCLUDED.key_prefix, key_last4=EXCLUDED.key_last4, key_hash=EXCLUDED.key_hash,
         key_encrypted=EXCLUDED.key_encrypted, secret_hash=EXCLUDED.secret_hash,
         secret_encrypted=EXCLUDED.secret_encrypted, is_active=TRUE, rotated_at=NOW()
       RETURNING *`,
      [b.id, key.slice(0, 13), key.slice(-4), hashApiKey(key), encrypt(key), hashApiKey(secret), encrypt(secret), req.user?.id || null]);
    await pool.query('UPDATE coexistence.businesses SET crm_connected=TRUE, updated_at=NOW() WHERE id=$1', [b.id]);
    await audit(b.id, req.user?.id, prev.length ? 'crm.credentials_regenerated' : 'crm.connected');
    res.status(201).json(shape(req, rows[0]));
  } catch (err) {
    console.error('[crm] connect error:', err.message);
    res.status(500).json({ error: 'Failed to connect CRM' });
  }
});

adminRouter.delete('/businesses/:id/crm-connection', async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    await pool.query('DELETE FROM coexistence.crm_connections WHERE business_id=$1', [b.id]);
    await pool.query('UPDATE coexistence.businesses SET crm_connected=FALSE, updated_at=NOW() WHERE id=$1', [b.id]);
    await audit(b.id, req.user?.id, 'crm.disconnected');
    res.json({ connected: false });
  } catch (err) {
    console.error('[crm] disconnect error:', err.message);
    res.status(500).json({ error: 'Failed to disconnect CRM' });
  }
});

/* ------------------------------ read-only API --------------------------- */

function safeEqual(a, b) {
  const x = Buffer.from(String(a)); const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

async function crmAuth(req, res, next) {
  try {
    if (req.method !== 'GET') return res.status(405).json({ error: 'This API is read-only' });
    const m = (req.headers.authorization || '').match(/^Bearer\s+(.+)$/i);
    const password = req.headers['x-api-password'];
    if (!m || !password) return res.status(401).json({ error: 'Send Authorization: Bearer <API key> and X-Api-Password headers' });
    const { rows } = await pool.query(
      `SELECT c.*, b.status FROM coexistence.crm_connections c
         JOIN coexistence.businesses b ON b.id = c.business_id AND b.deleted_at IS NULL
        WHERE c.key_hash = $1 AND c.is_active`, [hashApiKey(m[1].trim())]);
    const row = rows[0];
    if (!row || !safeEqual(row.secret_hash, hashApiKey(String(password)))) {
      return res.status(401).json({ error: 'Invalid API key or password' });
    }
    pool.query('UPDATE coexistence.crm_connections SET last_used_at=NOW(), request_count=request_count+1 WHERE business_id=$1',
      [row.business_id]).catch(() => {});
    req.crmBusinessId = Number(row.business_id);
    // Everything below is confined to this one business by Postgres RLS.
    runInBusiness(row.business_id, next);
  } catch (err) {
    console.error('[crm] auth error:', err.message);
    res.status(500).json({ error: 'Authentication failed' });
  }
}

apiRouter.use(crmAuth);

const digits = (s) => String(s || '').replace(/\D/g, '');

function leadShape(c) {
  return {
    id: Number(c.id),
    name: c.name || c.profile_name || null,
    number: c.contact_number,
    whatsappNumber: c.wa_number,
    tags: Array.isArray(c.tags) ? c.tags : [],
    lastMessage: c.last_message ?? undefined,
    lastMessageAt: c.last_message_at ?? undefined,
    messageCount: c.message_count ?? undefined,
    createdAt: c.created_at, updatedAt: c.updated_at,
  };
}

const LEAD_SELECT = `
  SELECT c.id, c.wa_number, c.contact_number, c.name, c.profile_name, c.tags, c.created_at, c.updated_at,
         (SELECT h.message_body FROM coexistence.chat_history h WHERE h.contact_number=c.contact_number AND h.wa_number=c.wa_number ORDER BY h.timestamp DESC LIMIT 1) AS last_message,
         (SELECT MAX(h.timestamp) FROM coexistence.chat_history h WHERE h.contact_number=c.contact_number AND h.wa_number=c.wa_number) AS last_message_at,
         (SELECT COUNT(*)::int FROM coexistence.chat_history h WHERE h.contact_number=c.contact_number AND h.wa_number=c.wa_number) AS message_count
    FROM coexistence.contacts c`;

apiRouter.get('/ping', async (req, res) => {
  const { rows } = await pool.query('SELECT id, name FROM coexistence.businesses WHERE id=$1', [req.crmBusinessId]);
  res.json({ ok: true, business: { id: Number(rows[0].id), name: rows[0].name }, readOnly: true });
});

apiRouter.get('/summary', async (req, res) => {
  try {
    const { rows } = await pool.query(`SELECT
        (SELECT COUNT(*)::int FROM coexistence.contacts) AS leads,
        (SELECT COUNT(*)::int FROM coexistence.contacts WHERE created_at > NOW() - INTERVAL '7 days') AS new_7d,
        (SELECT COUNT(*)::int FROM coexistence.chat_history) AS messages`);
    res.json({ leads: rows[0].leads, newLeads7d: rows[0].new_7d, messages: rows[0].messages });
  } catch (err) { console.error('[crm] summary:', err.message); res.status(500).json({ error: 'Failed to load summary' }); }
});

// Paged list. ?limit=1..500 &after=<id cursor> &q=<name or number> &updatedSince=<ISO date>
apiRouter.get('/contacts', async (req, res) => {
  try {
    const limit = Math.min(500, Math.max(1, parseInt(req.query.limit, 10) || 100));
    const after = parseInt(req.query.after, 10) || 0;
    const where = ['c.id > $1']; const params = [after];
    const q = String(req.query.q || '').trim();
    if (q) {
      params.push(`%${q.replace(/[%_\\]/g, m => '\\' + m)}%`);
      where.push(`(c.name ILIKE $${params.length} OR c.profile_name ILIKE $${params.length} OR c.contact_number ILIKE $${params.length})`);
    }
    if (req.query.updatedSince) {
      const d = new Date(req.query.updatedSince);
      if (Number.isNaN(d.getTime())) return res.status(400).json({ error: 'updatedSince must be an ISO date' });
      params.push(d.toISOString()); where.push(`c.updated_at >= $${params.length}`);
    }
    params.push(limit);
    const { rows } = await pool.query(
      `${LEAD_SELECT} WHERE ${where.join(' AND ')} ORDER BY c.id ASC LIMIT $${params.length}`, params);
    const total = (await pool.query('SELECT COUNT(*)::int AS n FROM coexistence.contacts')).rows[0].n;
    res.json({ items: rows.map(leadShape), total, nextAfter: rows.length === limit ? Number(rows[rows.length - 1].id) : null });
  } catch (err) { console.error('[crm] contacts:', err.message); res.status(500).json({ error: 'Failed to load contacts' }); }
});

apiRouter.get('/contacts/:number', async (req, res) => {
  try {
    const n = digits(req.params.number);
    if (!n) return res.status(400).json({ error: 'Invalid number' });
    const { rows } = await pool.query(`${LEAD_SELECT} WHERE c.contact_number = $1 ORDER BY c.id LIMIT 1`, [n]);
    if (!rows[0]) return res.status(404).json({ error: 'Lead not found' });
    res.json(leadShape(rows[0]));
  } catch (err) { console.error('[crm] contact:', err.message); res.status(500).json({ error: 'Failed to load lead' }); }
});

apiRouter.get('/contacts/:number/messages', async (req, res) => {
  try {
    const n = digits(req.params.number);
    if (!n) return res.status(400).json({ error: 'Invalid number' });
    const limit = Math.min(200, Math.max(1, parseInt(req.query.limit, 10) || 50));
    const { rows } = await pool.query(
      `SELECT direction, message_body, timestamp FROM coexistence.chat_history
        WHERE contact_number=$1 ORDER BY timestamp DESC LIMIT $2`, [n, limit]);
    res.json({ items: rows.reverse().map(r => ({ direction: r.direction, text: r.message_body, at: r.timestamp })) });
  } catch (err) { console.error('[crm] messages:', err.message); res.status(500).json({ error: 'Failed to load messages' }); }
});

module.exports = { adminRouter, apiRouter };
