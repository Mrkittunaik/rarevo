// Customer-records export (real .xlsx via ExcelJS streaming, or CSV).
//
//   GET /records/export
//       ?format=xlsx|csv
//       &range=today|yesterday|7d|30d|all|custom     (default: all)
//       &from=YYYY-MM-DD&to=YYYY-MM-DD               (when range=custom, inclusive, business-local days)
//       &q=<name or number>  &tag=<tag id>  &assignedUserId=<id>
//       &tz=Asia/Kolkata
//
// Runs inside the business context (mounted after tenantMiddleware), so Postgres RLS
// guarantees only the selected business's rows are read. Non-admin team members are
// further scoped to their assigned WhatsApp numbers / contacts (same rule as Chats).
// The workbook is streamed to the response — it is never held in memory as a whole —
// and every export is written to business_audit_log.

const { Router } = require('express');
const ExcelJS = require('exceljs');
const pool = require('../db');
const { runAsPlatform } = require('../tenant');
const { requirePermission, requireAction, buildWaScope } = require('../middleware/access');
const { safeTz } = require('../util/timezone');
const { safeCell, makeLocalizer } = require('../util/spreadsheet');

const router = Router();

const MAX_ROWS = 250000;          // hard safety cap per export
const ENRICH_BATCH = 2000;        // rows enriched / written per step
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

// Same aggregation the Records page uses (one row per customer conversation pair).
const AGG = `
  SELECT h.wa_number, h.contact_number, MIN(h.timestamp) AS first_at, MAX(h.timestamp) AS last_at,
         COUNT(*)::int AS msgs,
         COUNT(*) FILTER (WHERE h.direction='incoming')::int AS inbound,
         COUNT(*) FILTER (WHERE h.direction='outgoing')::int AS outbound
    FROM coexistence.chat_history h GROUP BY h.wa_number, h.contact_number`;

// ── range → [lo, hi) timestamptz bounds, evaluated by Postgres in the business-local zone ──
async function resolveRange(range, tz, from, to) {
  const TODAY = `(date_trunc('day', NOW() AT TIME ZONE $1) AT TIME ZONE $1)`;
  let sql, params = [tz];
  switch (range) {
    case 'today':     sql = `SELECT ${TODAY} AS lo, NULL::timestamptz AS hi`; break;
    case 'yesterday': sql = `SELECT ${TODAY} - INTERVAL '1 day' AS lo, ${TODAY} AS hi`; break;
    case '7d':        sql = `SELECT ${TODAY} - INTERVAL '6 days' AS lo, NULL::timestamptz AS hi`; break;
    case '30d':       sql = `SELECT ${TODAY} - INTERVAL '29 days' AS lo, NULL::timestamptz AS hi`; break;
    case 'custom':
      sql = `SELECT ($2::date)::timestamp AT TIME ZONE $1 AS lo, (($3::date + 1)::timestamp) AT TIME ZONE $1 AS hi`;
      params = [tz, from, to]; break;
    default:          return { lo: null, hi: null, label: 'All time' };
  }
  const { rows } = await pool.query(sql, params);
  const label = range === 'custom' ? `${from} to ${to}` : ({ today: 'Today', yesterday: 'Yesterday', '7d': 'Last 7 days', '30d': 'Last 30 days' })[range];
  return { lo: rows[0].lo, hi: rows[0].hi, label };
}

function tagNameOf(t, tagMap) {
  if (t == null) return '';
  if (typeof t === 'string') return tagMap.get(t) || t;
  if (typeof t === 'object') return t.name || tagMap.get(t.id) || t.id || '';
  return String(t);
}

function csvCell(v) {
  const s = String(safeCell(v) ?? '');
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

router.get('/records/export', requireAction('customers.export'), requirePermission('records'), async (req, res) => {
  const startedAt = Date.now();
  let headersSent = false;
  try {
    const format = req.query.format === 'csv' ? 'csv' : 'xlsx';
    const range = ['today', 'yesterday', '7d', '30d', 'all', 'custom'].includes(req.query.range) ? req.query.range : 'all';
    const tz = safeTz(req.query.tz);
    const q = String(req.query.q || '').trim().slice(0, 100);
    const tag = String(req.query.tag || '').trim().slice(0, 100);
    const assignedUserId = req.query.assignedUserId ? parseInt(req.query.assignedUserId, 10) : null;
    const from = String(req.query.from || ''), to = String(req.query.to || '');
    if (range === 'custom') {
      if (!DATE_RE.test(from) || !DATE_RE.test(to)) return res.status(400).json({ error: 'Custom range needs from and to as YYYY-MM-DD' });
      if (from > to) return res.status(400).json({ error: '"from" must not be after "to"' });
    }
    if (req.query.assignedUserId && !Number.isInteger(assignedUserId)) return res.status(400).json({ error: 'Invalid assignedUserId' });

    const { lo, hi, label: rangeLabel } = await resolveRange(range, tz, from, to);
    const toLocal = makeLocalizer(tz);

    // ── filters (all parameterised) ──
    const params = [lo, hi];
    const where = [`($1::timestamptz IS NULL OR a.last_at >= $1::timestamptz)`, `($2::timestamptz IS NULL OR a.last_at < $2::timestamptz)`];
    if (q) {
      params.push(`%${q.replace(/[%_\\]/g, m => '\\' + m)}%`);
      const i = params.length;
      where.push(`(a.contact_number ILIKE $${i} OR c.name ILIKE $${i} OR c.profile_name ILIKE $${i})`);
    }
    if (tag) {
      params.push(JSON.stringify([tag])); const i1 = params.length;
      params.push(JSON.stringify([{ id: tag }])); const i2 = params.length;
      where.push(`(c.tags @> $${i1}::jsonb OR c.tags @> $${i2}::jsonb)`);
    }
    if (assignedUserId) { params.push(assignedUserId); where.push(`c.assigned_user_id = $${params.length}`); }
    const scope = await buildWaScope(req, 'a', params.length + 1);
    if (scope.sql) { where.push(scope.sql); params.push(...scope.params); }

    // One aggregation pass; no per-row subqueries yet (those are done per batch below).
    const { rows: base } = await pool.query(
      `SELECT a.wa_number, a.contact_number, a.first_at, a.last_at, a.msgs, a.inbound, a.outbound,
              c.id AS contact_id, c.name, c.profile_name, c.tags, c.created_at AS c_created, c.updated_at AS c_updated,
              u.display_name AS assigned_name
         FROM (${AGG}) a
         LEFT JOIN coexistence.contacts c ON c.wa_number = a.wa_number AND c.contact_number = a.contact_number
         LEFT JOIN coexistence.forgecrm_users u ON u.id = c.assigned_user_id
        WHERE ${where.join(' AND ')}
        ORDER BY a.last_at DESC, a.wa_number, a.contact_number
        LIMIT ${MAX_ROWS + 1}`, params);
    if (base.length > MAX_ROWS) {
      return res.status(413).json({ error: `Export is larger than ${MAX_ROWS.toLocaleString()} customers. Narrow the date range or add a filter.` });
    }

    const tagRows = await pool.query(`SELECT id, name FROM coexistence.tags`).then(r => r.rows).catch(() => []);
    const tagMap = new Map(tagRows.map(t => [t.id, t.name]));
    const biz = (await runAsPlatform(() => pool.query(
      `SELECT id, name, slug FROM coexistence.businesses WHERE id = $1`, [req.business.id]))).rows[0] || req.business;

    // Enrich a batch with last message + latest deal stage (indexed lookups, 2,000 keys at a time).
    async function enrich(batch) {
      const was = batch.map(r => r.wa_number), cns = batch.map(r => r.contact_number);
      const { rows } = await pool.query(
        `SELECT k.wa, k.cn, lm.message_body, lm.message_type, dl.stage_name
           FROM unnest($1::text[], $2::text[]) AS k(wa, cn)
           LEFT JOIN LATERAL (SELECT message_body, message_type FROM coexistence.chat_history h
                               WHERE h.wa_number = k.wa AND h.contact_number = k.cn
                               ORDER BY h.timestamp DESC LIMIT 1) lm ON TRUE
           LEFT JOIN LATERAL (SELECT s.name AS stage_name FROM coexistence.deals d
                                JOIN coexistence.pipeline_stages s ON s.id = d.stage_id
                               WHERE d.contact_wa_number = k.wa AND d.contact_number = k.cn
                               ORDER BY d.updated_at DESC LIMIT 1) dl ON TRUE`, [was, cns]);
      const m = new Map(rows.map(r => [`${r.wa}|${r.cn}`, r]));
      return batch.map(r => {
        const e = m.get(`${r.wa_number}|${r.contact_number}`) || {};
        return { ...r, lastMessage: e.message_body || (e.message_type && e.message_type !== 'text' ? `[${e.message_type}]` : ''), leadStatus: e.stage_name || '' };
      });
    }

    const stamp = new Date().toISOString().slice(0, 10);
    const rangeSlug = range === 'custom' ? `${from}_to_${to}` : range;
    const fileBase = `rarevo-${String(biz.slug || 'business').replace(/[^a-z0-9_-]/gi, '')}-customers-${rangeSlug}-${stamp}`;

    // ───────────────────────── CSV ─────────────────────────
    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${fileBase}.csv"`);
      res.setHeader('Cache-Control', 'private, no-store');
      headersSent = true;
      res.write('\ufeff' + ['Customer ID', 'Customer Name', 'WhatsApp Number', 'WhatsApp Profile Name', 'First Contact', 'Last Contact',
        'Total Messages', 'Incoming', 'Outgoing', 'Last Message', 'Tags', 'Assigned Team Member', 'Lead Status'].join(',') + '\r\n');
      for (let i = 0; i < base.length; i += ENRICH_BATCH) {
        const batch = await enrich(base.slice(i, i + ENRICH_BATCH));
        let out = '';
        for (const r of batch) {
          out += [r.contact_id || '', r.name || '', r.contact_number, r.profile_name || '',
            toLocal(r.first_at)?.toISOString().replace('T', ' ').slice(0, 16), toLocal(r.last_at)?.toISOString().replace('T', ' ').slice(0, 16),
            r.msgs, r.inbound, r.outbound, r.lastMessage,
            (Array.isArray(r.tags) ? r.tags : []).map(t => tagNameOf(t, tagMap)).filter(Boolean).join('; '),
            r.assigned_name || '', r.leadStatus].map(csvCell).join(',') + '\r\n';
        }
        res.write(out);
      }
      res.end();
      await writeAudit(req, biz, { format, range, rangeLabel, rows: base.length, ms: Date.now() - startedAt });
      return;
    }

    // ───────────────────────── XLSX ─────────────────────────
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${fileBase}.xlsx"`);
    res.setHeader('Cache-Control', 'private, no-store');
    headersSent = true;

    const wb = new ExcelJS.stream.xlsx.WorkbookWriter({ stream: res, useStyles: true, useSharedStrings: false });
    wb.creator = 'Rarevo'; wb.created = new Date();
    const HEAD_FILL = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1F2937' } };
    const styleHeader = (ws) => {
      const r = ws.getRow(1);
      r.font = { bold: true, color: { argb: 'FFFFFFFF' } }; r.fill = HEAD_FILL;
      r.alignment = { vertical: 'middle' }; r.height = 22; r.commit();
    };
    const DT = 'yyyy-mm-dd hh:mm';

    // Sheet 1 — Customer Records
    const ws1 = wb.addWorksheet('Customer Records', { views: [{ state: 'frozen', ySplit: 1 }] });
    ws1.columns = [
      { header: 'Customer ID', key: 'id', width: 12 }, { header: 'Customer Name', key: 'name', width: 26 },
      { header: 'WhatsApp Number', key: 'num', width: 18, style: { numFmt: '@' } }, { header: 'WhatsApp Profile Name', key: 'prof', width: 24 },
      { header: 'First Contact Date', key: 'first', width: 18, style: { numFmt: DT } }, { header: 'Last Contact Date', key: 'last', width: 18, style: { numFmt: DT } },
      { header: 'Total Messages', key: 'msgs', width: 14, style: { numFmt: '#,##0' } }, { header: 'Incoming Messages', key: 'in', width: 17, style: { numFmt: '#,##0' } },
      { header: 'Outgoing Messages', key: 'out', width: 17, style: { numFmt: '#,##0' } }, { header: 'Last Message', key: 'lm', width: 44 },
      { header: 'Customer Tags', key: 'tags', width: 28 }, { header: 'Assigned Team Member', key: 'assg', width: 22 },
      { header: 'Lead Status', key: 'lead', width: 18 }, { header: 'Customer Created Date', key: 'cc', width: 20, style: { numFmt: DT } },
      { header: 'Last Updated Date', key: 'cu', width: 20, style: { numFmt: DT } },
    ];
    styleHeader(ws1);
    ws1.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: 15 } };
    for (let i = 0; i < base.length; i += ENRICH_BATCH) {
      const batch = await enrich(base.slice(i, i + ENRICH_BATCH));
      for (const r of batch) {
        ws1.addRow({
          id: r.contact_id || '', name: safeCell(r.name), num: safeCell(r.contact_number), prof: safeCell(r.profile_name),
          first: toLocal(r.first_at), last: toLocal(r.last_at), msgs: r.msgs, in: r.inbound, out: r.outbound,
          lm: safeCell(r.lastMessage),
          tags: safeCell((Array.isArray(r.tags) ? r.tags : []).map(t => tagNameOf(t, tagMap)).filter(Boolean).join(', ')),
          assg: safeCell(r.assigned_name), lead: safeCell(r.leadStatus), cc: toLocal(r.c_created), cu: toLocal(r.c_updated),
        }).commit();
      }
    }
    ws1.commit();

    // Sheet 2 — Message Summary (date-wise, business-local days, same range window)
    const msgParams = [tz, lo, hi];
    const ws2 = wb.addWorksheet('Message Summary', { views: [{ state: 'frozen', ySplit: 1 }] });
    ws2.columns = [
      { header: 'Date', key: 'd', width: 14, style: { numFmt: 'yyyy-mm-dd' } }, { header: 'Incoming', key: 'in', width: 12 },
      { header: 'Outgoing', key: 'out', width: 12 }, { header: 'Successful Sends', key: 'ok', width: 17 },
      { header: 'Failed Sends', key: 'fail', width: 14 }, { header: 'Active Customers', key: 'act', width: 17 },
      { header: 'New Customers', key: 'new', width: 15 },
    ];
    styleHeader(ws2);
    const sc = await buildWaScope(req, 'h', 4);
    const daily = await pool.query(
      `WITH m AS (
         SELECT (h.timestamp AT TIME ZONE $1)::date AS d, h.direction, h.status, h.contact_number, h.wa_number
           FROM coexistence.chat_history h
          WHERE ($2::timestamptz IS NULL OR h.timestamp >= $2::timestamptz) AND ($3::timestamptz IS NULL OR h.timestamp < $3::timestamptz)
            ${sc.sql ? `AND ${sc.sql}` : ''}),
       firsts AS (
         SELECT (MIN(h.timestamp) AT TIME ZONE $1)::date AS d, COUNT(*)::int AS n FROM (
           SELECT wa_number, contact_number, MIN(timestamp) AS timestamp FROM coexistence.chat_history GROUP BY 1,2) h GROUP BY 1)
       SELECT m.d,
              COUNT(*) FILTER (WHERE direction='incoming')::int AS inc,
              COUNT(*) FILTER (WHERE direction='outgoing')::int AS outg,
              COUNT(*) FILTER (WHERE direction='outgoing' AND status <> 'failed')::int AS ok,
              COUNT(*) FILTER (WHERE direction='outgoing' AND status = 'failed')::int AS fail,
              COUNT(DISTINCT (wa_number, contact_number))::int AS act,
              COALESCE(MAX(f.n),0)::int AS newc
         FROM m LEFT JOIN firsts f ON f.d = m.d GROUP BY m.d ORDER BY m.d DESC`, [...msgParams, ...sc.params]);
    const tot = { inc: 0, outg: 0, ok: 0, fail: 0, newc: 0 };
    for (const r of daily.rows) {
      tot.inc += r.inc; tot.outg += r.outg; tot.ok += r.ok; tot.fail += r.fail; tot.newc += r.newc;
      ws2.addRow({ d: new Date(r.d), in: r.inc, out: r.outg, ok: r.ok, fail: r.fail, act: r.act, new: r.newc }).commit();
    }
    const totalRow = ws2.addRow({ d: 'TOTAL', in: tot.inc, out: tot.outg, ok: tot.ok, fail: tot.fail, act: base.length, new: tot.newc });
    totalRow.font = { bold: true }; totalRow.commit();
    ws2.commit();

    // Sheet 3 — Business Information
    const ws3 = wb.addWorksheet('Business Information');
    ws3.columns = [{ header: 'Field', key: 'k', width: 28 }, { header: 'Value', key: 'v', width: 48 }];
    styleHeader(ws3);
    [['Business name', biz.name], ['Business ID', biz.id], ['Export date', toLocal(new Date())],
      ['Time zone', tz], ['Selected date range', rangeLabel],
      ['Search filter', q || '—'], ['Tag filter', tag ? (tagMap.get(tag) || tag) : '—'], ['Assigned member filter', assignedUserId || '—'],
      ['Total exported records', base.length], ['Exported by', req.user?.displayName || req.user?.username || `user ${req.user?.id}`]]
      .forEach(([k, v]) => {
        const row = ws3.addRow({ k, v: typeof v === 'string' ? safeCell(v) : v });
        row.getCell(1).font = { bold: true };
        if (v instanceof Date) row.getCell(2).numFmt = DT;
        row.getCell(2).alignment = { horizontal: 'left' };
        row.commit();
      });
    ws3.commit();

    // Sheet 4 — Campaign Summary (only if the business has broadcasts)
    try {
      const camps = await pool.query(
        `SELECT b.id, b.name, b.created_at, COALESCE(jsonb_array_length(b.recipient_numbers), 0)::int AS recipients,
                COUNT(l.id) FILTER (WHERE l.action = 'BROADCAST' AND l.status IN ('SENT','sent','delivered','read'))::int AS ok,
                COUNT(l.id) FILTER (WHERE l.action = 'BROADCAST' AND l.status IN ('FAILED','failed'))::int AS failed,
                COUNT(l.id) FILTER (WHERE l.action = 'BROADCAST' AND l.status = 'PENDING')::int AS pending
           FROM coexistence.broadcasts b LEFT JOIN coexistence.broadcast_logs l ON l.broadcast_id = b.id
          WHERE b.status = 'SENT' AND ($1::timestamptz IS NULL OR b.created_at >= $1::timestamptz) AND ($2::timestamptz IS NULL OR b.created_at < $2::timestamptz)
          GROUP BY b.id ORDER BY b.created_at DESC LIMIT 5000`, [lo, hi]);
      if (camps.rows.length) {
        const ws4 = wb.addWorksheet('Campaign Summary', { views: [{ state: 'frozen', ySplit: 1 }] });
        ws4.columns = [
          { header: 'Campaign Name', key: 'n', width: 32 }, { header: 'Campaign Date', key: 'd', width: 18, style: { numFmt: DT } },
          { header: 'Total Recipients', key: 't', width: 16 }, { header: 'Successful Messages', key: 'ok', width: 19 },
          { header: 'Failed Messages', key: 'f', width: 16 }, { header: 'Pending Messages', key: 'p', width: 17 },
        ];
        styleHeader(ws4);
        camps.rows.forEach(c => ws4.addRow({ n: safeCell(c.name || `Broadcast #${c.id}`), d: toLocal(c.created_at), t: c.recipients, ok: c.ok, f: c.failed, p: c.pending }).commit());
        ws4.commit();
      }
    } catch (e) { console.error('[recordsExport] campaign sheet skipped:', e.message); }

    await wb.commit();
    await writeAudit(req, biz, { format, range, rangeLabel, rows: base.length, ms: Date.now() - startedAt });
  } catch (err) {
    console.error('[recordsExport] error:', err.message);
    if (!headersSent) return res.status(500).json({ error: 'Failed to export records' });
    try { res.destroy(err); } catch { /* connection already closed */ }
  }
});

async function writeAudit(req, biz, details) {
  try {
    await runAsPlatform(() => pool.query(
      `INSERT INTO coexistence.business_audit_log (business_id, user_id, action, details) VALUES ($1,$2,'records.export',$3)`,
      [biz.id, req.user?.id || null, JSON.stringify({ ...details, ip: req.ip })]));
  } catch (err) { console.error('[recordsExport] audit failed:', err.message); }
}

module.exports = { router };
