// Platform-level API for the agency's team: manage client BUSINESSES.
//
// Mounted WITHOUT a business context (see index.js). Aggregate queries run as
// the table owner and so span businesses; anything that reads one business's
// working data switches into that business with runInBusiness().
//
//   GET    /businesses                      cards for the dashboard (+ stats)
//   GET    /businesses/overview             platform-wide totals
//   POST   /businesses/test-whatsapp        verify Cloud API credentials
//   POST   /businesses                      Add Business wizard (one call)
//   POST   /businesses/bulk                 import up to 1000 businesses at once
//   GET    /businesses/:id                  detail (+ numbers, team, webhook info)
//   PUT    /businesses/:id                  edit details
//   POST   /businesses/:id/status           pause / resume
//   DELETE /businesses/:id                  archive (soft delete)
//   POST   /businesses/:id/whatsapp         connect / reconnect a WhatsApp number
//   DELETE /businesses/:id/whatsapp/:accId  disconnect a number
//   (CRM connection: see routes/crmConnect.js — read-only API for the external Rarevo CRM)
//   POST   /businesses/:id/automations      create an automation (blank or from template)
//   GET    /businesses/:id/members          our team on this business
//   PUT    /businesses/:id/members          replace the member list
//   GET    /businesses/:id/audit-log        change history
//   GET    /automation-templates            starter automations

const { Router } = require('express');
const pool = require('../db');
const { ACTIONS, normalizeBusinessRole, effectiveBusinessActions, cleanOverrides } = require('../permissions');
const { syncMemberships, parseDesired } = require('../services/memberAccess');
const { encrypt, maskSecret, decrypt } = require('../util/crypto');
const { adminOnly } = require('../middleware/access');
const { fetchPhoneMeta } = require('./whatsappAccounts');

const router = Router();

/* ------------------------------ helpers -------------------------------- */

const STATUSES = new Set(['onboarding', 'active', 'paused', 'archived']);

function slugify(s) {
  return String(s || '').toLowerCase().normalize('NFKD').replace(/[^\w\s-]/g, '')
    .trim().replace(/[\s_]+/g, '-').replace(/-+/g, '-').slice(0, 48) || 'business';
}

async function uniqueSlug(client, name) {
  const base = slugify(name);
  for (let i = 0; i < 50; i++) {
    const slug = i === 0 ? base : `${base}-${i + 1}`;
    const { rowCount } = await client.query('SELECT 1 FROM coexistence.businesses WHERE slug = $1', [slug]);
    if (rowCount === 0) return slug;
  }
  return `${base}-${Date.now()}`;
}

async function audit(businessId, userId, action, details = {}) {
  try {
    await pool.query(
      `INSERT INTO coexistence.business_audit_log (business_id, user_id, action, details) VALUES ($1,$2,$3,$4)`,
      [businessId, userId || null, action, JSON.stringify(details)]
    );
  } catch (err) { console.error('[businesses] audit failed:', err.message); }
}

/** Admin = whole platform. Others need a business_members row. Returns role or null. */
async function accessRole(req, businessId) {
  if (req.user?.role === 'admin') { req.bizActions = new Set(ACTIONS); return 'business_manager'; }
  const { rows } = await pool.query(
    'SELECT role, permissions FROM coexistence.business_members WHERE business_id = $1 AND user_id = $2',
    [businessId, req.user?.id]
  );
  if (!rows[0]) return null;
  req.bizActions = effectiveBusinessActions(rows[0].role, rows[0].permissions);
  return normalizeBusinessRole(rows[0].role);
}

/** Loads the business and enforces access. `needManager` for edits. */
async function loadBusiness(req, res, { needManager = false } = {}) {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) { res.status(400).json({ error: 'Invalid business id' }); return null; }
  const { rows } = await pool.query(
    'SELECT * FROM coexistence.businesses WHERE id = $1 AND deleted_at IS NULL', [id]);
  if (!rows[0]) { res.status(404).json({ error: 'Business not found' }); return null; }
  const role = await accessRole(req, id);
  if (!role || (needManager && role !== 'business_manager')) {
    res.status(403).json({ error: 'You do not have access to this business' }); return null;
  }
  return rows[0];
}

function businessShape(b) {
  return {
    id: Number(b.id), name: b.name, slug: b.slug, logoUrl: b.logo_url, industry: b.industry,
    website: b.website, contactName: b.contact_name, contactEmail: b.contact_email,
    contactPhone: b.contact_phone, address: b.address, timezone: b.timezone, notes: b.notes,
    status: b.status, plan: b.plan, monthlyMessageLimit: b.monthly_message_limit, dailyMessageLimit: b.daily_message_limit || null,
    crmConnected: b.crm_connected, crmSettings: b.crm_settings || {},
    createdAt: b.created_at, updatedAt: b.updated_at,
  };
}

function accountShape(a) {
  return {
    id: Number(a.id), displayName: a.display_name, displayPhoneNumber: a.display_phone_number,
    phoneNumberId: a.phone_number_id, wabaId: a.waba_id, isDefault: a.is_default, isActive: a.is_active,
    healthStatus: a.health_status || 'unknown', lastErrorMessage: a.last_error_message,
    tokenMasked: a.access_token_encrypted ? maskSecret(decrypt(a.access_token_encrypted)) : '',
  };
}

function webhookInfo(req) {
  const base = (process.env.PUBLIC_BASE_URL || `${req.headers['x-forwarded-proto'] || req.protocol}://${req.headers['x-forwarded-host'] || req.get('host')}`).replace(/\/+$/, '');
  return { callbackUrl: `${base}/api/webhook/whatsapp` };
}

async function verifyWhatsApp({ phoneNumberId, accessToken }) {
  const meta = await fetchPhoneMeta(String(phoneNumberId).trim(), String(accessToken).trim());
  return {
    displayName: meta.verified_name || null,
    displayPhoneNumber: meta.display_phone_number ? String(meta.display_phone_number).replace(/\D/g, '') : '',
  };
}

const META_HELP = (m) =>
  `Couldn't verify this WhatsApp number with Meta. Check the Phone Number ID and access token (a test number's token expires every 24 hours). Meta said: ${m}`;

// Insert/update a WhatsApp account for a business. `db` is a pg client/pool at PLATFORM level,
// so business_id is passed explicitly (RLS does not apply to the owner role).
async function upsertAccount(db, businessId, { phoneNumberId, wabaId, accessToken, verifyToken, metaAppId }, meta) {
  const { rows: cnt } = await db.query(
    'SELECT COUNT(*)::int AS n FROM coexistence.whatsapp_accounts WHERE business_id = $1', [businessId]);
  const { rows: ex } = await db.query(
    'SELECT * FROM coexistence.whatsapp_accounts WHERE phone_number_id = $1', [String(phoneNumberId).trim()]);
  if (ex[0] && Number(ex[0].business_id) !== Number(businessId)) {
    const e = new Error('This Phone Number ID is already connected to another business');
    e.status = 409; throw e;
  }
  const displayName = meta.displayName || `WhatsApp ${String(wabaId).trim()}`;
  if (ex[0]) {
    const { rows } = await db.query(
      `UPDATE coexistence.whatsapp_accounts
          SET display_name=$1, display_phone_number=$2, waba_id=$3, meta_app_id=COALESCE($4, meta_app_id),
              access_token_encrypted=$5,
              verify_token_encrypted=COALESCE($6, verify_token_encrypted),
              is_active=TRUE, health_status='unknown', last_error_message=NULL, updated_at=NOW()
        WHERE id=$7 RETURNING *`,
      [displayName, meta.displayPhoneNumber, String(wabaId).trim(), metaAppId?.trim() || null,
       encrypt(String(accessToken).trim()),
       verifyToken != null ? encrypt(String(verifyToken).trim()) : null, ex[0].id]);
    return rows[0];
  }
  const { rows } = await db.query(
    `INSERT INTO coexistence.whatsapp_accounts
       (business_id, display_name, display_phone_number, phone_number_id, waba_id, meta_app_id,
        access_token_encrypted, verify_token_encrypted, is_default, is_active)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,TRUE) RETURNING *`,
    [businessId, displayName, meta.displayPhoneNumber, String(phoneNumberId).trim(), String(wabaId).trim(),
     metaAppId?.trim() || null, encrypt(String(accessToken).trim()),
     encrypt(String(verifyToken || '').trim()), cnt[0].n === 0]);
  return rows[0];
}

async function createAutomation(db, businessId, { name, templateId }) {
  let config = {
    nodes: [
      { id: 'n1', type: 'trigger', x: 80, y: 120, title: 'Trigger', sub: 'Keyword', triggerKind: 'keyword', keyword: 'hi', matchType: 'exact', caseSensitive: false },
      { id: 'n2', type: 'message', x: 380, y: 120, title: 'Message', sub: 'Reply', templateId: '', bindings: {}, messageMode: 'direct', directType: 'text', directData: { body: 'Hello! 👋 How can we help you today?' } },
    ],
    edges: [{ from: 'n1', to: 'n2', fromHandle: 'default' }],
  };
  let description = null;
  if (templateId) {
    const { rows } = await db.query('SELECT * FROM coexistence.automation_templates WHERE id = $1', [templateId]);
    if (!rows[0]) { const e = new Error('Automation template not found'); e.status = 404; throw e; }
    config = rows[0].config; description = rows[0].description;
  }
  const { rows } = await db.query(
    `INSERT INTO coexistence.chatbots (business_id, name, description, status, trigger_type, config)
     VALUES ($1,$2,$3,'active','keyword',$4) RETURNING id, name, status`,
    [businessId, name, description, JSON.stringify(config)]);
  return rows[0];
}

/* ------------------------------ list / overview ------------------------- */

const STATS_SQL = `
  SELECT b.*,
    (SELECT COUNT(*)::int FROM coexistence.contacts c WHERE c.business_id = b.id)                     AS contacts_count,
    (SELECT COUNT(*)::int FROM coexistence.chat_history h
       WHERE h.business_id = b.id AND h.timestamp > NOW() - INTERVAL '7 days')                         AS messages_7d,
    (SELECT COUNT(*)::int FROM coexistence.chat_history h
       WHERE h.business_id = b.id AND h.timestamp > date_trunc('month', NOW()))                        AS messages_month,
    (SELECT COUNT(*)::int FROM coexistence.chat_history h
       WHERE h.business_id = b.id AND h.direction = 'outgoing' AND h.status <> 'failed'
         AND h.timestamp >= (date_trunc('day', NOW() AT TIME ZONE COALESCE((SELECT z.name FROM pg_timezone_names z WHERE z.name = b.timezone LIMIT 1), 'Asia/Kolkata'))
                             AT TIME ZONE COALESCE((SELECT z.name FROM pg_timezone_names z WHERE z.name = b.timezone LIMIT 1), 'Asia/Kolkata'))) AS sent_today,
    (SELECT MAX(h.timestamp) FROM coexistence.chat_history h WHERE h.business_id = b.id)               AS last_activity,
    (SELECT COUNT(*)::int FROM coexistence.chatbots cb WHERE cb.business_id = b.id AND cb.status='active') AS automations_active,
    (SELECT COUNT(*)::int FROM coexistence.chatbots cb WHERE cb.business_id = b.id)                    AS automations_total,
    (SELECT COUNT(*)::int FROM coexistence.deals d WHERE d.business_id = b.id AND d.status='open')     AS open_deals,
    (SELECT COUNT(*)::int FROM coexistence.business_members m WHERE m.business_id = b.id)              AS members_count,
    COALESCE((SELECT json_agg(json_build_object(
        'id', wa.id, 'displayName', wa.display_name, 'displayPhoneNumber', wa.display_phone_number,
        'isDefault', wa.is_default, 'isActive', wa.is_active, 'healthStatus', COALESCE(wa.health_status,'unknown'))
        ORDER BY wa.is_default DESC, wa.id)
      FROM coexistence.whatsapp_accounts wa WHERE wa.business_id = b.id), '[]'::json)                  AS accounts
  FROM coexistence.businesses b
  WHERE b.deleted_at IS NULL AND b.status <> 'archived'`;

router.get('/businesses', async (req, res) => {
  try {
    // Server-side paging/search/filter so the dashboard stays fast with 100s–1000s of businesses.
    const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize, 10) || 24));
    const page = Math.max(1, parseInt(req.query.page, 10) || 1);
    const q = String(req.query.q || '').trim();
    const status = ['active', 'onboarding', 'paused'].includes(req.query.status) ? req.query.status : '';
    const slim = req.query.slim === '1'; // switcher: no stats

    const where = [`b.deleted_at IS NULL`, `b.status <> 'archived'`];
    const params = [];
    if (req.user?.role !== 'admin') {
      params.push(req.user.id);
      where.push(`b.id IN (SELECT business_id FROM coexistence.business_members WHERE user_id = $${params.length})`);
    }
    const baseWhere = where.join(' AND ');
    if (q) {
      params.push(`%${q.replace(/[%_]/g, m => '\\' + m)}%`);
      where.push(`(b.name ILIKE $${params.length} OR b.industry ILIKE $${params.length} OR b.contact_name ILIKE $${params.length}
        OR EXISTS (SELECT 1 FROM coexistence.whatsapp_accounts w WHERE w.business_id = b.id AND w.display_phone_number ILIKE $${params.length}))`);
    }
    if (status) { params.push(status); where.push(`b.status = $${params.length}`); }

    const countParams = params.slice();
    const { rows: tot } = await pool.query(
      `SELECT COUNT(*)::int AS n FROM coexistence.businesses b WHERE ${where.join(' AND ')}`, countParams);

    // status chip counts (ignore the status filter itself, honour search + access)
    const chipWhere = where.filter(w => !w.startsWith('b.status = '));
    const chipParams = status ? params.slice(0, -1) : params;
    const { rows: chips } = await pool.query(
      `SELECT b.status, COUNT(*)::int AS n FROM coexistence.businesses b WHERE ${chipWhere.join(' AND ')} GROUP BY b.status`, chipParams);
    const counts = { all: 0, active: 0, onboarding: 0, paused: 0 };
    chips.forEach(c => { counts[c.status] = c.n; counts.all += c.n; });

    if (slim) {
      const { rows } = await pool.query(
        `SELECT b.id, b.name, b.status FROM coexistence.businesses b WHERE ${where.join(' AND ')}
          ORDER BY b.name LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`, params);
      return res.json({ items: rows.map(r => ({ id: Number(r.id), name: r.name, status: r.status })), total: tot[0].n, page, pageSize, counts });
    }

    // Stats are computed only for the visible page (correlated subqueries), not all businesses.
    const sql = STATS_SQL.replace(
      "WHERE b.deleted_at IS NULL AND b.status <> 'archived'",
      `WHERE ${where.join(' AND ')}`);
    const { rows } = await pool.query(
      `${sql} ORDER BY b.created_at DESC, b.id DESC LIMIT ${pageSize} OFFSET ${(page - 1) * pageSize}`, params);
    let roles = new Map();
    if (req.user?.role !== 'admin') {
      const m = await pool.query('SELECT business_id, role FROM coexistence.business_members WHERE user_id = $1', [req.user.id]);
      roles = new Map(m.rows.map(x => [Number(x.business_id), x.role]));
    }
    res.json({
      items: rows.map(r => ({
        ...businessShape(r),
        myRole: req.user?.role === 'admin' ? 'business_manager' : normalizeBusinessRole(roles.get(Number(r.id))),
        stats: {
          contacts: r.contacts_count, sentToday: r.sent_today, messages7d: r.messages_7d, messagesMonth: r.messages_month,
          lastActivity: r.last_activity, automationsActive: r.automations_active,
          automationsTotal: r.automations_total, openDeals: r.open_deals, members: r.members_count,
        },
        accounts: r.accounts,
      })),
      total: tot[0].n, page, pageSize, counts,
    });
  } catch (err) {
    console.error('[businesses] list error:', err.message);
    res.status(500).json({ error: 'Failed to list businesses' });
  }
});

router.get('/businesses/overview', adminOnly, async (req, res) => {
  try {
    const { rows: tot } = await pool.query(`
      SELECT
        (SELECT COUNT(*)::int FROM coexistence.businesses WHERE deleted_at IS NULL AND status<>'archived') AS businesses,
        (SELECT COUNT(*)::int FROM coexistence.businesses WHERE deleted_at IS NULL AND status='active')   AS active,
        (SELECT COUNT(*)::int FROM coexistence.businesses WHERE deleted_at IS NULL AND status='paused')   AS paused,
        (SELECT COUNT(*)::int FROM coexistence.businesses WHERE deleted_at IS NULL AND status='onboarding') AS onboarding,
        (SELECT COUNT(*)::int FROM coexistence.whatsapp_accounts) AS numbers,
        (SELECT COUNT(*)::int FROM coexistence.whatsapp_accounts WHERE health_status NOT IN ('healthy','unknown')) AS numbers_unhealthy,
        (SELECT COUNT(*)::int FROM coexistence.contacts) AS contacts,
        (SELECT COUNT(*)::int FROM coexistence.chat_history WHERE timestamp > date_trunc('day', NOW())) AS messages_today,
        (SELECT COUNT(*)::int FROM coexistence.chat_history WHERE timestamp > NOW() - INTERVAL '7 days') AS messages_7d,
        (SELECT COUNT(*)::int FROM coexistence.chatbots WHERE status='active') AS automations_active`);
    const { rows: daily } = await pool.query(`
      SELECT to_char(d::date,'YYYY-MM-DD') AS day, COALESCE(c.n,0)::int AS messages
        FROM generate_series(NOW()::date - 13, NOW()::date, '1 day') d
        LEFT JOIN (SELECT timestamp::date AS day, COUNT(*) n FROM coexistence.chat_history
                    WHERE timestamp > NOW() - INTERVAL '14 days' GROUP BY 1) c ON c.day = d::date
       ORDER BY d`);
    const { rows: attention } = await pool.query(`
      SELECT b.id, b.name, wa.display_phone_number, wa.health_status, wa.last_error_message
        FROM coexistence.whatsapp_accounts wa JOIN coexistence.businesses b ON b.id = wa.business_id
       WHERE b.deleted_at IS NULL AND wa.health_status NOT IN ('healthy','unknown')
       ORDER BY b.name LIMIT 20`);
    const o = tot[0];
    res.json({
      businesses: o.businesses, active: o.active, paused: o.paused, onboarding: o.onboarding,
      numbers: o.numbers, numbersUnhealthy: o.numbers_unhealthy, contacts: o.contacts,
      messagesToday: o.messages_today, messages7d: o.messages_7d, automationsActive: o.automations_active,
      daily, attention,
    });
  } catch (err) {
    console.error('[businesses] overview error:', err.message);
    res.status(500).json({ error: 'Failed to load overview' });
  }
});

router.get('/automation-templates', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT id, name, description, category FROM coexistence.automation_templates ORDER BY id');
    res.json(rows.map(r => ({ id: Number(r.id), name: r.name, description: r.description, category: r.category })));
  } catch (err) {
    res.status(500).json({ error: 'Failed to load automation templates' });
  }
});

/* ------------------------------ wizard ---------------------------------- */

router.post('/businesses/test-whatsapp', adminOnly, async (req, res) => {
  const { phoneNumberId, accessToken } = req.body || {};
  if (!phoneNumberId || !accessToken) return res.status(400).json({ error: 'Phone Number ID and access token are required' });
  try {
    const meta = await verifyWhatsApp({ phoneNumberId, accessToken });
    res.json({ ok: true, ...meta });
  } catch (err) {
    res.status(400).json({ ok: false, error: META_HELP(err.message) });
  }
});

// Bulk import: create many businesses in one call (max 1000). Each row is its own
// transaction, so one bad row never blocks the rest. WhatsApp credentials are stored
// as given WITHOUT a live Meta check (too slow for hundreds of rows) — the number's
// health shows up on the card after its first send/receive, or use "Connect WhatsApp"
// on a card to re-verify.
router.post('/businesses/bulk', adminOnly, async (req, res) => {
  const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
  if (rows.length === 0) return res.status(400).json({ error: 'No rows to import' });
  if (rows.length > 1000) return res.status(400).json({ error: 'Import at most 1000 businesses at a time' });
  const results = [];
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i] || {};
    const name = String(r.name || '').trim();
    if (!name) { results.push({ row: i + 1, ok: false, error: 'Missing name' }); continue; }
    const hasWa = r.phoneNumberId && r.wabaId && r.accessToken;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const slug = await uniqueSlug(client, name);
      const { rows: ins } = await client.query(
        `INSERT INTO coexistence.businesses (name, slug, industry, contact_name, contact_email, contact_phone, website, notes, status, created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
        [name, slug, r.industry || null, r.contactName || null, r.contactEmail || null, r.contactPhone || null,
         r.website || null, r.notes || null, hasWa ? 'active' : 'onboarding', req.user.id]);
      const bid = ins[0].id;
      await client.query('SELECT coexistence.seed_business_defaults($1)', [bid]);
      if (hasWa) {
        await upsertAccount(client, bid, r, { displayName: r.displayName || name, displayPhoneNumber: String(r.displayPhoneNumber || '').replace(/\D/g, '') });
      }
      if (r.automation !== false) {
        const bot = await createAutomation(client, bid, { name: `${name} – Welcome Flow`, templateId: null });
        if (!hasWa) await client.query(`UPDATE coexistence.chatbots SET status='draft' WHERE id=$1`, [bot.id]);
      }
      await client.query('COMMIT');
      results.push({ row: i + 1, ok: true, id: Number(bid), name });
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      results.push({ row: i + 1, ok: false, name, error: err.status ? err.message : (err.detail || err.message) });
    } finally {
      client.release();
    }
  }
  const created = results.filter(x => x.ok).length;
  await audit(null, req.user.id, 'business.bulk_import', { created, failed: results.length - created });
  res.json({ created, failed: results.length - created, results });
});

router.post('/businesses', adminOnly, async (req, res) => {
  const { details = {}, whatsapp, automation, memberIds } = req.body || {};
  const name = String(details.name || '').trim();
  if (!name) return res.status(400).json({ error: 'Business name is required' });
  if (whatsapp && (!whatsapp.phoneNumberId || !whatsapp.wabaId || !whatsapp.accessToken)) {
    return res.status(400).json({ error: 'WhatsApp needs Phone Number ID, WABA ID and access token (or leave WhatsApp out and connect later)' });
  }

  // Verify with Meta BEFORE touching the database so a typo never leaves a half-built business.
  let meta = null;
  if (whatsapp) {
    try { meta = await verifyWhatsApp(whatsapp); }
    catch (err) { return res.status(400).json({ error: META_HELP(err.message), step: 'whatsapp' }); }
  }

  const client = await pool.connect(); // platform level: no business context here
  try {
    await client.query('BEGIN');
    const slug = await uniqueSlug(client, name);
    const { rows } = await client.query(
      `INSERT INTO coexistence.businesses
         (name, slug, logo_url, industry, website, contact_name, contact_email, contact_phone,
          address, timezone, notes, plan, status, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,COALESCE($10,'Asia/Kolkata'),$11,COALESCE($12,'starter'),$13,$14)
       RETURNING *`,
      [name, slug, details.logoUrl || null, details.industry || null, details.website || null,
       details.contactName || null, details.contactEmail || null, details.contactPhone || null,
       details.address || null, details.timezone || null, details.notes || null, details.plan || null,
       whatsapp ? 'active' : 'onboarding', req.user.id]);
    const biz = rows[0];

    await client.query('SELECT coexistence.seed_business_defaults($1)', [biz.id]);

    let account = null;
    if (whatsapp) account = await upsertAccount(client, biz.id, whatsapp, meta);

    let bot = null;
    if (automation !== false) {
      const botName = String(automation?.name || '').trim() || `${name} – Welcome Flow`;
      bot = await createAutomation(client, biz.id, { name: botName, templateId: automation?.templateId });
      if (!account) await client.query(`UPDATE coexistence.chatbots SET status='draft' WHERE id=$1`, [bot.id]);
    }

    const members = Array.isArray(memberIds) ? [...new Set(memberIds.map(Number).filter(Number.isInteger))] : [];
    for (const uid of members) {
      await client.query(
        `INSERT INTO coexistence.business_members (business_id, user_id, role) VALUES ($1,$2,'support_agent')
         ON CONFLICT DO NOTHING`, [biz.id, uid]);
    }
    await client.query('COMMIT');
    await audit(biz.id, req.user.id, 'business.created', { name, whatsapp: !!account, automation: bot?.name || null });
    res.status(201).json({
      business: businessShape(biz),
      account: account ? accountShape(account) : null,
      automation: bot,
      webhook: webhookInfo(req),
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    if (err.status) return res.status(err.status).json({ error: err.message });
    console.error('[businesses] create error:', err.message);
    res.status(500).json({ error: 'Failed to create business' });
  } finally {
    client.release();
  }
});

/* ------------------------------ one business ---------------------------- */

router.get('/businesses/:id', async (req, res) => {
  try {
    const b = await loadBusiness(req, res); if (!b) return;
    const { rows: accs } = await pool.query(
      'SELECT * FROM coexistence.whatsapp_accounts WHERE business_id = $1 ORDER BY is_default DESC, id', [b.id]);
    const { rows: mem } = await pool.query(
      `SELECT m.user_id, m.role, u.display_name, u.email
         FROM coexistence.business_members m JOIN coexistence.forgecrm_users u ON u.id = m.user_id
        WHERE m.business_id = $1 ORDER BY u.display_name`, [b.id]);
    res.json({
      ...businessShape(b),
      accounts: accs.map(accountShape),
      members: mem.map(m => ({ userId: Number(m.user_id), role: m.role, displayName: m.display_name, email: m.email })),
      webhook: webhookInfo(req),
      myRole: await accessRole(req, b.id),
    });
  } catch (err) {
    console.error('[businesses] get error:', err.message);
    res.status(500).json({ error: 'Failed to load business' });
  }
});

router.put('/businesses/:id', async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const d = req.body || {};
    if (d.name !== undefined && !String(d.name).trim()) return res.status(400).json({ error: 'Business name is required' });
    const map = {
      name: 'name', logoUrl: 'logo_url', industry: 'industry', website: 'website', contactName: 'contact_name',
      contactEmail: 'contact_email', contactPhone: 'contact_phone', address: 'address', timezone: 'timezone',
      notes: 'notes', plan: 'plan', monthlyMessageLimit: 'monthly_message_limit',
    };
    // Usage limits and the plan are NOT part of a manager's normal edit rights: changing them needs the
    // 'limits.edit' permission (platform admins always have it; admins can grant it to a member).
    const canEditLimits = req.user?.role === 'admin' || req.bizActions?.has('limits.edit');
    if ((d.monthlyMessageLimit !== undefined || d.plan !== undefined || d.dailyMessageLimit !== undefined) && !canEditLimits) {
      return res.status(403).json({ error: 'You need the "Change usage limits" permission to change message limits or the plan', code: 'PERMISSION_DENIED', required: 'limits.edit' });
    }
    if (d.monthlyMessageLimit !== undefined) {
      const m = d.monthlyMessageLimit === '' || d.monthlyMessageLimit === null ? null : Number(d.monthlyMessageLimit);
      if (m !== null && (!Number.isInteger(m) || m < 1 || m > 1000000000)) {
        return res.status(400).json({ error: 'Monthly message limit must be a whole number of 1 or more (leave blank for unlimited)' });
      }
      d.monthlyMessageLimit = m === null ? '' : m;
    }
    // Daily message limit (blank = unlimited).
    if (d.dailyMessageLimit !== undefined) {
      const raw = d.dailyMessageLimit === '' || d.dailyMessageLimit === null ? null : Number(d.dailyMessageLimit);
      if (raw !== null && (!Number.isInteger(raw) || raw < 1 || raw > 10000000)) {
        return res.status(400).json({ error: 'Daily message limit must be a whole number of 1 or more (leave blank for unlimited)' });
      }
      map.dailyMessageLimit = 'daily_message_limit'; d.dailyMessageLimit = raw === null ? '' : raw;
    }
    const sets = ['updated_at = NOW()']; const params = [];
    for (const [k, col] of Object.entries(map)) {
      if (d[k] !== undefined) { params.push(d[k] === '' ? null : d[k]); sets.push(`${col} = $${params.length}`); }
    }
    params.push(b.id);
    const { rows } = await pool.query(
      `UPDATE coexistence.businesses SET ${sets.join(', ')} WHERE id = $${params.length} RETURNING *`, params);
    await audit(b.id, req.user.id, 'business.updated', { fields: Object.keys(d) });
    res.json(businessShape(rows[0]));
  } catch (err) {
    console.error('[businesses] update error:', err.message);
    res.status(500).json({ error: 'Failed to update business' });
  }
});

router.post('/businesses/:id/status', adminOnly, async (req, res) => {
  try {
    const status = String(req.body?.status || '');
    if (!STATUSES.has(status) || status === 'archived') return res.status(400).json({ error: 'status must be active, paused or onboarding' });
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const { rows } = await pool.query(
      'UPDATE coexistence.businesses SET status=$1, updated_at=NOW() WHERE id=$2 RETURNING *', [status, b.id]);
    await audit(b.id, req.user.id, `business.${status}`, {});
    res.json(businessShape(rows[0]));
  } catch (err) {
    res.status(500).json({ error: 'Failed to change status' });
  }
});

router.delete('/businesses/:id', adminOnly, async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    if (String(req.query.confirm || '') !== b.slug) {
      return res.status(400).json({ error: 'Type the business slug as ?confirm= to archive it', slug: b.slug });
    }
    // Soft delete: data is kept, the business disappears everywhere and its numbers stop
    // routing (the webhook ignores archived businesses). Phone numbers are released so they
    // can be attached to another business.
    await pool.query(`UPDATE coexistence.businesses SET status='archived', deleted_at=NOW(), updated_at=NOW() WHERE id=$1`, [b.id]);
    await pool.query(`UPDATE coexistence.whatsapp_accounts SET is_active=FALSE WHERE business_id=$1`, [b.id]);
    await audit(b.id, req.user.id, 'business.archived', { name: b.name });
    res.json({ ok: true });
  } catch (err) {
    console.error('[businesses] archive error:', err.message);
    res.status(500).json({ error: 'Failed to archive business' });
  }
});

/* ------------------------------ WhatsApp -------------------------------- */

router.post('/businesses/:id/whatsapp', adminOnly, async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const w = req.body || {};
    if (!w.phoneNumberId || !w.wabaId || !w.accessToken) {
      return res.status(400).json({ error: 'Phone Number ID, WABA ID and access token are required' });
    }
    let meta;
    try { meta = await verifyWhatsApp(w); }
    catch (err) { return res.status(400).json({ error: META_HELP(err.message) }); }
    const acc = await upsertAccount(pool, b.id, w, meta);
    if (b.status === 'onboarding') {
      await pool.query(`UPDATE coexistence.businesses SET status='active', updated_at=NOW() WHERE id=$1`, [b.id]);
      await pool.query(`UPDATE coexistence.chatbots SET status='active' WHERE business_id=$1 AND status='draft'`, [b.id]);
    }
    await audit(b.id, req.user.id, 'whatsapp.connected', { phoneNumberId: acc.phone_number_id });
    res.status(201).json({ account: accountShape(acc), webhook: webhookInfo(req) });
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    console.error('[businesses] whatsapp error:', err.message);
    res.status(500).json({ error: 'Failed to connect WhatsApp' });
  }
});

router.delete('/businesses/:id/whatsapp/:accId', adminOnly, async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const { rows: cnt } = await pool.query('SELECT COUNT(*)::int n FROM coexistence.whatsapp_accounts WHERE business_id=$1', [b.id]);
    if (cnt[0].n <= 1) return res.status(409).json({ error: 'Cannot remove the only number. Reconnect it with new details instead.' });
    const { rowCount } = await pool.query(
      'DELETE FROM coexistence.whatsapp_accounts WHERE id=$1 AND business_id=$2', [req.params.accId, b.id]);
    if (!rowCount) return res.status(404).json({ error: 'Number not found' });
    await pool.query(`UPDATE coexistence.whatsapp_accounts SET is_default=TRUE
                       WHERE id = (SELECT id FROM coexistence.whatsapp_accounts WHERE business_id=$1 ORDER BY id LIMIT 1)
                         AND NOT EXISTS (SELECT 1 FROM coexistence.whatsapp_accounts WHERE business_id=$1 AND is_default)`, [b.id]);
    await audit(b.id, req.user.id, 'whatsapp.removed', { accountId: req.params.accId });
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to remove number' });
  }
});

/* ------------------------------ automations ----------------------------- */

router.post('/businesses/:id/automations', async (req, res) => {
  try {
    const b = await loadBusiness(req, res, { needManager: true }); if (!b) return;
    const name = String(req.body?.name || '').trim() || `${b.name} – Automation`;
    const bot = await createAutomation(pool, b.id, { name, templateId: req.body?.templateId });
    await audit(b.id, req.user.id, 'automation.created', { name });
    res.status(201).json(bot);
  } catch (err) {
    if (err.status) return res.status(err.status).json({ error: err.message });
    res.status(500).json({ error: 'Failed to create automation' });
  }
});

/* ------------------------------ team access ----------------------------- */

router.get('/businesses/:id/members', adminOnly, async (req, res) => {
  const b = await loadBusiness(req, res); if (!b) return;
  const { rows } = await pool.query(
    `SELECT m.user_id, m.role, m.permissions, u.display_name, u.email FROM coexistence.business_members m
       JOIN coexistence.forgecrm_users u ON u.id = m.user_id WHERE m.business_id=$1 ORDER BY u.display_name`, [b.id]);
  res.json(rows.map(m => ({ userId: Number(m.user_id), role: normalizeBusinessRole(m.role), ...cleanOverrides(m.permissions), displayName: m.display_name, email: m.email })));
});

router.put('/businesses/:id/members', adminOnly, async (req, res) => {
  const client = await pool.connect();
  try {
    const b = await loadBusiness(req, res); if (!b) { client.release(); return; }
    await client.query('BEGIN');
    // Diffs against existing rows: roles and permission overrides of unchanged members are preserved,
    // and every add / change / removal is written to the audit log in the same transaction.
    const sync = await syncMemberships(client, { by: 'business', id: b.id }, parseDesired(req.body || {}, 'userId'), { actorId: req.user.id });
    await client.query('COMMIT');
    await audit(b.id, req.user.id, 'members.updated', sync);
    res.json({ ok: true, ...sync });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('[businesses] members error:', err.message);
    if (!res.headersSent) res.status(500).json({ error: 'Failed to update team access' });
  } finally {
    client.release();
  }
});

router.get('/businesses/:id/audit-log', adminOnly, async (req, res) => {
  const b = await loadBusiness(req, res); if (!b) return;
  const { rows } = await pool.query(
    `SELECT a.id, a.action, a.details, a.created_at, u.display_name
       FROM coexistence.business_audit_log a LEFT JOIN coexistence.forgecrm_users u ON u.id = a.user_id
      WHERE a.business_id=$1 ORDER BY a.created_at DESC LIMIT 100`, [b.id]);
  res.json(rows.map(r => ({ id: Number(r.id), action: r.action, details: r.details, at: r.created_at, by: r.display_name })));
});

module.exports = { router };
