const test = require('node:test');
const assert = require('node:assert');
const { safeCell, makeLocalizer } = require('../src/util/spreadsheet');
const { safeTz } = require('../src/util/timezone');

test('safeCell neutralises spreadsheet formulas', () => {
  for (const bad of ['=1+1', '+91 98765', '-2+3', '@SUM(A1)', '\t=cmd', '\r=cmd']) {
    assert.ok(safeCell(bad).startsWith("'"), `${JSON.stringify(bad)} should be prefixed`);
  }
  assert.strictEqual(safeCell('Rahul Sharma'), 'Rahul Sharma');
  assert.strictEqual(safeCell(null), '');
  assert.strictEqual(safeCell(42), 42);
  assert.strictEqual(safeCell('a\u0001b'), 'ab'); // control chars XML cannot hold
  assert.strictEqual(safeCell('हिन्दी नाम'), 'हिन्दी नाम'); // UTF-8 untouched
});

test('makeLocalizer shows business-local wall time', () => {
  const toLocal = makeLocalizer('Asia/Kolkata');
  const d = toLocal(new Date('2026-11-17T00:00:00Z')); // 05:30 in India
  assert.strictEqual(d.toISOString(), '2026-11-17T05:30:00.000Z');
  assert.strictEqual(toLocal(null), null);
  assert.strictEqual(toLocal('not a date'), null);
});

test('safeTz maps legacy names Postgres rejects', () => {
  assert.strictEqual(safeTz('Asia/Calcutta'), 'Asia/Kolkata');
  assert.strictEqual(safeTz('Asia/Kolkata'), 'Asia/Kolkata');
  assert.strictEqual(safeTz('Not/AZone'), 'Asia/Kolkata');
  assert.strictEqual(safeTz(''), 'Asia/Kolkata');
});
