const test = require('node:test');
const assert = require('node:assert');
const P = require('../src/permissions');
const { passwordProblem, isKnownDefaultPassword } = require('../src/util/passwordPolicy');
const { buildSpec, parseDesired, hasAssignments } = require('../src/services/memberAccess');

// ── presets ────────────────────────────────────────────────────────────────
test('every preset only references real actions', () => {
  for (const [role, preset] of Object.entries(P.BUSINESS_ROLE_PRESETS)) {
    for (const a of preset.actions) assert.ok(P.ACTIONS.includes(a), `${role} has unknown action ${a}`);
  }
});

test('Analyst is read-only: no reply, edit, send, export-by-default, or settings', () => {
  const a = P.effectiveBusinessActions('analyst', null);
  for (const forbidden of ['chats.reply', 'chats.view', 'customers.edit', 'customers.archive', 'customers.export',
    'campaigns.send', 'settings.edit', 'whatsapp.connect', 'limits.edit', 'automations.edit']) {
    assert.ok(!a.has(forbidden), `analyst must not hold ${forbidden}`);
  }
  assert.ok(a.has('dashboard.view') && a.has('customers.view') && a.has('reports.view'));
});

test('Support Agent can work chats but cannot export, delete customers or change settings', () => {
  const a = P.effectiveBusinessActions('support_agent', null);
  assert.ok(a.has('chats.reply') && a.has('chats.close') && a.has('customers.edit'));
  for (const f of ['customers.export', 'customers.archive', 'settings.edit', 'limits.edit', 'campaigns.send']) assert.ok(!a.has(f), f);
});

test('Business Manager has everything except changing usage limits', () => {
  const a = P.effectiveBusinessActions('business_manager', null);
  assert.strictEqual(a.size, P.ACTIONS.length - 1);
  assert.ok(!a.has('limits.edit'));
});

test('Supervisor reviews errors but cannot reply to customers or edit settings', () => {
  const a = P.effectiveBusinessActions('supervisor', null);
  assert.ok(a.has('errors.view') && a.has('errors.resolve') && a.has('reports.export'));
  assert.ok(!a.has('chats.reply') && !a.has('settings.edit'));
});

// ── legacy roles & overrides ───────────────────────────────────────────────
test('legacy roles map to presets; unknown roles fall back to the least-privileged default', () => {
  assert.strictEqual(P.normalizeBusinessRole('manager'), 'business_manager');
  assert.strictEqual(P.normalizeBusinessRole('agent'), 'support_agent');
  assert.strictEqual(P.normalizeBusinessRole('analyst'), 'analyst');
  assert.strictEqual(P.normalizeBusinessRole('root'), 'support_agent');
  assert.strictEqual(P.normalizeBusinessRole(undefined), 'support_agent');
});

test('grant adds, revoke removes, unknown names are dropped, grant beats revoke', () => {
  const a = P.effectiveBusinessActions('analyst', { grant: ['customers.export', 'nope.nothing'], revoke: ['reports.view'] });
  assert.ok(a.has('customers.export') && !a.has('reports.view') && !a.has('nope.nothing'));
  const both = P.cleanOverrides({ grant: ['chats.reply'], revoke: ['chats.reply'] });
  assert.deepStrictEqual(both, { grant: ['chats.reply'], revoke: [] });
  assert.deepStrictEqual(P.cleanOverrides('garbage'), { grant: [], revoke: [] });
});

test('overridesFromActions round-trips a custom checklist', () => {
  const want = new Set(['dashboard.view', 'customers.view', 'customers.export']);
  const o = P.overridesFromActions('analyst', want);
  const back = P.effectiveBusinessActions('analyst', o);
  assert.deepStrictEqual([...back].sort(), [...want].sort());
});

test('holdsAny accepts a single action or a list', () => {
  const have = new Set(['chats.view']);
  assert.ok(P.holdsAny(have, 'chats.view'));
  assert.ok(P.holdsAny(have, ['customers.view', 'chats.view']));
  assert.ok(!P.holdsAny(have, ['customers.view']));
});

// ── membership spec logic ──────────────────────────────────────────────────
test('buildSpec keeps existing overrides when only the role is unchanged / omitted', () => {
  const existing = { role: 'agent', permissions: { grant: ['customers.export'], revoke: [] } };
  const s = buildSpec({}, existing);
  assert.strictEqual(s.role, 'support_agent');
  assert.deepStrictEqual(s.grant, ['customers.export']);
});

test('buildSpec resets overrides when the role changes without new overrides', () => {
  const existing = { role: 'support_agent', permissions: { grant: ['customers.export'], revoke: [] } };
  const s = buildSpec({ role: 'supervisor' }, existing);
  assert.strictEqual(s.role, 'supervisor');
  assert.deepStrictEqual(s.grant, []);
});

test('buildSpec for a brand-new member defaults to the least-privileged preset', () => {
  assert.strictEqual(buildSpec({}, undefined).role, 'support_agent');
  assert.strictEqual(buildSpec({ role: 'admin' }, undefined).role, 'support_agent'); // cannot self-assign "admin"
});

test('parseDesired accepts assignments, members and legacy businessIds; rejects junk ids', () => {
  const a = parseDesired({ assignments: [{ businessId: 3, role: 'analyst' }, { businessId: 'x' }, { businessId: -1 }] }, 'businessId');
  assert.deepStrictEqual([...a.keys()], [3]);
  const m = parseDesired({ members: [{ userId: 9, role: 'supervisor' }] }, 'userId');
  assert.strictEqual(m.get(9).role, 'supervisor');
  const legacy = parseDesired({ businessIds: [1, 2, '3', 'bad'] }, 'businessId');
  assert.deepStrictEqual([...legacy.keys()], [1, 2, 3]);
  assert.ok(hasAssignments({ businessIds: [] }) && !hasAssignments({ name: 'x' }));
});

// ── password policy ────────────────────────────────────────────────────────
test('password policy rejects short, common, default and email-derived passwords', () => {
  assert.ok(passwordProblem('short'));
  assert.ok(passwordProblem('rarevo@123'));              // the old shipped default
  assert.ok(passwordProblem('Password123'));
  assert.ok(passwordProblem('aaaaaaaaaa'));
  assert.ok(passwordProblem('priya.sharma99!', { email: 'priya.sharma@rarevoindia.com' }));
  assert.ok(passwordProblem('x'.repeat(200)));
  assert.strictEqual(passwordProblem('Tr1cky-Horse-Battery'), null);
  assert.strictEqual(passwordProblem('Tr1cky-Horse-Battery', { email: 'a@b.co' }), null);
});

test('isKnownDefaultPassword flags the shipped default regardless of case', () => {
  assert.ok(isKnownDefaultPassword('Rarevo@123'));
  assert.ok(!isKnownDefaultPassword('Tr1cky-Horse-Battery'));
});
