#!/usr/bin/env node
// Verifies, against the REAL database, that the access-control layer is in place and tenant data is isolated.
//
//   docker compose exec forgecrm-backend node scripts/verifyAccessControl.js
//
// Safe to run on a live system: everything that writes happens inside one transaction that is always
// rolled back, so no data is created or changed. Exit code 0 = all checks passed, 1 = at least one FAIL.

const bcrypt = require('bcryptjs');
const pool = require('../src/db');
const { BUSINESS_ROLES } = require('../src/permissions');

const results = [];
const record = (status, name, detail = '') => {
  results.push({ status, name });
  const icon = status === 'PASS' ? '✔' : status === 'WARN' ? '!' : '✘';
  console.log(`${icon} ${status}  ${name}${detail ? `\n          ${detail}` : ''}`);
};
const pass = (n, d) => record('PASS', n, d);
const fail = (n, d) => record('FAIL', n, d);
const warn = (n, d) => record('WARN', n, d);

async function expectError(client, name, sql, params, code) {
  await client.query('SAVEPOINT s');
  try {
    await client.query(sql, params);
    await client.query('ROLLBACK TO SAVEPOINT s');
    fail(name, 'the statement succeeded but should have been refused');
  } catch (err) {
    await client.query('ROLLBACK TO SAVEPOINT s');
    if (!code || err.code === code) pass(name);
    else fail(name, `refused with ${err.code} (${err.message}), expected ${code}`);
  }
}

async function main() {
  const client = await pool.connect();
  try {
    // ── 1. Schema ─────────────────────────────────────────────────────────
    const cols = await client.query(
      `SELECT table_name, column_name FROM information_schema.columns
        WHERE table_schema = 'coexistence'
          AND ((table_name = 'business_members' AND column_name = 'permissions')
            OR (table_name = 'forgecrm_users' AND column_name IN ('token_version','password_changed_at','must_change_password')))`);
    const have = new Set(cols.rows.map(r => `${r.table_name}.${r.column_name}`));
    for (const c of ['business_members.permissions', 'forgecrm_users.token_version', 'forgecrm_users.password_changed_at', 'forgecrm_users.must_change_password']) {
      have.has(c) ? pass(`migration 063 column ${c}`) : fail(`migration 063 column ${c}`, 'missing — migration 063 has not been applied');
    }

    // ── 2. Roles, audit immutability (all inside one rolled-back transaction) ──
    await client.query('BEGIN');
    const stamp = Date.now();
    const biz = (await client.query(
      `INSERT INTO coexistence.businesses (name, slug) VALUES ($1, $2) RETURNING id`,
      [`__verify_${stamp}`, `verify-${stamp}`])).rows[0].id;
    const usr = (await client.query(
      `INSERT INTO coexistence.forgecrm_users (username, email, password, display_name, role)
       VALUES ($1, $1, 'x', 'verify', 'bda_sales') RETURNING id, token_version`, [`verify_${stamp}@example.invalid`])).rows[0];
    usr.token_version === 0 ? pass('new users start at token_version 0') : fail('new users start at token_version 0', `got ${usr.token_version}`);

    for (const role of [...BUSINESS_ROLES, 'manager', 'agent']) {
      await client.query('SAVEPOINT r');
      try {
        await client.query(`DELETE FROM coexistence.business_members WHERE business_id = $1 AND user_id = $2`, [biz, usr.id]);
        await client.query(`INSERT INTO coexistence.business_members (business_id, user_id, role) VALUES ($1,$2,$3)`, [biz, usr.id, role]);
        await client.query('RELEASE SAVEPOINT r');
        pass(`business_members accepts role '${role}'`);
      } catch (err) {
        await client.query('ROLLBACK TO SAVEPOINT r');
        fail(`business_members accepts role '${role}'`, err.message);
      }
    }
    await expectError(client, `business_members rejects an unknown role`,
      `UPDATE coexistence.business_members SET role = 'root' WHERE business_id = $1 AND user_id = $2`, [biz, usr.id], '23514');

    const aud = (await client.query(
      `INSERT INTO coexistence.business_audit_log (business_id, user_id, action, details) VALUES ($1,$2,'verify.test','{}') RETURNING id`,
      [biz, usr.id])).rows[0].id;
    await expectError(client, 'business_audit_log: UPDATE is blocked (append-only)',
      `UPDATE coexistence.business_audit_log SET action = 'tampered' WHERE id = $1`, [aud], '42501');
    await expectError(client, 'business_audit_log: DELETE is blocked (append-only)',
      `DELETE FROM coexistence.business_audit_log WHERE id = $1`, [aud], '42501');
    const uaud = (await client.query(
      `INSERT INTO coexistence.user_audit_log (actor_user_id, actor_username, action) VALUES ($1,'verify','verify.test') RETURNING id`, [usr.id])).rows[0].id;
    await expectError(client, 'user_audit_log: UPDATE is blocked (append-only)',
      `UPDATE coexistence.user_audit_log SET action = 'tampered' WHERE id = $1`, [uaud], '42501');
    await expectError(client, 'user_audit_log: DELETE is blocked (append-only)',
      `DELETE FROM coexistence.user_audit_log WHERE id = $1`, [uaud], '42501');

    // Deleting a business must still work (its audit rows go with it via ON DELETE CASCADE).
    try {
      await client.query('SAVEPOINT c');
      await client.query(`DELETE FROM coexistence.businesses WHERE id = $1`, [biz]);
      await client.query('RELEASE SAVEPOINT c');
      pass('deleting a business still cascades through its audit rows');
    } catch (err) {
      await client.query('ROLLBACK TO SAVEPOINT c');
      fail('deleting a business still cascades through its audit rows', err.message);
    }
    // Deleting a user must still work (audit actor reference is nulled by the FK, not blocked).
    try {
      await client.query('SAVEPOINT u');
      await client.query(`DELETE FROM coexistence.forgecrm_users WHERE id = $1`, [usr.id]);
      await client.query('RELEASE SAVEPOINT u');
      pass('deleting a user is not blocked by the audit trigger');
    } catch (err) {
      await client.query('ROLLBACK TO SAVEPOINT u');
      fail('deleting a user is not blocked by the audit trigger', err.message);
    }
    await client.query('ROLLBACK');

    // ── 3. Tenant isolation (Row Level Security) ──────────────────────────
    const tenantTables = (await client.query(
      `SELECT c.relname AS t FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
         JOIN pg_attribute a ON a.attrelid = c.oid AND a.attname = 'business_id' AND NOT a.attisdropped
        WHERE n.nspname = 'coexistence' AND c.relkind = 'r' ORDER BY c.relname`)).rows.map(r => r.t);
    const rls = new Map((await client.query(
      `SELECT c.relname AS t, c.relrowsecurity AS on FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'coexistence' AND c.relkind = 'r'`)).rows.map(r => [r.t, r.on]));
    const policies = (await client.query(
      `SELECT tablename, policyname, qual, with_check FROM pg_policies WHERE schemaname = 'coexistence'`)).rows;
    // Platform-level tables carry a business_id for attribution but are only ever read by platform code.
    const PLATFORM_LEVEL = new Set(['business_audit_log', 'business_members']);

    const unprotected = tenantTables.filter(t => !rls.get(t) && !PLATFORM_LEVEL.has(t));
    unprotected.length === 0
      ? pass(`all ${tenantTables.length - PLATFORM_LEVEL.size} tenant tables have Row Level Security enabled`)
      : fail('every table with business_id has Row Level Security', `NOT protected: ${unprotected.join(', ')}`);

    const noCheck = policies.filter(p => p.policyname === 'tenant_isolation' && !p.with_check && !PLATFORM_LEVEL.has(p.tablename)
      && !['businesses'].includes(p.tablename)).map(p => p.tablename);
    noCheck.length === 0
      ? pass('tenant policies carry WITH CHECK (a business cannot write rows into another business)')
      : fail('tenant policies carry WITH CHECK', `missing on: ${noCheck.join(', ')}`);

    // Live behaviour: act exactly like the app does (SET ROLE forgechat_tenant + app.business_id).
    const bizIds = (await client.query(`SELECT id FROM coexistence.businesses WHERE deleted_at IS NULL ORDER BY id`)).rows.map(r => Number(r.id));
    const protectedTables = tenantTables.filter(t => rls.get(t) && !PLATFORM_LEVEL.has(t));
    if (bizIds.length < 2) {
      warn('cross-business visibility test', 'needs at least 2 businesses in the database — create a second one and re-run');
    }
    for (const t of ['__fail_closed__', ...(bizIds.length ? [bizIds[0]] : [])]) {
      await client.query('BEGIN');
      try {
        await client.query('SET LOCAL ROLE forgechat_tenant');
        if (t !== '__fail_closed__') await client.query(`SELECT set_config('app.business_id', $1, true)`, [String(t)]);
        let leaks = [];
        for (const tbl of protectedTables) {
          const q = t === '__fail_closed__'
            ? `SELECT COUNT(*)::int AS n FROM coexistence."${tbl}"`
            : `SELECT COUNT(*)::int AS n FROM coexistence."${tbl}" WHERE business_id <> $1`;
          const n = (await client.query(q, t === '__fail_closed__' ? [] : [t])).rows[0].n;
          if (n > 0) leaks.push(`${tbl} (${n} rows)`);
        }
        leaks.length === 0
          ? pass(t === '__fail_closed__' ? 'with no business selected, the tenant role sees NO tenant rows' : `inside business #${t}, no other business's rows are visible in any of ${protectedTables.length} tables`)
          : fail(t === '__fail_closed__' ? 'tenant role must see nothing without a business context' : `business #${t} can see other businesses' rows`, leaks.join(', '));
      } finally {
        await client.query('ROLLBACK');
      }
    }

    // ── 4. Known default passwords ────────────────────────────────────────
    const admins = (await client.query(`SELECT email, password FROM coexistence.forgecrm_users WHERE role = 'admin'`)).rows;
    for (const a of admins) {
      let weak = null;
      for (const pw of ['rarevo@123', 'admin123', 'password']) { if (await bcrypt.compare(pw, a.password)) { weak = pw; break; } }
      weak ? fail(`admin ${a.email} password`, `still uses the known default "${weak}" — change it (avatar menu → Change password)`)
           : pass(`admin ${a.email} does not use a known default password`);
    }
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch { /* already rolled back */ }
    fail('verification script', err.message);
  } finally {
    client.release();
    await pool.end().catch(() => {});
  }

  const f = results.filter(r => r.status === 'FAIL').length, w = results.filter(r => r.status === 'WARN').length;
  console.log(`\n${results.length - f - w} passed, ${f} failed, ${w} warnings`);
  process.exit(f ? 1 : 0);
}

main();
