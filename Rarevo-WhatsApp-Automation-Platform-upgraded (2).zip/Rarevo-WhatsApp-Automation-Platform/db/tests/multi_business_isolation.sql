SET search_path TO coexistence;
-- platform (owner) creates two businesses
INSERT INTO businesses(id,name,slug) VALUES (2,'Acme','acme'),(3,'Beta','beta');
SELECT seed_business_defaults(2); SELECT seed_business_defaults(3);
INSERT INTO whatsapp_accounts(display_name,display_phone_number,phone_number_id,waba_id,access_token_encrypted,is_default,business_id) VALUES ('A','111','pnA','wA','x',true,2),('B','222','pnB','wB','x',true,3);
-- second WhatsApp number in same business now allowed
INSERT INTO whatsapp_accounts(display_name,display_phone_number,phone_number_id,waba_id,access_token_encrypted,is_default,business_id) VALUES ('A2','112','pnA2','wA','x',false,2);
BEGIN; SET LOCAL ROLE forgechat_tenant; SET LOCAL app.business_id='2';
  INSERT INTO contacts(wa_number,contact_number,name) VALUES ('111','999','Alice');  -- default business_id
  INSERT INTO chatbots(name) VALUES ('flow A');
  SELECT 'tenant2 sees accounts' k, count(*) FROM whatsapp_accounts;
  SELECT 'tenant2 pipelines' k, count(*) FROM pipelines;
  SELECT 'tenant2 businesses' k, count(*) FROM businesses;
COMMIT;
BEGIN; SET LOCAL ROLE forgechat_tenant; SET LOCAL app.business_id='3';
  SELECT 'tenant3 sees contacts' k, count(*) FROM contacts;
  SELECT 'tenant3 sees chatbots' k, count(*) FROM chatbots;
  SELECT 'tenant3 accounts' k, count(*) FROM whatsapp_accounts;
  UPDATE contacts SET name='hacked'; -- affects 0 rows
  DELETE FROM chatbots;
COMMIT;
BEGIN; SET LOCAL ROLE forgechat_tenant; SET LOCAL app.business_id='3';
  INSERT INTO contacts(wa_number,contact_number,name,business_id) VALUES ('222','1','x',2); -- must fail
ROLLBACK;
SELECT 'owner view contacts' k, name, business_id FROM contacts;
SELECT 'owner chatbots' k, count(*) FROM chatbots;
SELECT 'old data business' k, business_id, count(*) FROM pipelines GROUP BY business_id ORDER BY 2;
BEGIN; SET LOCAL ROLE forgechat_tenant; -- no context
  SELECT 'no-context contacts' k, count(*) FROM contacts;
ROLLBACK;
