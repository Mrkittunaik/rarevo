-- 063: Access control (Phase 2)
--   1. Business-level role presets + per-member permission overrides
--   2. Session revocation (token_version)
--   3. Append-only audit logs
-- Additive and idempotent. Existing members keep exactly the capabilities they had.

-- ── 1. Business roles ──────────────────────────────────────────────────────
ALTER TABLE coexistence.business_members DROP CONSTRAINT IF EXISTS business_members_role_check;

ALTER TABLE coexistence.business_members
  ADD COLUMN IF NOT EXISTS permissions JSONB NOT NULL DEFAULT '{}'::jsonb;   -- { "grant": [...], "revoke": [...] }

ALTER TABLE coexistence.business_members
  ADD CONSTRAINT business_members_role_check
  CHECK (role IN ('manager','agent',                                         -- legacy names, still accepted
                  'business_manager','supervisor','support_agent','campaign_manager','analyst'));

-- Map legacy roles onto the new presets. Before this migration the business role was not
-- enforced anywhere, so an 'agent' could export and delete customers through the page-level
-- permissions. Grant those explicitly so nobody silently loses a capability.
UPDATE coexistence.business_members
   SET role = 'support_agent',
       permissions = '{"grant":["customers.archive","customers.export","reports.view"]}'::jsonb
 WHERE role = 'agent' AND permissions = '{}'::jsonb;

UPDATE coexistence.business_members
   SET role = 'business_manager'
 WHERE role = 'manager';

ALTER TABLE coexistence.business_members ALTER COLUMN role SET DEFAULT 'support_agent';

-- ── 2. Session revocation ──────────────────────────────────────────────────
-- A JWT carries the version it was issued with. Bumping token_version (password change or reset,
-- deactivation, role change, access removal) invalidates every session for that user at once.
ALTER TABLE coexistence.forgecrm_users
  ADD COLUMN IF NOT EXISTS token_version INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS password_changed_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS must_change_password BOOLEAN NOT NULL DEFAULT FALSE;  -- soft nag in the UI until the user picks their own

-- ── 3. Append-only audit logs ──────────────────────────────────────────────
-- Normal code can INSERT but never UPDATE or DELETE audit rows. Two deliberate exceptions:
--   * referential actions (ON DELETE CASCADE / SET NULL when a business or user is removed) run one
--     trigger level deeper and are allowed;
--   * a retention job may opt in with:  SET LOCAL rarevo.allow_audit_purge = 'on'
CREATE OR REPLACE FUNCTION coexistence.audit_log_immutable() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF pg_trigger_depth() > 1 OR current_setting('rarevo.allow_audit_purge', true) = 'on' THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
  END IF;
  RAISE EXCEPTION 'Audit log rows are append-only (% on %.% is not allowed)', TG_OP, TG_TABLE_SCHEMA, TG_TABLE_NAME
    USING ERRCODE = 'insufficient_privilege';
END;
$$;

DROP TRIGGER IF EXISTS trg_business_audit_immutable ON coexistence.business_audit_log;
CREATE TRIGGER trg_business_audit_immutable
  BEFORE UPDATE OR DELETE ON coexistence.business_audit_log
  FOR EACH ROW EXECUTE FUNCTION coexistence.audit_log_immutable();

DROP TRIGGER IF EXISTS trg_user_audit_immutable ON coexistence.user_audit_log;
CREATE TRIGGER trg_user_audit_immutable
  BEFORE UPDATE OR DELETE ON coexistence.user_audit_log
  FOR EACH ROW EXECUTE FUNCTION coexistence.audit_log_immutable();
