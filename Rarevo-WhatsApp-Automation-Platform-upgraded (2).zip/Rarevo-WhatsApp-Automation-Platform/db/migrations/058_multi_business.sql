-- 058: Multi-business (multi-tenant) platform.
--
-- ForgeChat becomes an agency-run platform: ONE install serves MANY client
-- businesses. Each business has its own WhatsApp Cloud API number(s), contacts,
-- chats, automations, templates, broadcasts, pipelines (CRM), agents and media.
--
-- Isolation model (defence in depth):
--   1. Every tenant table gets business_id (NOT NULL, FK -> businesses).
--   2. The app tells Postgres which business a request/job belongs to through the
--      session setting  app.business_id  (see backend/src/db.js + tenant.js).
--      business_id DEFAULTs to that setting, so existing INSERTs need no change.
--   3. Row Level Security on every tenant table, enforced for the NOLOGIN role
--      forgechat_tenant. The app does `SET ROLE forgechat_tenant` whenever a
--      business context is active, so a query that forgets a WHERE clause still
--      cannot see another business's rows.
--   4. With NO business context the app connects as its normal (owner) role and
--      is "platform level": used by the businesses dashboard, auth, webhook
--      routing, schedulers.
--
-- Existing single-business data is backfilled into business #1.
-- Additive + idempotent.

-- ── 1. Core tables ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS coexistence.businesses (
  id             BIGSERIAL PRIMARY KEY,
  name           TEXT NOT NULL,
  slug           TEXT NOT NULL UNIQUE,
  logo_url       TEXT,
  industry       TEXT,
  website        TEXT,
  contact_name   TEXT,
  contact_email  TEXT,
  contact_phone  TEXT,
  address        TEXT,
  timezone       TEXT NOT NULL DEFAULT 'Asia/Kolkata',
  notes          TEXT,
  status         TEXT NOT NULL DEFAULT 'onboarding'
                   CHECK (status IN ('onboarding','active','paused','archived')),
  plan           TEXT NOT NULL DEFAULT 'starter',
  monthly_message_limit INT,
  crm_connected  BOOLEAN NOT NULL DEFAULT FALSE,
  crm_settings   JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_by     BIGINT REFERENCES coexistence.forgecrm_users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_businesses_status ON coexistence.businesses(status) WHERE deleted_at IS NULL;

-- Which of OUR team members may work inside which business.
-- (Platform admins implicitly see every business; they need no row.)
CREATE TABLE IF NOT EXISTS coexistence.business_members (
  id           BIGSERIAL PRIMARY KEY,
  business_id  BIGINT NOT NULL REFERENCES coexistence.businesses(id) ON DELETE CASCADE,
  user_id      BIGINT NOT NULL REFERENCES coexistence.forgecrm_users(id) ON DELETE CASCADE,
  role         TEXT NOT NULL DEFAULT 'agent' CHECK (role IN ('manager','agent')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (business_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_business_members_user ON coexistence.business_members(user_id);

-- Who changed what, per business (platform-level, not tenant-scoped).
CREATE TABLE IF NOT EXISTS coexistence.business_audit_log (
  id           BIGSERIAL PRIMARY KEY,
  business_id  BIGINT REFERENCES coexistence.businesses(id) ON DELETE CASCADE,
  user_id      BIGINT REFERENCES coexistence.forgecrm_users(id) ON DELETE SET NULL,
  action       TEXT NOT NULL,
  details      JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_business_audit_biz ON coexistence.business_audit_log(business_id, created_at DESC);

-- Starter automation library (global). "Clone to business" copies one of these.
CREATE TABLE IF NOT EXISTS coexistence.automation_templates (
  id           BIGSERIAL PRIMARY KEY,
  name         TEXT NOT NULL UNIQUE,
  description  TEXT,
  category     TEXT NOT NULL DEFAULT 'general',
  config       JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO coexistence.automation_templates (name, description, category, config) VALUES
 ('Welcome message', 'Greets anyone who says hi / hello.', 'general',
  '{"nodes":[
     {"id":"n1","type":"trigger","x":80,"y":120,"title":"Trigger","sub":"Keyword","triggerKind":"keyword","keyword":"hi","matchType":"exact","caseSensitive":false},
     {"id":"n2","type":"message","x":380,"y":120,"title":"Message","sub":"Welcome","templateId":"","bindings":{},"messageMode":"direct","directType":"text","directData":{"body":"Hello! 👋 Thanks for contacting us. How can we help you today?"}}
   ],"edges":[{"from":"n1","to":"n2","fromHandle":"default"}]}'::jsonb),
 ('Business hours & contact', 'Replies to "hours" with opening hours and contact info.', 'support',
  '{"nodes":[
     {"id":"n1","type":"trigger","x":80,"y":120,"title":"Trigger","sub":"Keyword","triggerKind":"keyword","keyword":"hours","matchType":"contains","caseSensitive":false},
     {"id":"n2","type":"message","x":380,"y":120,"title":"Message","sub":"Hours","templateId":"","bindings":{},"messageMode":"direct","directType":"text","directData":{"body":"We are open Mon–Sat, 9:00 AM – 6:00 PM. Reply with your question and our team will get back to you."}}
   ],"edges":[{"from":"n1","to":"n2","fromHandle":"default"}]}'::jsonb),
 ('Price / enquiry capture', 'Replies to "price" and asks for details so the team can follow up.', 'sales',
  '{"nodes":[
     {"id":"n1","type":"trigger","x":80,"y":120,"title":"Trigger","sub":"Keyword","triggerKind":"keyword","keyword":"price","matchType":"contains","caseSensitive":false},
     {"id":"n2","type":"message","x":380,"y":120,"title":"Message","sub":"Ask details","templateId":"","bindings":{},"messageMode":"direct","directType":"text","directData":{"body":"Thanks for your interest! Please share your name and what you are looking for, and our team will send you the best price shortly."}}
   ],"edges":[{"from":"n1","to":"n2","fromHandle":"default"}]}'::jsonb)
ON CONFLICT (name) DO NOTHING;

-- Business #1 holds everything that existed before multi-business support.
INSERT INTO coexistence.businesses (id, name, slug, status, plan)
VALUES (1, 'Default Business', 'default', 'active', 'internal')
ON CONFLICT (id) DO NOTHING;
SELECT setval(pg_get_serial_sequence('coexistence.businesses', 'id'),
              GREATEST((SELECT MAX(id) FROM coexistence.businesses), 1));

-- ── 2. Context helper ──────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION coexistence.current_business_id() RETURNS BIGINT
LANGUAGE sql STABLE AS
$$ SELECT NULLIF(current_setting('app.business_id', true), '')::BIGINT $$;

-- ── 3. Tenant role (RLS is enforced for this role) ─────────────────────────
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'forgechat_tenant') THEN
    CREATE ROLE forgechat_tenant NOLOGIN NOBYPASSRLS;
  END IF;
  -- The login role the app uses must be allowed to SET ROLE to it.
  EXECUTE format('GRANT forgechat_tenant TO %I', current_user);
EXCEPTION WHEN insufficient_privilege THEN
  RAISE EXCEPTION 'Cannot create/grant role forgechat_tenant. Run once as a superuser: CREATE ROLE forgechat_tenant NOLOGIN; GRANT forgechat_tenant TO %;', current_user;
END $$;

-- ── 4. Add business_id + RLS to every tenant table ─────────────────────────
DO $$
DECLARE
  t text;
  tenant_tables text[] := ARRAY[
    'contacts','chat_history','categories','tags','contact_field_definitions',
    'message_templates','message_template_revisions','message_template_analytics_daily',
    'broadcasts','broadcast_logs','broadcast_variable_mapping',
    'chatbots','automation_executions','automation_execution_steps',
    'media_library','media_meta_sync','whatsapp_accounts','ai_models',
    'agents','agent_tools','agent_runs','agent_run_steps',
    'wa_links','conversation_reads','message_reactions',
    'pipelines','pipeline_stages','deals',
    'google_oauth_credentials','oauth_credentials','mcp_api_keys'
  ];
BEGIN
  FOREACH t IN ARRAY tenant_tables LOOP
    IF to_regclass('coexistence.' || t) IS NULL THEN
      RAISE NOTICE 'skip %, table does not exist', t;
      CONTINUE;
    END IF;

    EXECUTE format('ALTER TABLE coexistence.%I ADD COLUMN IF NOT EXISTS business_id BIGINT', t);
    EXECUTE format('UPDATE coexistence.%I SET business_id = 1 WHERE business_id IS NULL', t);
    EXECUTE format('ALTER TABLE coexistence.%I ALTER COLUMN business_id SET DEFAULT coexistence.current_business_id()', t);
    EXECUTE format('ALTER TABLE coexistence.%I ALTER COLUMN business_id SET NOT NULL', t);
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint
       WHERE conname = t || '_business_fk' AND conrelid = ('coexistence.' || t)::regclass
    ) THEN
      EXECUTE format(
        'ALTER TABLE coexistence.%I ADD CONSTRAINT %I FOREIGN KEY (business_id) REFERENCES coexistence.businesses(id) ON DELETE CASCADE',
        t, t || '_business_fk');
    END IF;
    EXECUTE format('CREATE INDEX IF NOT EXISTS %I ON coexistence.%I (business_id)', 'idx_' || t || '_business', t);

    EXECUTE format('ALTER TABLE coexistence.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON coexistence.%I', t);
    EXECUTE format(
      'CREATE POLICY tenant_isolation ON coexistence.%I TO forgechat_tenant
         USING (business_id = coexistence.current_business_id())
         WITH CHECK (business_id = coexistence.current_business_id())', t);
  END LOOP;
END $$;

-- The tenant role may only see its OWN business row / memberships.
ALTER TABLE coexistence.businesses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation ON coexistence.businesses;
CREATE POLICY tenant_isolation ON coexistence.businesses TO forgechat_tenant
  USING (id = coexistence.current_business_id());

ALTER TABLE coexistence.business_members ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS tenant_isolation ON coexistence.business_members;
CREATE POLICY tenant_isolation ON coexistence.business_members TO forgechat_tenant
  USING (business_id = coexistence.current_business_id());

-- ── 5. Per-business uniqueness instead of global singletons ────────────────
-- 041 capped the whole install at ONE WhatsApp account. Now: any number of
-- accounts, at most one default PER BUSINESS.
DROP INDEX IF EXISTS coexistence.whatsapp_accounts_singleton;
DROP INDEX IF EXISTS coexistence.idx_whatsapp_accounts_one_default;
CREATE UNIQUE INDEX IF NOT EXISTS idx_whatsapp_accounts_one_default_per_business
  ON coexistence.whatsapp_accounts (business_id) WHERE is_default = TRUE;

-- ── 6. Privileges for the tenant role ──────────────────────────────────────
GRANT USAGE ON SCHEMA coexistence TO forgechat_tenant;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA coexistence TO forgechat_tenant;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA coexistence TO forgechat_tenant;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA coexistence TO forgechat_tenant;
ALTER DEFAULT PRIVILEGES IN SCHEMA coexistence
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO forgechat_tenant;
ALTER DEFAULT PRIVILEGES IN SCHEMA coexistence
  GRANT USAGE, SELECT ON SEQUENCES TO forgechat_tenant;
-- Platform-only tables: tenant role must not touch them.
REVOKE ALL ON coexistence.business_audit_log FROM forgechat_tenant;
REVOKE ALL ON coexistence.automation_templates FROM forgechat_tenant;
GRANT SELECT ON coexistence.automation_templates TO forgechat_tenant;
GRANT USAGE ON SCHEMA public TO forgechat_tenant;

-- ── 7. Seed helper: default CRM pipeline for a new business ────────────────
CREATE OR REPLACE FUNCTION coexistence.seed_business_defaults(bid BIGINT) RETURNS VOID
LANGUAGE plpgsql AS $$
DECLARE pid BIGINT;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM coexistence.pipelines WHERE business_id = bid) THEN
    INSERT INTO coexistence.pipelines (name, is_default, position, business_id)
      VALUES ('Sales Pipeline', TRUE, 0, bid) RETURNING id INTO pid;
    INSERT INTO coexistence.pipeline_stages (pipeline_id, name, probability, position, stage_type, color, business_id) VALUES
      (pid, 'New Lead',      10, 0, 'open', '#3B82F6', bid),
      (pid, 'Qualified',     30, 1, 'open', '#EAB308', bid),
      (pid, 'Proposal Sent', 50, 2, 'open', '#F97316', bid),
      (pid, 'Negotiation',   70, 3, 'open', '#A855F7', bid),
      (pid, 'Won',          100, 4, 'won',  '#16A34A', bid),
      (pid, 'Lost',           0, 5, 'lost', '#DC2626', bid);
  END IF;
END $$;
