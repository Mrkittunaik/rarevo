-- 062: Optional per-business daily cap on OUTGOING WhatsApp messages (NULL = unlimited).
-- Counted per calendar day in the business's own timezone; failed sends don't count.
ALTER TABLE coexistence.businesses ADD COLUMN IF NOT EXISTS daily_message_limit INTEGER;
ALTER TABLE coexistence.businesses DROP CONSTRAINT IF EXISTS businesses_daily_message_limit_pos;
ALTER TABLE coexistence.businesses ADD CONSTRAINT businesses_daily_message_limit_pos
  CHECK (daily_message_limit IS NULL OR daily_message_limit > 0);
