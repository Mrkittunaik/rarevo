-- 059: indexes so the platform stays fast with hundreds–thousands of businesses.
CREATE INDEX IF NOT EXISTS idx_chat_history_business_ts ON coexistence.chat_history (business_id, timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_contacts_business_created ON coexistence.contacts (business_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_chatbots_business_status ON coexistence.chatbots (business_id, status);
CREATE INDEX IF NOT EXISTS idx_message_templates_business_status ON coexistence.message_templates (business_id, status);
CREATE INDEX IF NOT EXISTS idx_whatsapp_accounts_business ON coexistence.whatsapp_accounts (business_id);
CREATE INDEX IF NOT EXISTS idx_businesses_created ON coexistence.businesses (created_at DESC) WHERE deleted_at IS NULL;
