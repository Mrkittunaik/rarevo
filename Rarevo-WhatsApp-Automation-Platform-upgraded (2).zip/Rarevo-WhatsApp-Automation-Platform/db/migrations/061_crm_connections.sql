-- 061: External CRM connections (one per business).
-- Rarevo generates an API key + API password for a business. The external CRM
-- uses them to READ that business's leads. Credentials are stored (encrypted for
-- re-display, hashed for lookup) until the connection is disconnected, which
-- deletes the row.
CREATE TABLE IF NOT EXISTS coexistence.crm_connections (
  business_id     BIGINT PRIMARY KEY REFERENCES coexistence.businesses(id) ON DELETE CASCADE,
  key_prefix      TEXT NOT NULL,
  key_last4       TEXT NOT NULL,
  key_hash        TEXT NOT NULL UNIQUE,
  key_encrypted   TEXT NOT NULL,
  secret_hash     TEXT NOT NULL,
  secret_encrypted TEXT NOT NULL,
  is_active       BOOLEAN NOT NULL DEFAULT TRUE,
  connected_by    BIGINT REFERENCES coexistence.forgecrm_users(id) ON DELETE SET NULL,
  connected_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  rotated_at      TIMESTAMPTZ,
  last_used_at    TIMESTAMPTZ,
  request_count   BIGINT NOT NULL DEFAULT 0
);
