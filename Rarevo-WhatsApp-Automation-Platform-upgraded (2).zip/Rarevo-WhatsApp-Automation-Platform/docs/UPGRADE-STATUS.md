# Rarevo upgrade — audit and status

Last updated: 2026-11-18. This tracks the "complete multi-business platform" upgrade against the repository as it actually is.

## Phase 1 — audit findings

Verified by reading the code and migrations (not by running a full stack).

| Area | Current state | Gap vs. requirement |
|---|---|---|
| Multi-tenancy | Solid: `tenantMiddleware`, `forgechat_tenant` role, RLS on tenant tables (migration 058), AsyncLocalStorage context | Only `admin` / `business_members.role` checked; no granular permissions |
| Roles | `admin`, `bda_sales`, `viewer` + page map. Business role (`manager`/`agent`) **was not enforced anywhere** | **Phase 2:** 5 business role presets + 30 action permissions + per-member overrides, enforced server-side (see `docs/ACCESS-CONTROL.md`) |
| Access revocation | `requirePermission` reloads the user row each call (good). Tenant check reloads `business_members` each request (good) | JWT is not invalidated on deactivation unless every route re-checks `is_active` — needs verification |
| Default credentials | Was: `rarevo@123` seeded automatically | **Fixed in Phase 2** — no built-in password; existing accounts still on it are flagged and nagged |
| Daily limit | Enforced in the shared sender (`messageSender.js`) | Counts via `COUNT(*)` on every send: not atomic under concurrency |
| Monthly limit | Column `monthly_message_limit` existed and was editable, but **never enforced** | Done in this drop (see below); atomic reservation still open |
| Error logging | `console.error` plus `webhook_events.processing_error` | **No persistent, searchable per-business error log** (Phase 3) |
| Health monitoring | `accountHealth.js` (WhatsApp account only) | No Redis/Postgres/queue/AI/Google health model |
| Audit | `business_audit_log` (business-level), `user_audit_log` (platform) | Needs more action coverage + append-only enforcement |
| Records page | Aggregates `chat_history` per customer; **CSV built in the browser, capped at 500 rows** | Real XLSX, full-range export (done), customer detail view (open) |
| Records authorization | `/records` had **no permission check and no per-user scoping** | Fixed in this drop |
| Notifications | None | Phase 7 |
| Capacity / load testing | None | Phase 4 |
| Timezones | Browser zone passed straight to Postgres | `Asia/Calcutta` crashed Records (fixed) |
| Migrations | Runner works; file 060 shipped with a UTF-8 BOM | Fixed + runner now strips BOMs |

## Done in this drop

1. **Boot fix** — BOM removed from `060_…sql`; `migrate.js` strips a BOM from any migration.
2. **Timezone fix** — `util/timezone.js` maps legacy zone names; used by Records, the exporter and the sender.
3. **Monthly message limit enforced** in `services/messageSender.js` (all send paths). Counts non-failed outgoing rows since the 1st of the month in the business timezone. Blocks with `MONTHLY_LIMIT`; inbound is unaffected. Daily limit unchanged.
4. **Records authorization** — `/records` now requires the `records` page permission and scopes non-admin users to their assigned numbers/contacts.
5. **Excel / CSV export** — `GET /api/records/export` (`routes/recordsExport.js`): streaming `.xlsx` via ExcelJS (Customer Records, Message Summary, Business Information, Campaign Summary), frozen headers, filters, widths, real date cells in business-local time, formula-injection protection, UTF-8, per-business RLS + user scoping, audit row in `business_audit_log`. Range: today / yesterday / 7d / 30d / all / custom. Hard cap 250,000 customers per export.
6. **Frontend** — Records page "Export" menu (range picker, custom dates, Excel or CSV) replaces the 500-row browser CSV.
7. **Tests** — `test/exportHelpers.test.js` (formula guard, timezone localisation, tz aliasing).

## Phase 2 — security and access (done, needs your stack to verify)

- Business-level roles: Business Manager, Supervisor, Support Agent, Campaign Manager, Analyst; 30 actions; per-member grant/revoke; Team page role picker + permission checklist; legacy roles migrated without losing capabilities.
- `requireAction` enforced on Records, export, dashboard and 19 messaging/contact routes (these had **no** permission checks).
- **Privilege-escalation fix:** a Business Manager could raise their own `monthlyMessageLimit`/plan. Now needs `limits.edit`.
- Membership changes no longer wipe roles; every add/change/removal is audited. Business role is read live per request (immediate revocation).
- Sessions: token versioning (password change/reset/deactivate signs out everywhere), self-service change-password, login rate limit, `must_change_password` banner.
- Removed built-in default password; production refuses the dev JWT secret; password policy; `crypto.randomInt` for generated passwords (was `Math.random`).
- Append-only audit logs (DB trigger; cascades still work).
- Real client IP behind nginx/Caddy (`TRUST_PROXY`) so rate limits and audit IPs are meaningful.
- `scripts/verifyAccessControl.js` — tenant-isolation + access-control verification against the real DB.

Not done in Phase 2: CSRF tokens (cookie is `SameSite=strict`; verify against your deployment), CORS/helmet review, webhook-signature and OAuth review (existing tests cover signature code), file-upload validation review, Business Managers managing their own team (admin-only today), IP in audit rows.

## Not tested yet (needs the Docker stack)

- The exporter against real data, including 10,000+ customers and opening the file in Excel.
- Monthly-limit blocking against a real business.
- The Records scoping change with a non-admin user.
- The frontend build (first compile happens in `docker compose build`).
- Phase 2 end to end: run `scripts/verifyAccessControl.js` and the manual checklist in `docs/ACCESS-CONTROL.md`.
- `test/access.test.js` needs the `pg` package (runs in Docker/CI, not in the authoring sandbox).

## Remaining phases (not started)

- **Phase 3** monitoring: `system_error_logs`, health checks, error UI, business-card three-dot menu, notifications.
- **Phase 4** usage/capacity: atomic usage reservation, 70/85/95/100% warnings, usage charts, metrics, load-test harness.
- **Phase 5 (rest)**: customer detail view, async export jobs with progress, export history.
- **Phase 6** campaign/automation traces and safe retry.
- **Phase 7** platform analytics, team activity, notification centre.
- **Phase 8** tenant-isolation, permission and load test suites against a staging stack.
