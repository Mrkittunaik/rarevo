# Access control

Three levels, all enforced on the server (the UI only mirrors them):

| Level | Who | What it decides |
|---|---|---|
| Platform admin | `forgecrm_users.role = 'admin'` | Everything, in every business. Only admins manage the team, businesses and usage limits by default. |
| Page access | `forgecrm_users.role` + `permissions` JSON (`permissions.js`) | Which *screens* a team member may open at all (Chats, Records, Pipelines, …). |
| Business role | `business_members.role` + `permissions` | Which *actions* the member may perform **inside one business**. A person can be a Supervisor in one business and an Analyst in another. |

## Business roles (presets)

| Role | Intended for | Notable abilities | Cannot |
|---|---|---|---|
| Business Manager | Runs a client business | Settings, WhatsApp connection, integrations, automations, agents, campaigns, customers, reports, errors | Change usage limits (unless granted) |
| Supervisor | Oversees the team | Dashboards, reports + export, error review/resolve, assign/close chats, export customers | Reply to customers, edit settings |
| Support Agent | Handles conversations | View/reply/assign/close chats, view + edit customers | Export, delete customers, settings, campaigns |
| Campaign Manager | Runs campaigns | Create + send campaigns, campaign reports | Chats, settings |
| Analyst | Read-only | Dashboard, analytics, customers, reports, usage | Chats, any change, export |

Any member can be customised per business (grant/revoke). 30 actions in 9 groups: see `GET /api/permissions/catalog`.

Legacy roles are migrated by `063_access_control.sql`: `manager` → Business Manager; `agent` → Support Agent **with** `customers.archive`, `customers.export` and `reports.view` granted, because the old model let agents do those things. Nobody loses a capability they had.

## What is enforced where

- `tenant.js` re-reads the member's `business_members` row **on every request** → removing a member or changing their role/permissions applies on their next call (no token to expire).
- `requireAction(...)` (`middleware/access.js`) guards: Records list, Records export, Dashboard, and all messaging/contact routes (view, reply, edit, import, delete).
- Changing `monthlyMessageLimit`, `dailyMessageLimit` or `plan` requires `limits.edit` (was: any manager could raise their own monthly limit).
- Team and membership changes go through `services/memberAccess.js`: diffed (existing roles are no longer reset), audited to `business_audit_log` in the same transaction.

## Sessions and passwords

- JWT carries `tv` (token version). Password change/reset and deactivation bump `token_version` → signed out everywhere immediately. A user changing their own password keeps their current session.
- Policy: ≥ 8 chars, not a known/default password, must not contain the email name (`util/passwordPolicy.js`).
- Failed logins limited to 10 per 15 min per IP+email.
- Admin-set and default passwords raise `mustChangePassword` → banner + "Change password" in the avatar menu.
- Generated passwords use `crypto.randomInt` (was `Math.random`).
- The app refuses to start in production with the built-in development JWT secret.
- Audit logs are append-only (DB trigger). Business/user hard deletes still cascade.

## Reverse proxies

The real client IP comes from `X-Forwarded-For`. `TRUST_PROXY` = number of proxies in front of the backend: `1` for local compose (nginx), `2` with the production overlay (Caddy → nginx; set automatically).

## Verifying it on your stack

```
docker compose exec forgecrm-backend node scripts/verifyAccessControl.js
```
Checks migration 063, role constraint, audit immutability, that every tenant table has Row Level Security, that a business sees none of another business's rows (and nothing with no business selected), and that no admin still uses a known default password. Everything runs in a rolled-back transaction.

## Manual acceptance checklist

1. Create two businesses, A and B. Create members **Priya** (Supervisor in A) and **Ravi** (Support Agent in A and Analyst in B) in Team.
2. Sign in as Ravi: in A he can reply in Chats; in B Chats is read-only/forbidden and the Export button is hidden.
3. As Ravi, call `POST /api/messages/send` with `X-Business-Id: B` → `403 PERMISSION_DENIED`. Change the header to a business he isn't in → `403 BUSINESS_FORBIDDEN`.
4. As Priya open Records → Export works (Supervisor has `customers.export`); `PUT /api/businesses/A` with `monthlyMessageLimit` → `403` (needs `limits.edit`).
5. As admin, change Ravi's role in A to Analyst. Ravi's **next** request is refused for replies — no re-login needed.
6. As admin, remove Ravi from B. His next request with `X-Business-Id: B` → `403 BUSINESS_FORBIDDEN`.
7. As admin, reset Ravi's password. His old session gets `401 Session expired` on the next request.
8. Business A → Activity (audit log) shows `member.added`, `member.access_changed`, `member.removed`.
