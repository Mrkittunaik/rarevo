# Rarevo — Multi-Business Platform

One Rarevo install now runs MANY client businesses. Your team manages them all;
clients never log in.

## What you get
- **Businesses dashboard** (`#/businesses`, the new home screen): platform totals, one card per
  business (WhatsApp number + health, contacts, 7-day messages, automations, open deals).
- **Add Business wizard**: details → WhatsApp Cloud API (tested live against Meta) → named starter
  automation (blank or from a template) → team access → review. Webhook URL shown at the end.
- **Card ⋮ menu**: Open workspace · Edit details · Connect WhatsApp · Connect to CRM ·
  Add automation · Team access · Pause/Resume · Activity log · Archive.
- **Connect to CRM (per business, view-only)**: the built-in CRM screen was removed. ⋮ → Connect to CRM generates an API URL + API key + API password for that business. Enter them in the Rarevo CRM; it can then READ the business's leads (name, number, tags, last message) via `/api/crm/v1/*` (GET only; headers `Authorization: Bearer <key>` + `X-Api-Password`). Credentials are saved (key/password encrypted) until you Disconnect, which deletes them. Migration 061.
- **Admin login + Team**: there is **no built-in password**. On a fresh install the first-run setup wizard creates the admin account. To pre-seed one for headless installs set **both** `DEFAULT_ADMIN_EMAIL` and `DEFAULT_ADMIN_PASSWORD` (must pass the password policy). Admin dashboard → Team creates member logins and assigns, per business, a role (Business Manager, Supervisor, Support Agent, Campaign Manager, Analyst) with optional per-member permission overrides — see `docs/ACCESS-CONTROL.md`. Members see only the businesses they are assigned to.
- **Workspace switcher** (top bar) + "All businesses" link (sidebar). Opening a business loads the
  existing Chats / Contacts / Pipelines / Automations / Templates / Bulk pages scoped to it.
- **Team access**: admins see everything; other users see only businesses they are assigned to
  (Manager = can edit/connect, Agent = day-to-day work).
- Pausing a business keeps history but stops automations/AI and outbound sends.

- **Daily message limit (per business)**: ⋮ → Edit details → *Daily message limit* (admin only, blank = unlimited). Caps OUTGOING messages per day in the business time zone (automations, AI, chat replies and bulk together; failed sends don't count). Cards show *Sent today X / limit*. Migration 062.

## Scale: 100 → 1000+ businesses
- Dashboard is server-paged (24/page) with debounced search and status filters; stats are computed only
  for the visible page. The top-bar switcher has its own search.
- **Import CSV**: add up to 1000 businesses in one go (template download, per-row errors, optional WhatsApp
  credentials; saved without a live Meta check — verify a card via ⋮ → Connect WhatsApp).
- After creating a business the wizard offers **Add another business** or **Back to dashboard**.
- Migration 059 adds the indexes; schedulers only visit businesses that have work.
- Settings (tags, fields, WhatsApp, integrations, MCP) are per business; only the Users tab is team-wide.

## How isolation works (migration 058)
Every tenant table has `business_id` + Postgres Row Level Security. For each request/job the app runs
`SET ROLE forgechat_tenant; SET app.business_id = N`, so even a query missing a WHERE cannot touch
another business. No context ⇒ inserts fail (NOT NULL) instead of landing in the wrong business.
- `backend/src/tenant.js` — context (AsyncLocalStorage), middleware, `forEachActiveBusiness`.
- `backend/src/db.js` — pool wrapper that applies the context.
- Webhook routes each message by `phone_number_id` → business. BullMQ jobs carry `businessId`.
- MCP API keys and the Google OAuth state are bound to one business.
- Test: `psql -f db/tests/multi_business_isolation.sql` (after migrations).

## Upgrading an existing install
1. Back up the database. 2. Deploy; migrations run on start (058 needs a DB user that can
`CREATE ROLE` — the default docker `postgres` user can; otherwise run
`CREATE ROLE forgechat_tenant NOLOGIN; GRANT forgechat_tenant TO <app_user>;` once as superuser).
3. All existing data becomes **"Default Business"** (id 1). Rename it in the dashboard.
4. Set `PUBLIC_BASE_URL` (optional) so the wizard shows the right webhook URL.

## Adding a client
Dashboard → **Add Business** → fill the wizard. In Meta (one app for all clients) set the callback
`https://<your-domain>/api/webhook/whatsapp` and subscribe to `messages`.

## Not done yet / next
- Not run end-to-end: this build environment had no npm access, so the server/UI were syntax- and
  SQL-checked (migration + RLS tested on real Postgres 16) but not booted. Run `npm test` + a smoke
  test before production.
- Meta Embedded Signup (client self-connect), billing/limits enforcement (`monthly_message_limit`
  is stored, not enforced), per-business webhook secrets, external CRM sync (HubSpot/Zoho),
  re-enabling the parked advanced automation nodes (conditions, delays, API calls).
