import { useState, useEffect } from 'react';
import { api } from './api.js';
import { C, FONT } from './constants.js';
import { useHashRoute } from './hooks/useHashRoute.js';
import LoginGate from './components/LoginGate.jsx';
import SetupWizard from './components/SetupWizard.jsx';
import Topbar from './components/Topbar.jsx';
import ChangePasswordModal, { PasswordBanner } from './components/ChangePasswordModal.jsx';
import Sidebar from './components/Sidebar.jsx';
import ChatsPage from './components/ChatsPage.jsx';
import HomePage from './pages/HomePage.jsx';
import ChatbotBuilderPage from './pages/ChatbotBuilderPage.jsx';
import TemplateBuilderPage from './pages/TemplateBuilderPage.jsx';
import ContactsPage from './pages/ContactsPage.jsx';
import BulkMessagePage from './pages/BulkMessagePage.jsx';
import AdminSettingsPage from './pages/AdminSettingsPage.jsx';
import MediaLibraryPage from './pages/MediaLibraryPage.jsx';
import AboutUsPage from './pages/AboutUsPage.jsx';
import PipelinesPage from './pages/PipelinesPage.jsx';
import AiAgentBuilderPage from './pages/AiAgentBuilderPage.jsx';
import BusinessesPage from './pages/BusinessesPage.jsx';
import RecordsPage from './pages/RecordsPage.jsx';
import TeamPage from './pages/TeamPage.jsx';
import { getBusinessId, setBusinessId, onBusinessChange } from './tenant.js';

const VALID_PAGES = new Set([
  'home', 'chatbot-builder', 'template-builder', 'chats', 'records',
  'contacts', 'pipelines', 'bulk-message', 'admin-settings', 'media-library', 'about',
  'ai-agent-builder', 'businesses', 'team',
]);

// Pages that work without a selected business (platform level).
const PLATFORM_PAGES = new Set(['businesses', 'about', 'team']);
// Settings are per business (WhatsApp, tags, fields, integrations, MCP…) except the team's Users tab.

export default function App() {
  const [user, setUser] = useState(null);
  const [pwOpen, setPwOpen] = useState(false);
  const [checking, setChecking] = useState(true);
  const [setupRequired, setSetupRequired] = useState(false);
  const [routeParts, navigate, replaceRoute] = useHashRoute();
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const [businessId, setBusinessIdState] = useState(getBusinessId());
  const [business, setBusiness] = useState(null);
  useEffect(() => onBusinessChange(setBusinessIdState), []);

  // Load the selected business (name for the switcher/sidebar). If it is gone or
  // forbidden, tenant.js clears the selection and we fall back to the dashboard.
  useEffect(() => {
    if (!user || !businessId) { setBusiness(null); return; }
    let cancelled = false;
    api.businesses.get(businessId)
      .then(b => { if (!cancelled) setBusiness(b); })
      .catch(() => { if (!cancelled) { setBusinessId(''); setBusiness(null); } });
    return () => { cancelled = true; };
  }, [user, businessId]);

  const openBusiness = (id, targetPage = 'home') => {
    setBusinessId(id);
    navigate(targetPage);
  };
  const allBusinesses = () => navigate('businesses');

  const requested = VALID_PAGES.has(routeParts[0]) ? routeParts[0] : null;
  const platformSettings = routeParts[0] === 'admin-settings' && routeParts[1] === 'users';
  // No business chosen → the businesses dashboard is the home screen.
  const page = requested
    ? (!businessId && !PLATFORM_PAGES.has(requested) && !platformSettings ? 'businesses' : requested)
    : (businessId ? 'home' : 'businesses');
  const subParts = routeParts.slice(1);
  const setPage = (p) => navigate(p);

  // Normalize empty hash to #/home so reload always shows a valid URL
  useEffect(() => {
    if (!routeParts[0]) replaceRoute(businessId ? 'home' : 'businesses');
  }, [routeParts, replaceRoute, businessId]);

  // Page guard: non-admins can only reach pages granted to them (user.pages).
  // admin-settings is allowed if they have any admin-settings:* sub-page.
  useEffect(() => {
    if (!user || user.role === 'admin' || !Array.isArray(user.pages)) return;
    if (page === 'businesses') return; // everyone may see the businesses they were given
    if (page === 'team') { setPage('businesses'); return; } // admin only
    const allowed = page === 'admin-settings'
      ? user.pages.some(p => p.startsWith('admin-settings'))
      : user.pages.includes(page);
    if (!allowed) setPage('home');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, user]);

  useEffect(() => {
    // Collapse main sidebar by default on automation builder page
    if (page === 'chatbot-builder') {
      setSidebarCollapsed(true);
    }
  }, [page]);

  useEffect(() => {
    // First check whether the instance needs first-run setup (no users yet).
    // If so, show the setup wizard; otherwise resume the normal session check.
    api.auth.status()
      .then(({ setupRequired: needed }) => {
        if (needed) { setSetupRequired(true); setChecking(false); return null; }
        return api.auth.me()
          .then(({ user }) => setUser(user))
          .catch(() => setUser(null))
          .finally(() => setChecking(false));
      })
      .catch(() => {
        // status unavailable (DB warming) — fall back to a normal session check.
        api.auth.me()
          .then(({ user }) => setUser(user))
          .catch(() => setUser(null))
          .finally(() => setChecking(false));
      });
  }, []);

  const handleLogout = async () => {
    await api.auth.logout().catch(() => {});
    setUser(null);
    setPage('home');
  };

  if (checking) {
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: FONT,
        background: C.pageBg,
      }}>
        <div style={{ fontSize: 13, color: C.textMuted, fontWeight: 500 }}>Loading…</div>
      </div>
    );
  }

  if (setupRequired && !user) {
    return <SetupWizard onComplete={(u) => { setSetupRequired(false); setUser(u); }} />;
  }

  if (!user) {
    return <LoginGate onLogin={setUser} />;
  }

  const renderPage = () => {
    switch (page) {
      case 'businesses': return <BusinessesPage user={user} onOpenBusiness={openBusiness} onNavigate={navigate} />;
      case 'records': return <RecordsPage navigate={navigate} />;
      case 'team': return <TeamPage user={user} navigate={navigate} />;
      case 'home': return <HomePage user={user} onPageChange={setPage} />;
      case 'chats': return <ChatsPage subParts={subParts} navigate={navigate} user={user} />;
      case 'contacts': return <ContactsPage user={user} onNavigate={navigate} />;
      case 'pipelines': return <PipelinesPage user={user} />;
      case 'template-builder': return <TemplateBuilderPage subParts={subParts} navigate={navigate} />;
      case 'media-library': return <MediaLibraryPage />;
      case 'bulk-message': return <BulkMessagePage onNavigate={navigate} />;
      case 'chatbot-builder': return <ChatbotBuilderPage subParts={subParts} navigate={navigate} />;
      case 'ai-agent-builder': return <AiAgentBuilderPage user={user} navigate={navigate} />;
      case 'about': return <AboutUsPage />;
      case 'admin-settings': return <AdminSettingsPage onLogout={handleLogout} onNavigate={setPage} subParts={subParts} navigate={navigate} user={user} />;
      default: return <HomePage user={user} onPageChange={setPage} />;
    }
  };

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      fontFamily: FONT,
      background: C.pageBg,
    }}>
      <Topbar
        user={user} onLogout={handleLogout} onNavigate={setPage}
        business={businessId ? business : null}
        onSelectBusiness={(id) => openBusiness(id, page === 'businesses' ? 'home' : page)}
        onAllBusinesses={allBusinesses}
        onChangePassword={() => setPwOpen(true)}
      />
      <PasswordBanner user={user} onChange={() => setPwOpen(true)} />
      {pwOpen && <ChangePasswordModal onClose={() => setPwOpen(false)} onChanged={() => setUser(u => (u ? { ...u, mustChangePassword: false } : u))} />}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {page !== 'admin-settings' && page !== 'businesses' && page !== 'team' && (
          <Sidebar
            activePage={page}
            onPageChange={setPage}
            collapsed={sidebarCollapsed}
            setCollapsed={setSidebarCollapsed}
            user={user}
            business={business}
            onAllBusinesses={allBusinesses}
          />
        )}
        <div style={{ flex: 1, overflow: 'auto', background: C.pageBg, display: 'flex', flexDirection: 'column' }}>
          {business && businessId && page !== 'businesses' && page !== 'team' && page !== 'about' && !platformSettings && (
            <div style={{
              flexShrink: 0, padding: '7px 18px', fontSize: 12.5, fontFamily: FONT, display: 'flex', gap: 10, alignItems: 'center',
              background: business.status === 'paused' ? '#FEF3C7' : C.surfaceAlt, color: business.status === 'paused' ? '#92400E' : C.textSecondary,
              borderBottom: `1px solid ${C.border}`,
            }}>
              <b style={{ color: business.status === 'paused' ? '#92400E' : C.text }}>{business.name}</b>
              <span>{business.accounts?.[0]?.displayPhoneNumber ? `+${business.accounts[0].displayPhoneNumber}` : 'WhatsApp not connected'}</span>
              {business.status === 'paused' && <span style={{ fontWeight: 700 }}>· Paused — automations, AI agents and sending are off</span>}
              <span style={{ flex: 1 }} />
              <span>Everything on this screen belongs to this business only</span>
            </div>
          )}
          <div key={businessId || 'none'} style={{ flex: 1, display: 'flex', flexDirection: 'column', minHeight: 0, overflow: 'auto' }}>{renderPage()}</div>
        </div>
      </div>
    </div>
  );
}
