import { useState, useEffect, useCallback, useMemo } from 'react';
import { Plus, X, Check, Copy, Pencil, Trash2, Search, Building2, ArrowLeft, KeyRound, Users, SlidersHorizontal } from 'lucide-react';
import { api } from '../api.js';
import { C, FONT, relativeTime } from '../constants.js';

const errMsg = (e) => {
  const raw = String(e?.message || e || 'Something went wrong');
  const m = raw.match(/^\d{3}\s+([\s\S]*)$/); const body = m ? m[1] : raw;
  try { const j = JSON.parse(body); if (j?.error) return j.error; } catch { /* plain */ }
  return body;
};

const btn = (kind = 'ghost', extra = {}) => ({
  height: 36, padding: '0 14px', borderRadius: 3, fontFamily: FONT, fontSize: 13, fontWeight: 600, cursor: 'pointer',
  display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
  border: kind === 'primary' || kind === 'danger' ? 'none' : `1.5px solid ${C.border}`,
  background: kind === 'primary' ? C.primary : kind === 'danger' ? '#DC2626' : C.cardBg,
  color: kind === 'primary' || kind === 'danger' ? '#fff' : C.text, ...extra,
});
const input = {
  width: '100%', height: 38, borderRadius: 3, border: `1.5px solid ${C.border}`, padding: '0 11px', fontFamily: FONT,
  fontSize: 13, background: C.cardBg, color: C.text, boxSizing: 'border-box', outline: 'none',
};
const Label = ({ children }) => <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 5, color: C.text }}>{children}</div>;

function genPassword() {
  const a = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  const arr = new Uint32Array(10); crypto.getRandomValues(arr);
  return [...arr].map(n => a[n % a.length]).join('') + '@7';
}

// Actions held by a role preset, plus a member's grant/revoke overrides.
const actionsFor = (catalog, role, grant = [], revoke = []) => {
  const base = new Set(catalog?.roles?.find(r => r.key === role)?.actions || []);
  grant.forEach(a => base.add(a)); revoke.forEach(a => base.delete(a));
  return base;
};

function MemberModal({ member, businesses, catalog, onClose, onSaved }) {
  const editing = !!member;
  const [name, setName] = useState(member?.name || '');
  const [email, setEmail] = useState(member?.email || '');
  const [password, setPassword] = useState('');
  // businessId -> { role, grant, revoke }  (an entry exists for every business the member can open)
  const defaultRole = catalog?.defaultRole || 'support_agent';
  const [assign, setAssign] = useState(() => Object.fromEntries((member?.assignments || []).map(a => [a.businessId, { role: a.role, grant: a.grant || [], revoke: a.revoke || [] }])));
  const [openCustom, setOpenCustom] = useState(null); // businessId whose permission checklist is expanded
  const ids = useMemo(() => new Set(Object.keys(assign).map(Number)), [assign]);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  const shown = useMemo(() => businesses.filter(b => b.name.toLowerCase().includes(q.toLowerCase())), [businesses, q]);
  const toggle = (id) => setAssign(prev => {
    const n = { ...prev };
    if (n[id]) delete n[id]; else n[id] = { role: defaultRole, grant: [], revoke: [] };
    return n;
  });
  const setRole = (id, role) => setAssign(prev => ({ ...prev, [id]: { role, grant: [], revoke: [] } })); // new preset → clear overrides
  const toggleAction = (id, action) => setAssign(prev => {
    const cur = prev[id]; const have = actionsFor(catalog, cur.role, cur.grant, cur.revoke);
    if (have.has(action)) have.delete(action); else have.add(action);
    // store only the difference from the preset
    const preset = new Set(catalog?.roles?.find(r => r.key === cur.role)?.actions || []);
    const grant = [...have].filter(a => !preset.has(a)); const revoke = [...preset].filter(a => !have.has(a));
    return { ...prev, [id]: { ...cur, grant, revoke } };
  });

  const save = async () => {
    setBusy(true); setError('');
    try {
      const body = { name, email, assignments: Object.entries(assign).map(([businessId, a]) => ({ businessId: Number(businessId), role: a.role, grant: a.grant, revoke: a.revoke })) };
      if (password) body.password = password;
      if (editing) await api.team.update(member.id, body); else await api.team.create({ ...body, password });
      onSaved(); onClose();
    } catch (e) { setError(errMsg(e)); setBusy(false); }
  };

  return (
    <div onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }} style={{ position: 'fixed', inset: 0, background: 'rgba(15,15,16,.55)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 620, maxHeight: '92vh', background: C.cardBg, borderRadius: 3, boxShadow: C.shadowLg, display: 'flex', flexDirection: 'column', fontFamily: FONT, overflow: 'hidden' }}>
        <div style={{ padding: '16px 22px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 800 }}>{editing ? 'Edit team member' : 'Add team member'}</div>
            <div style={{ fontSize: 12.5, color: C.textSecondary, marginTop: 2 }}>They sign in with this email + password and can open only the businesses you tick.</div>
          </div>
          <button onClick={onClose} aria-label="Close" style={{ ...btn('ghost'), width: 32, padding: 0, height: 32 }}><X size={16} /></button>
        </div>
        <div style={{ padding: '16px 22px', overflowY: 'auto', flex: 1 }}>
          {error && <div style={{ background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 3, padding: '9px 12px', fontSize: 12.5, marginBottom: 12 }}>{error}</div>}
          <div style={{ display: 'flex', gap: 12, marginBottom: 12, flexWrap: 'wrap' }}>
            <div style={{ flex: 1, minWidth: 200 }}><Label>Name</Label><input style={input} value={name} onChange={e => setName(e.target.value)} placeholder="Full name" /></div>
            <div style={{ flex: 1, minWidth: 200 }}><Label>Login email (ID)</Label><input style={input} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="member@rarevoindia.com" autoComplete="off" /></div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <Label>{editing ? 'New password (leave empty to keep current)' : 'Password'}</Label>
            <div style={{ display: 'flex', gap: 6 }}>
              <input style={{ ...input, fontFamily: 'ui-monospace, monospace' }} value={password} onChange={e => setPassword(e.target.value)}  placeholder="At least 8 characters" autoComplete="new-password" />
              <button style={btn('ghost')} type="button" onClick={() => setPassword(genPassword())}><KeyRound size={14} /> Generate</button>
              <button style={btn('ghost')} type="button" disabled={!password} onClick={() => { navigator.clipboard?.writeText(`${email} / ${password}`); setCopied(true); setTimeout(() => setCopied(false), 1500); }}>{copied ? <Check size={14} /> : <Copy size={14} />}</button>
            </div>
            <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>Passwords are stored hashed — copy it now to share with the member.</div>
          </div>

          <Label>Businesses this member can open ({ids.size} selected)</Label>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            <div style={{ position: 'relative', flex: 1 }}>
              <Search size={14} style={{ position: 'absolute', left: 10, top: 12, color: C.textMuted }} />
              <input style={{ ...input, paddingLeft: 30 }} placeholder="Search businesses…" value={q} onChange={e => setQ(e.target.value)} />
            </div>
            <button style={btn('ghost')} onClick={() => setAssign(prev => Object.fromEntries(businesses.map(b => [b.id, prev[b.id] || { role: defaultRole, grant: [], revoke: [] }])))}>All</button>
            <button style={btn('ghost')} onClick={() => setAssign({})}>None</button>
          </div>
          <div style={{ border: `1px solid ${C.border}`, borderRadius: 3, maxHeight: 240, overflowY: 'auto' }}>
            {shown.length === 0 && <div style={{ padding: 14, fontSize: 12.5, color: C.textMuted }}>No businesses found.</div>}
            {shown.map(b => {
              const a = assign[b.id]; const preset = catalog?.roles?.find(r => r.key === a?.role);
              const customised = a && (a.grant.length || a.revoke.length);
              return (
                <div key={b.id} style={{ borderBottom: `1px solid ${C.border}` }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', fontSize: 13 }}>
                    <input type="checkbox" checked={!!a} onChange={() => toggle(b.id)} aria-label={`Allow access to ${b.name}`} />
                    <Building2 size={14} color={C.textMuted} /><span style={{ flex: 1, fontWeight: 600 }}>{b.name}{b.status !== 'active' && <span style={{ fontSize: 11, color: C.textMuted, marginLeft: 6 }}>{b.status}</span>}</span>
                    {a && (
                      <>
                        <select value={a.role} onChange={e => setRole(b.id, e.target.value)} aria-label={`Role in ${b.name}`}
                          style={{ ...input, width: 160, height: 30, padding: '0 6px' }}>
                          {(catalog?.roles || []).map(r => <option key={r.key} value={r.key}>{r.label}</option>)}
                        </select>
                        <button type="button" title="Customize permissions" onClick={() => setOpenCustom(openCustom === b.id ? null : b.id)}
                          style={btn('ghost', { height: 30, padding: '0 8px', borderColor: customised ? C.primary : C.border, color: customised ? C.primary : C.text })}>
                          <SlidersHorizontal size={13} />{customised ? 'Custom' : ''}
                        </button>
                      </>
                    )}
                  </div>
                  {a && openCustom === b.id && (
                    <div style={{ padding: '4px 14px 12px 40px', background: C.surfaceAlt }}>
                      <div style={{ fontSize: 11.5, color: C.textSecondary, margin: '6px 0 8px' }}>{preset?.description} Tick or untick to customize this member in this business only.</div>
                      {(catalog?.groups || []).map(g => (
                        <div key={g.key} style={{ marginBottom: 8 }}>
                          <div style={{ fontSize: 11, fontWeight: 700, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '.04em', marginBottom: 3 }}>{g.label}</div>
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '2px 16px' }}>
                            {g.actions.map(ac => (
                              <label key={ac.key} style={{ fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer', minWidth: 210 }}>
                                <input type="checkbox" checked={actionsFor(catalog, a.role, a.grant, a.revoke).has(ac.key)} onChange={() => toggleAction(b.id, ac.key)} />{ac.label}
                              </label>
                            ))}
                          </div>
                        </div>
                      ))}
                      {customised ? <button type="button" style={btn('ghost', { height: 28, fontSize: 12 })} onClick={() => setRole(b.id, a.role)}>Reset to {preset?.label} preset</button> : null}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
        <div style={{ padding: '12px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button style={btn('ghost')} onClick={onClose}>Cancel</button>
          <button style={btn('primary')} disabled={busy || !name.trim() || !email.trim() || (!editing && !password)} onClick={save}>{busy ? 'Saving…' : editing ? 'Save changes' : 'Create member'}</button>
        </div>
      </div>
    </div>
  );
}

export default function TeamPage({ user, navigate }) {
  const [members, setMembers] = useState(null);
  const [businesses, setBusinesses] = useState([]);
  const [error, setError] = useState('');
  const [modal, setModal] = useState(null); // {member?} | {}
  const [catalog, setCatalog] = useState(null);
  const isAdmin = user?.role === 'admin';

  const load = useCallback(() => {
    api.team.list().then(setMembers).catch(e => setError(errMsg(e)));
    api.businesses.list({ page: 1, pageSize: 100, slim: true }).then(r => setBusinesses(r.items || [])).catch(() => {});
    api.permissionCatalog().then(setCatalog).catch(e => setError(errMsg(e)));
  }, []);
  useEffect(() => { if (isAdmin) load(); }, [isAdmin, load]);

  if (!isAdmin) return <div style={{ padding: 30, fontFamily: FONT, color: C.textSecondary }}>Only the admin can manage the team.</div>;

  const nameOf = (id) => businesses.find(b => b.id === id)?.name || `#${id}`;
  const toggleActive = async (m) => { try { await api.team.update(m.id, { isActive: !m.isActive }); load(); } catch (e) { setError(errMsg(e)); } };
  const remove = async (m) => { if (!window.confirm(`Delete ${m.name}? They will lose access immediately.`)) return; try { await api.team.remove(m.id); load(); } catch (e) { setError(errMsg(e)); } };

  return (
    <div style={{ padding: '26px 30px 40px', fontFamily: FONT, maxWidth: 1100, width: '100%', boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap', marginBottom: 18 }}>
        <button style={btn('ghost', { width: 36, padding: 0 })} onClick={() => navigate('businesses')} aria-label="Back"><ArrowLeft size={16} /></button>
        <div style={{ flex: 1, minWidth: 220 }}>
          <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-.02em', display: 'flex', alignItems: 'center', gap: 10 }}><Users size={24} /> Team</div>
          <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 3 }}>Create a login for each team member and choose which businesses they can open. They see nothing else.</div>
        </div>
        <button style={btn('primary', { height: 40, padding: '0 18px' })} onClick={() => setModal({})}><Plus size={16} /> Add member</button>
      </div>

      {error && <div style={{ background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 3, padding: '9px 12px', fontSize: 12.5, marginBottom: 12 }}>{error}</div>}
      {!members && !error && <div style={{ color: C.textMuted, fontSize: 13 }}>Loading…</div>}
      {members && members.length === 0 && (
        <div style={{ background: C.cardBg, border: `1px dashed ${C.border}`, borderRadius: 3, padding: 40, textAlign: 'center', color: C.textSecondary, fontSize: 14 }}>
          No team members yet. Click <b>Add member</b> to create the first login.
        </div>
      )}
      <div style={{ display: 'grid', gap: 10 }}>
        {(members || []).map(m => (
          <div key={m.id} style={{ background: C.cardBg, border: `1px solid ${C.border}`, borderRadius: 3, padding: '14px 16px', display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap', opacity: m.isActive ? 1 : 0.6 }}>
            <div style={{ flex: 1, minWidth: 240 }}>
              <div style={{ fontWeight: 700, fontSize: 14.5 }}>{m.name} {!m.isActive && <span style={{ fontSize: 11, color: '#B91C1C', fontWeight: 600 }}>· disabled</span>}</div>
              <div style={{ fontSize: 12.5, color: C.textSecondary }}>{m.email}</div>
              <div style={{ fontSize: 11.5, color: C.textMuted, marginTop: 2 }}>{m.lastLoginAt ? `Last login ${relativeTime(m.lastLoginAt)}` : 'Never logged in'}{m.mustChangePassword ? ' · hasn\'t chosen their own password yet' : ''}</div>
            </div>
            <div style={{ flex: 2, minWidth: 240, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {m.assignments.length === 0 && <span style={{ fontSize: 12, color: '#92400E', background: '#FEF3C7', borderRadius: 3, padding: '3px 8px' }}>No business assigned</span>}
              {m.assignments.map(a => (
                <span key={a.businessId} style={{ fontSize: 12, background: C.surfaceAlt, border: `1px solid ${C.border}`, borderRadius: 3, padding: '3px 8px', fontWeight: 600 }}>
                  {nameOf(a.businessId)} <span style={{ fontWeight: 500, color: C.textSecondary }}>· {catalog?.roles?.find(r => r.key === a.role)?.label || a.role}{(a.grant.length || a.revoke.length) ? ' (custom)' : ''}</span>
                </span>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <button style={btn('ghost', { height: 32, padding: '0 10px' })} onClick={() => setModal({ member: m })}><Pencil size={13} /> Edit</button>
              <button style={btn('ghost', { height: 32, padding: '0 10px' })} onClick={() => toggleActive(m)}>{m.isActive ? 'Disable' : 'Enable'}</button>
              <button style={btn('ghost', { height: 32, padding: '0 10px', color: '#DC2626' })} onClick={() => remove(m)} aria-label="Delete"><Trash2 size={13} /></button>
            </div>
          </div>
        ))}
      </div>

      {modal && <MemberModal member={modal.member} businesses={businesses} catalog={catalog} onClose={() => setModal(null)} onSaved={load} />}
    </div>
  );
}
