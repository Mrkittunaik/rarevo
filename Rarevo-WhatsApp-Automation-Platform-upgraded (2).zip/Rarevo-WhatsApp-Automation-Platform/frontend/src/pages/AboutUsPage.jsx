import { C, FONT } from '../constants.js';
import RarevoMark from '../components/RarevoMark.jsx';

export default function AboutUsPage() {
  return (
    <div style={{ padding: '40px 24px', fontFamily: FONT, color: C.text, maxWidth: 760, margin: '0 auto', width: '100%' }}>
      <div style={{ textAlign: 'center', marginBottom: 32, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <RarevoMark size={64} />
        <h1 style={{ fontSize: 28, fontWeight: 800, margin: '14px 0 0', letterSpacing: '-0.02em' }}>
          RAREVO <span style={{ color: C.primary }}>WhatsApp Automation Platform</span>
        </h1>
        <p style={{ fontSize: 14, color: C.textSecondary, margin: '10px auto 0', maxWidth: 560, lineHeight: 1.6 }}>
          Rarevo runs WhatsApp automation, bulk messaging and a built-in CRM for many businesses from one place —
          each business with its own number, automations and customer data.
        </p>
      </div>
      <div style={{ textAlign: 'center', marginTop: 36, fontSize: 12, color: C.textMuted }}>
        © {new Date().getFullYear()} Rarevo
      </div>
    </div>
  );
}
