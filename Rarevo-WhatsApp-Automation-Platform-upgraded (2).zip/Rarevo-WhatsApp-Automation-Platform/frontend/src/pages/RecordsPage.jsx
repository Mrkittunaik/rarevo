import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Search, Download, RefreshCw, MessageCircle, UserPlus, CalendarDays, Users, ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { api } from '../api.js';
import { C, FONT } from '../constants.js';
import MaskedNumber from '../components/MaskedNumber.jsx';

const TZ = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'Asia/Kolkata'; } catch { return 'Asia/Kolkata'; } })();
const RANGES = [
  { key: 'today', label: 'Today' },
  { key: 'yesterday', label: 'Yesterday' },
  { key: '7d', label: 'Last 7 days' },
  { key: '30d', label: 'Last 30 days' },
  { key: 'all', label: 'All' },
];

const dayKey = (d) => new Date(d).toLocaleDateString('en-CA', { timeZone: TZ }); // YYYY-MM-DD
const timeStr = (d) => new Date(d).toLocaleTimeString('en-IN', { timeZone: TZ, hour: 'numeric', minute: '2-digit', hour12: true });
const dateStr = (d) => new Date(d).toLocaleDateString('en-IN', { timeZone: TZ, day: '2-digit', month: 'short', year: 'numeric' });
function dayLabel(d) {
  const k = dayKey(d);
  const now = new Date();
  if (k === dayKey(now)) return 'Today';
  if (k === dayKey(new Date(now.getTime() - 86400000))) return 'Yesterday';
  return new Date(d).toLocaleDateString('en-IN', { timeZone: TZ, weekday: 'long', day: '2-digit', month: 'short', year: 'numeric' });
}

const card = { background: C.cardBg, border: `1px solid ${C.border}`, borderRadius: 3 };
const th = { textAlign: 'left', fontSize: 11, fontWeight: 700, letterSpacing: '.05em', textTransform: 'uppercase', color: C.textSecondary, padding: '9px 12px', whiteSpace: 'nowrap' };
const td = { padding: '10px 12px', fontSize: 13, borderTop: `1px solid ${C.border}`, verticalAlign: 'middle' };

function Tile({ Icon, label, value, sub }) {
  return (
    <div style={{ ...card, flex: 1, minWidth: 170, padding: '13px 15px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, fontWeight: 600, color: C.textSecondary }}><Icon size={14} />{label}</div>
      <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: '-.02em', marginTop: 4 }}>{value ?? '—'}</div>
      {sub && <div style={{ fontSize: 11.5, color: C.textMuted }}>{sub}</div>}
    </div>
  );
}

export default function RecordsPage({ navigate }) {
  const [range, setRange] = useState('today');
  const [q, setQ] = useState('');
  const [dq, setDq] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const pageSize = 50;
  const [canExport, setCanExport] = useState(true); // the server enforces this too; this only hides the button
  const [exportOpen, setExportOpen] = useState(false);
  const [exporting, setExporting] = useState('');
  const [exRange, setExRange] = useState('view'); // 'view' = whatever the page is showing
  const [exFrom, setExFrom] = useState('');
  const [exTo, setExTo] = useState('');
  const tRef = useRef(null);

  useEffect(() => { clearTimeout(tRef.current); tRef.current = setTimeout(() => { setDq(q); setPage(1); }, 300); return () => clearTimeout(tRef.current); }, [q]);

  const load = useCallback((silent = false) => {
    if (!silent) setLoading(true);
    return api.records({ range, q: dq, page, pageSize, tz: TZ })
      .then(d => { setData(d); setError(''); })
      .catch(e => setError(String(e.message || e)))
      .finally(() => setLoading(false));
  }, [range, dq, page]);
  useEffect(() => { load(); }, [load]);
  // New conversations appear on their own: refresh every 30s.
  useEffect(() => { const t = setInterval(() => load(true), 30000); return () => clearInterval(t); }, [load]);

  const groups = useMemo(() => {
    const out = []; const idx = new Map();
    for (const r of data?.items || []) {
      const k = dayKey(r.lastAt);
      if (!idx.has(k)) { idx.set(k, out.length); out.push({ key: k, label: dayLabel(r.lastAt), rows: [] }); }
      out[idx.get(k)].rows.push(r);
    }
    return out;
  }, [data]);

  useEffect(() => {
    api.myPermissions().then(p => setCanExport((p.actions || []).includes('customers.export'))).catch(() => { /* keep default; server decides */ });
  }, []);

  // Server-side export: every matching customer (not just the loaded page), as a real .xlsx or .csv.
  const exportFile = async (format) => {
    const eff = exRange === 'view' ? range : exRange;
    if (eff === 'custom' && (!exFrom || !exTo)) { setError('Pick both a from and a to date for a custom range.'); return; }
    setExporting(format); setError('');
    try {
      const qs = new URLSearchParams({ format, range: eff, tz: TZ });
      if (exRange === 'view' && dq) qs.set('q', dq);
      if (eff === 'custom') { qs.set('from', exFrom); qs.set('to', exTo); }
      const res = await fetch(`/api/records/export?${qs}`, { credentials: 'include' });
      if (!res.ok) {
        const text = await res.text().catch(() => '');
        let msg = text; try { msg = JSON.parse(text).error || text; } catch { /* plain text */ }
        throw new Error(msg || `Export failed (${res.status})`);
      }
      const blob = await res.blob();
      const cd = res.headers.get('Content-Disposition') || '';
      const name = cd.split('filename=')[1]?.split(';')[0]?.replaceAll('"', '').trim() || `records.${format}`;
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      setExportOpen(false);
    } catch (e) { setError(String(e.message || e)); }
    finally { setExporting(''); }
  };

  const c = data?.counts;
  const pages = data ? Math.max(1, Math.ceil(data.total / pageSize)) : 1;
  const chip = (active) => ({
    height: 34, padding: '0 14px', borderRadius: 3, fontFamily: FONT, fontSize: 13, fontWeight: 600, cursor: 'pointer',
    border: `1.5px solid ${active ? C.primary : C.border}`, background: active ? C.primary : C.cardBg, color: active ? '#fff' : C.text,
  });

  return (
    <div style={{ padding: '26px 30px 40px', fontFamily: FONT, maxWidth: 1500, width: '100%', boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap', marginBottom: 16 }}>
        <div style={{ flex: 1, minWidth: 220 }}>
          <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-.02em' }}>Records</div>
          <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 3 }}>Every customer conversation — name, number and time — grouped by day. New conversations are added automatically.</div>
        </div>
        <button onClick={() => load()} style={{ ...chip(false), display: 'inline-flex', alignItems: 'center', gap: 6 }}><RefreshCw size={14} className={loading ? 'spin' : ''} /> Refresh</button>
        {canExport && <div style={{ position: 'relative' }}>
          <button onClick={() => setExportOpen(o => !o)} style={{ ...chip(false), display: 'inline-flex', alignItems: 'center', gap: 6 }}><Download size={14} /> Export</button>
          {exportOpen && (
            <div style={{ position: 'absolute', right: 0, top: 40, zIndex: 20, width: 290, background: C.cardBg, border: `1.5px solid ${C.border}`, borderRadius: 4, padding: 14, boxShadow: '0 8px 24px rgba(0,0,0,.12)' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: C.textSecondary, marginBottom: 6 }}>What to export</div>
              <select value={exRange} onChange={e => setExRange(e.target.value)}
                style={{ width: '100%', height: 34, borderRadius: 3, border: `1.5px solid ${C.border}`, fontFamily: FONT, fontSize: 13, background: C.cardBg, padding: '0 8px', marginBottom: 8 }}>
                <option value="view">Current view ({RANGES.find(r => r.key === range)?.label}{dq ? ' + search' : ''})</option>
                <option value="all">All customers</option>
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="custom">Custom date range…</option>
              </select>
              {exRange === 'custom' && (
                <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
                  <input type="date" value={exFrom} max={exTo || undefined} onChange={e => setExFrom(e.target.value)} style={{ flex: 1, height: 32, border: `1.5px solid ${C.border}`, borderRadius: 3, fontFamily: FONT, fontSize: 12 }} />
                  <input type="date" value={exTo} min={exFrom || undefined} onChange={e => setExTo(e.target.value)} style={{ flex: 1, height: 32, border: `1.5px solid ${C.border}`, borderRadius: 3, fontFamily: FONT, fontSize: 12 }} />
                </div>
              )}
              <div style={{ display: 'flex', gap: 8 }}>
                <button disabled={!!exporting} onClick={() => exportFile('xlsx')} style={{ ...chip(true), flex: 1, opacity: exporting ? 0.6 : 1 }}>{exporting === 'xlsx' ? 'Preparing…' : 'Excel (.xlsx)'}</button>
                <button disabled={!!exporting} onClick={() => exportFile('csv')} style={{ ...chip(false), flex: 1, opacity: exporting ? 0.6 : 1 }}>{exporting === 'csv' ? 'Preparing…' : 'CSV'}</button>
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 8, lineHeight: 1.4 }}>Includes every matching customer, not just this page. Excel adds message-summary and business-info sheets.</div>
            </div>
          )}
        </div>}
      </div>

      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 16 }}>
        <Tile Icon={MessageCircle} label="Conversations today" value={c?.today} sub={`${c?.newToday ?? 0} new customers`} />
        <Tile Icon={CalendarDays} label="Yesterday" value={c?.yesterday} sub={`${c?.newYesterday ?? 0} new customers`} />
        <Tile Icon={UserPlus} label="Last 7 days" value={c?.['7d']} />
        <Tile Icon={Users} label="All customers" value={c?.all} />
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', alignItems: 'center', marginBottom: 14 }}>
        {RANGES.map(r => (
          <button key={r.key} style={chip(range === r.key)} onClick={() => { setRange(r.key); setPage(1); }}>
            {r.label}{c ? ` (${c[r.key]})` : ''}
          </button>
        ))}
        <div style={{ position: 'relative', flex: 1, minWidth: 220, maxWidth: 360, marginLeft: 'auto' }}>
          <Search size={14} style={{ position: 'absolute', left: 11, top: 11, color: C.textMuted }} />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search name or number…"
            style={{ width: '100%', height: 36, borderRadius: 3, border: `1.5px solid ${C.border}`, padding: '0 11px 0 32px', fontFamily: FONT, fontSize: 13, background: C.cardBg, boxSizing: 'border-box', outline: 'none' }} />
        </div>
      </div>

      {error && <div style={{ background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 3, padding: '9px 12px', fontSize: 12.5, marginBottom: 12 }}>{error}</div>}

      {data && data.items.length === 0 && (
        <div style={{ ...card, borderStyle: 'dashed', padding: 40, textAlign: 'center', color: C.textSecondary, fontSize: 14 }}>
          No conversations {range === 'all' ? 'yet' : `for “${RANGES.find(r => r.key === range).label}”`}{dq ? ' matching your search' : ''}. They appear here as soon as a customer messages this business.
        </div>
      )}

      {groups.map(g => (
        <div key={g.key} style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 13, fontWeight: 800, margin: '0 2px 8px', display: 'flex', gap: 8, alignItems: 'baseline' }}>
            {g.label} <span style={{ fontSize: 12, fontWeight: 600, color: C.textMuted }}>{g.rows.length} {g.rows.length === 1 ? 'customer' : 'customers'}</span>
          </div>
          <div style={{ ...card, overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 900 }}>
              <thead><tr style={{ background: C.surfaceAlt }}>
                <th style={th}>Name</th><th style={th}>Number</th><th style={th}>First message</th><th style={th}>Last activity</th>
                <th style={th}>Messages</th><th style={th}>Last message</th>
              </tr></thead>
              <tbody>
                {g.rows.map(r => {
                  const isNew = dayKey(r.firstAt) === g.key;
                  return (
                    <tr key={r.waNumber + r.contactNumber} onClick={() => navigate(`chats/${r.waNumber}/${r.contactNumber}`)}
                      style={{ cursor: 'pointer' }} onMouseEnter={e => e.currentTarget.style.background = C.hover} onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                      <td style={{ ...td, fontWeight: 700 }}>
                        {r.name || <span style={{ color: C.textMuted, fontWeight: 500 }}>Unknown</span>}
                        {isNew && <span style={{ marginLeft: 8, fontSize: 10.5, fontWeight: 700, color: '#047857', background: '#ECFDF5', border: '1px solid #A7F3D0', borderRadius: 3, padding: '1px 6px' }}>NEW</span>}
                      </td>
                      <td style={td}><MaskedNumber number={r.contactNumber} prefix="+" /></td>
                      <td style={{ ...td, whiteSpace: 'nowrap', color: C.textSecondary }}>{dateStr(r.firstAt)}<br /><span style={{ fontSize: 12 }}>{timeStr(r.firstAt)}</span></td>
                      <td style={{ ...td, whiteSpace: 'nowrap' }}><b>{timeStr(r.lastAt)}</b><br /><span style={{ fontSize: 12, color: C.textSecondary }}>{dateStr(r.lastAt)}</span></td>
                      <td style={{ ...td, whiteSpace: 'nowrap' }}>
                        <b>{r.messages}</b>
                        <span style={{ color: C.textMuted, fontSize: 12, marginLeft: 8 }}><ArrowDownLeft size={11} /> {r.inbound} <ArrowUpRight size={11} /> {r.outbound}</span>
                      </td>
                      <td style={{ ...td, maxWidth: 360, color: C.textSecondary }}>
                        <div style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.lastDirection === 'outgoing' ? 'You: ' : ''}{r.lastMessage || '—'}</div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      {data && data.total > pageSize && (
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', justifyContent: 'center', marginTop: 10, fontSize: 13 }}>
          <button style={chip(false)} disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Previous</button>
          <span>Page {page} of {pages} · {data.total} customers</span>
          <button style={chip(false)} disabled={page >= pages} onClick={() => setPage(p => p + 1)}>Next</button>
        </div>
      )}
    </div>
  );
}
