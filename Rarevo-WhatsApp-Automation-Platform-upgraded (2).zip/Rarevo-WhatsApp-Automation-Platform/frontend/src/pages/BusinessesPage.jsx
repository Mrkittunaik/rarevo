import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  Plus, Search, MoreVertical, Building2, MessageCircle, Users, Zap, KanbanSquare,
  Phone, X, Check, ExternalLink, Pause, Play, Archive, Pencil, Link2,
  UserCog, History, Copy, AlertTriangle, ChevronRight, ChevronLeft, Loader2, Sparkles,
} from 'lucide-react';
import { api } from '../api.js';
import { C, FONT, relativeTime } from '../constants.js';

/* ───────────────────────── helpers ───────────────────────── */

function errMsg(e) {
  const raw = String(e?.message || e || 'Something went wrong');
  const m = raw.match(/^\d{3}\s+([\s\S]*)$/);
  const body = m ? m[1] : raw;
  try { const j = JSON.parse(body); if (j?.error) return j.error; } catch { /* plain text */ }
  return body || 'Something went wrong';
}

const AVATAR_COLORS = ['#dc2626', '#2563eb', '#0F6E56', '#7c3aed', '#d97706', '#0891b2', '#be185d', '#4d7c0f'];
function avatarColor(name) {
  let h = 0; for (const ch of String(name || '?')) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
}
const initials = (name) => String(name || '?').split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
const fmt = (n) => (n == null ? '—' : Number(n).toLocaleString('en-IN'));
const money = (n) => '₹' + Number(n || 0).toLocaleString('en-IN');

const STATUS_STYLE = {
  active:     { bg: '#E6F4EA', fg: '#0F6E56', label: 'Active' },
  onboarding: { bg: '#FEF3C7', fg: '#92400E', label: 'Onboarding' },
  paused:     { bg: '#F1F1EE', fg: '#6B7280', label: 'Paused' },
};
const HEALTH = {
  healthy:       { color: '#16A34A', label: 'Healthy' },
  unknown:       { color: '#9CA3AF', label: 'Not yet used' },
  invalid_token: { color: '#DC2626', label: 'Token expired' },
  rate_limited:  { color: '#D97706', label: 'Rate limited' },
  unknown_error: { color: '#DC2626', label: 'Error' },
};

const INDUSTRIES = ['Retail', 'E-commerce', 'Real estate', 'Education', 'Healthcare', 'Restaurant / Food', 'Travel', 'Finance', 'Services', 'Other'];

/* ───────────────────────── small UI kit ───────────────────────── */

const btn = (kind = 'ghost', extra = {}) => ({
  height: 36, padding: '0 14px', borderRadius: 3, fontFamily: FONT, fontSize: 13, fontWeight: 600,
  cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 7,
  border: kind === 'primary' ? 'none' : `1.5px solid ${C.border}`,
  background: kind === 'primary' ? C.primary : kind === 'danger' ? '#DC2626' : C.cardBg,
  color: kind === 'primary' || kind === 'danger' ? '#fff' : C.text, ...extra,
});

const inputStyle = {
  width: '100%', height: 38, borderRadius: 3, border: `1.5px solid ${C.border}`, padding: '0 11px',
  fontFamily: FONT, fontSize: 13, background: C.cardBg, color: C.text, boxSizing: 'border-box', outline: 'none',
};

function Field({ label, hint, children }) {
  return (
    <label style={{ display: 'block', marginBottom: 13 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 5, fontFamily: FONT }}>{label}</div>
      {children}
      {hint && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4, fontFamily: FONT }}>{hint}</div>}
    </label>
  );
}

function Modal({ title, subtitle, onClose, children, footer, width = 560 }) {
  useEffect(() => {
    const h = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', h);
    return () => document.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }} style={{
      position: 'fixed', inset: 0, background: 'rgba(15,15,16,.55)', zIndex: 1000,
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16,
    }}>
      <div role="dialog" aria-modal="true" style={{
        width: '100%', maxWidth: width, maxHeight: '92vh', background: C.cardBg, borderRadius: 3,
        boxShadow: C.shadowLg, display: 'flex', flexDirection: 'column', fontFamily: FONT, overflow: 'hidden',
      }}>
        <div style={{ padding: '18px 22px 14px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 17, fontWeight: 800, color: C.text, letterSpacing: '-.01em' }}>{title}</div>
            {subtitle && <div style={{ fontSize: 12.5, color: C.textSecondary, marginTop: 3 }}>{subtitle}</div>}
          </div>
          <button onClick={onClose} aria-label="Close" style={{ ...btn('ghost'), width: 32, height: 32, padding: 0 }}><X size={16} /></button>
        </div>
        <div style={{ padding: '18px 22px', overflowY: 'auto', flex: 1 }}>{children}</div>
        {footer && <div style={{ padding: '13px 22px', borderTop: `1px solid ${C.border}`, display: 'flex', gap: 10, justifyContent: 'flex-end', alignItems: 'center' }}>{footer}</div>}
      </div>
    </div>
  );
}

function Notice({ kind = 'error', children }) {
  const s = kind === 'error' ? { bg: '#FEF2F2', fg: '#B91C1C', bd: '#FECACA' }
    : kind === 'ok' ? { bg: '#ECFDF5', fg: '#047857', bd: '#A7F3D0' } : { bg: '#FFFBEB', fg: '#92400E', bd: '#FDE68A' };
  return <div style={{ background: s.bg, color: s.fg, border: `1px solid ${s.bd}`, borderRadius: 3, padding: '9px 12px', fontSize: 12.5, marginBottom: 12, lineHeight: 1.45 }}>{children}</div>;
}

function Avatar({ b, size = 44 }) {
  if (b.logoUrl) {
    return <img src={b.logoUrl} alt="" style={{ width: size, height: size, borderRadius: 3, objectFit: 'cover', flexShrink: 0 }} onError={e => { e.currentTarget.style.display = 'none'; }} />;
  }
  return (
    <div style={{
      width: size, height: size, borderRadius: 3, background: avatarColor(b.name), color: '#fff', flexShrink: 0,
      display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: size * 0.36, fontFamily: FONT,
    }}>{initials(b.name)}</div>
  );
}

function CopyBox({ label, value }) {
  const [done, setDone] = useState(false);
  return (
    <div style={{ marginBottom: 10 }}>
      <div style={{ fontSize: 11.5, fontWeight: 600, color: C.textSecondary, marginBottom: 4 }}>{label}</div>
      <div style={{ display: 'flex', gap: 6 }}>
        <input readOnly value={value} style={{ ...inputStyle, fontFamily: 'ui-monospace, monospace', fontSize: 12 }} onFocus={e => e.target.select()} />
        <button style={btn('ghost', { height: 38 })} onClick={() => { navigator.clipboard?.writeText(value); setDone(true); setTimeout(() => setDone(false), 1500); }}>
          {done ? <Check size={14} /> : <Copy size={14} />}
        </button>
      </div>
    </div>
  );
}

/* ───────────────────────── Add Business wizard ───────────────────────── */

const EMPTY_DETAILS = { name: '', industry: '', contactName: '', contactEmail: '', contactPhone: '', website: '', timezone: 'Asia/Kolkata', notes: '' };
const EMPTY_WA = { phoneNumberId: '', wabaId: '', accessToken: '', verifyToken: '', metaAppId: '' };

function WhatsAppFields({ wa, setWa, onTest, testing, test }) {
  return (
    <>
      <Field label="Phone Number ID" hint="Meta for Developers → WhatsApp → API Setup">
        <input style={inputStyle} value={wa.phoneNumberId} onChange={e => setWa({ ...wa, phoneNumberId: e.target.value })} placeholder="e.g. 109876543210987" />
      </Field>
      <Field label="WhatsApp Business Account ID (WABA ID)">
        <input style={inputStyle} value={wa.wabaId} onChange={e => setWa({ ...wa, wabaId: e.target.value })} placeholder="e.g. 102938475610293" />
      </Field>
      <Field label="Permanent access token" hint="Use a System User token. Temporary tokens expire in 24 hours.">
        <input style={inputStyle} type="password" autoComplete="off" value={wa.accessToken} onChange={e => setWa({ ...wa, accessToken: e.target.value })} placeholder="EAAG…" />
      </Field>
      <div style={{ display: 'flex', gap: 10 }}>
        <div style={{ flex: 1 }}>
          <Field label="Webhook verify token (optional)">
            <input style={inputStyle} value={wa.verifyToken} onChange={e => setWa({ ...wa, verifyToken: e.target.value })} placeholder="any secret string" />
          </Field>
        </div>
        <div style={{ flex: 1 }}>
          <Field label="Meta App ID (optional)">
            <input style={inputStyle} value={wa.metaAppId} onChange={e => setWa({ ...wa, metaAppId: e.target.value })} />
          </Field>
        </div>
      </div>
      <button style={btn('ghost')} disabled={testing || !wa.phoneNumberId || !wa.accessToken} onClick={onTest}>
        {testing ? <Loader2 size={14} className="spin" /> : <Check size={14} />} Test connection
      </button>
      {test?.ok && <div style={{ marginTop: 10 }}><Notice kind="ok">Connected to Meta: <b>{test.displayName || 'verified number'}</b> {test.displayPhoneNumber ? `(+${test.displayPhoneNumber})` : ''}</Notice></div>}
      {test && !test.ok && <div style={{ marginTop: 10 }}><Notice>{test.error}</Notice></div>}
    </>
  );
}

function AddBusinessWizard({ onClose, onCreated, onAddAnother, canPickTeam }) {
  const [step, setStep] = useState(0);
  const [details, setDetails] = useState(EMPTY_DETAILS);
  const [wa, setWa] = useState(EMPTY_WA);
  const [skipWa, setSkipWa] = useState(false);
  const [test, setTest] = useState(null);
  const [testing, setTesting] = useState(false);
  const [templates, setTemplates] = useState([]);
  const [autoOn, setAutoOn] = useState(true);
  const [autoName, setAutoName] = useState('');
  const [templateId, setTemplateId] = useState('');
  const [users, setUsers] = useState([]);
  const [memberIds, setMemberIds] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  useEffect(() => {
    api.businesses.automationTemplates().then(setTemplates).catch(() => {});
    if (canPickTeam) api.users.list().then(u => setUsers((Array.isArray(u) ? u : u.users || []).filter(x => x.isActive !== false && x.role !== 'admin'))).catch(() => {});
  }, [canPickTeam]);

  const STEPS = ['Business', 'WhatsApp', 'Automation', 'Team & review'];
  const defaultAutoName = `${details.name.trim() || 'Business'} – Welcome Flow`;

  const next = () => {
    setError('');
    if (step === 0 && !details.name.trim()) return setError('Business name is required.');
    if (step === 1 && !skipWa && (!wa.phoneNumberId.trim() || !wa.wabaId.trim() || !wa.accessToken.trim())) {
      return setError('Fill Phone Number ID, WABA ID and access token — or choose "Connect later".');
    }
    setStep(s => s + 1);
  };

  const runTest = async () => {
    setTesting(true); setTest(null);
    try { setTest(await api.businesses.testWhatsapp(wa.phoneNumberId.trim(), wa.accessToken.trim())); }
    catch (e) { setTest({ ok: false, error: errMsg(e) }); }
    finally { setTesting(false); }
  };

  const create = async () => {
    setBusy(true); setError('');
    try {
      const res = await api.businesses.create({
        details,
        whatsapp: skipWa ? undefined : wa,
        automation: autoOn ? { name: autoName.trim() || defaultAutoName, templateId: templateId || undefined } : false,
        memberIds,
      });
      setResult({ ...res, verifyToken: wa.verifyToken });
      onCreated();
    } catch (e) {
      const m = errMsg(e);
      setError(m);
      if (/WhatsApp number|Phone Number ID/i.test(m)) setStep(1);
    } finally { setBusy(false); }
  };

  if (result) {
    return (
      <Modal title="Business created 🎉" subtitle={`${result.business.name} is ready.`} onClose={onClose}
        footer={<>
          <button style={btn('ghost')} onClick={onAddAnother}><Plus size={15} /> Add another business</button>
          <button style={btn('primary')} onClick={onClose}>Back to dashboard</button>
        </>}>
        {result.account
          ? <Notice kind="ok">WhatsApp number <b>{result.account.displayPhoneNumber ? `+${result.account.displayPhoneNumber}` : result.account.displayName}</b> is connected.</Notice>
          : <Notice kind="warn">No WhatsApp number yet. Use the card's ⋮ menu → <b>Connect WhatsApp</b> when the client's credentials are ready.</Notice>}
        {result.automation && <Notice kind="ok">Automation <b>{result.automation.name}</b> was created ({result.automation.status}).</Notice>}
        {result.account && (
          <>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8, color: C.text }}>Last step in Meta</div>
            <div style={{ fontSize: 12.5, color: C.textSecondary, marginBottom: 10, lineHeight: 1.5 }}>
              In Meta for Developers → WhatsApp → Configuration, set this webhook and subscribe to <b>messages</b>. One URL serves every business.
            </div>
            <CopyBox label="Callback URL" value={result.webhook.callbackUrl} />
            {result.verifyToken && <CopyBox label="Verify token" value={result.verifyToken} />}
          </>
        )}
      </Modal>
    );
  }

  return (
    <Modal title="Add Business" subtitle={`Step ${step + 1} of ${STEPS.length} · ${STEPS[step]}`} onClose={onClose} width={600}
      footer={<>
        {step > 0 && <button style={btn('ghost')} onClick={() => { setError(''); setStep(s => s - 1); }} disabled={busy}><ChevronLeft size={15} /> Back</button>}
        <div style={{ flex: 1 }} />
        {step < 3
          ? <button style={btn('primary')} onClick={next}>Next <ChevronRight size={15} /></button>
          : <button style={btn('primary')} onClick={create} disabled={busy}>{busy ? <Loader2 size={14} className="spin" /> : <Check size={15} />} Create business</button>}
      </>}>
      <div style={{ display: 'flex', gap: 6, marginBottom: 18 }}>
        {STEPS.map((s, i) => <div key={s} style={{ flex: 1, height: 4, borderRadius: 3, background: i <= step ? C.primary : C.border }} />)}
      </div>
      {error && <Notice>{error}</Notice>}

      {step === 0 && (
        <>
          <Field label="Business name *"><input style={inputStyle} autoFocus value={details.name} onChange={e => setDetails({ ...details, name: e.target.value })} placeholder="e.g. Sharma Electronics" /></Field>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}><Field label="Industry">
              <select style={inputStyle} value={details.industry} onChange={e => setDetails({ ...details, industry: e.target.value })}>
                <option value="">Select…</option>{INDUSTRIES.map(i => <option key={i}>{i}</option>)}
              </select></Field></div>
            <div style={{ flex: 1 }}><Field label="Website"><input style={inputStyle} value={details.website} onChange={e => setDetails({ ...details, website: e.target.value })} placeholder="https://" /></Field></div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}><Field label="Contact person"><input style={inputStyle} value={details.contactName} onChange={e => setDetails({ ...details, contactName: e.target.value })} /></Field></div>
            <div style={{ flex: 1 }}><Field label="Contact phone"><input style={inputStyle} value={details.contactPhone} onChange={e => setDetails({ ...details, contactPhone: e.target.value })} /></Field></div>
          </div>
          <Field label="Contact email"><input style={inputStyle} type="email" value={details.contactEmail} onChange={e => setDetails({ ...details, contactEmail: e.target.value })} /></Field>
          <Field label="Internal notes"><textarea style={{ ...inputStyle, height: 70, padding: 10, resize: 'vertical' }} value={details.notes} onChange={e => setDetails({ ...details, notes: e.target.value })} placeholder="Contract, onboarding notes, anything the team should know" /></Field>
        </>
      )}

      {step === 1 && (
        <>
          <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
            <button style={btn(!skipWa ? 'primary' : 'ghost', { flex: 1 })} onClick={() => setSkipWa(false)}>Connect Cloud API now</button>
            <button style={btn(skipWa ? 'primary' : 'ghost', { flex: 1 })} onClick={() => setSkipWa(true)}>Connect later</button>
          </div>
          {skipWa
            ? <Notice kind="warn">The business will be created in <b>Onboarding</b>. Its automation stays a draft until a number is connected.</Notice>
            : <WhatsAppFields wa={wa} setWa={(v) => { setWa(v); setTest(null); }} onTest={runTest} testing={testing} test={test} />}
        </>
      )}

      {step === 2 && (
        <>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, fontWeight: 600, marginBottom: 12, cursor: 'pointer' }}>
            <input type="checkbox" checked={autoOn} onChange={e => setAutoOn(e.target.checked)} /> Create a starter automation for this business
          </label>
          {autoOn && (
            <>
              <Field label="Automation name" hint="Each business gets its own separate automation flows."><input style={inputStyle} value={autoName} onChange={e => setAutoName(e.target.value)} placeholder={defaultAutoName} /></Field>
              <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Start from</div>
              {[{ id: '', name: 'Blank "hi" greeting', description: 'A simple hi → greeting flow you can edit.' }, ...templates].map(t => (
                <div key={t.id} onClick={() => setTemplateId(String(t.id))} style={{
                  border: `1.5px solid ${String(templateId) === String(t.id) ? C.primary : C.border}`, borderRadius: 3,
                  padding: '9px 12px', marginBottom: 7, cursor: 'pointer', background: String(templateId) === String(t.id) ? C.primaryLight : C.cardBg,
                }}>
                  <div style={{ fontSize: 13, fontWeight: 700 }}>{t.name}</div>
                  <div style={{ fontSize: 12, color: C.textSecondary }}>{t.description}</div>
                </div>
              ))}
              <div style={{ fontSize: 11.5, color: C.textMuted }}>You can edit it afterwards in the business's Automations builder.</div>
            </>
          )}
        </>
      )}

      {step === 3 && (
        <>
          {canPickTeam && (
            <>
              <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Team members who can work on this business</div>
              <div style={{ fontSize: 11.5, color: C.textMuted, marginBottom: 8 }}>Admins always have access to every business.</div>
              <div style={{ maxHeight: 150, overflowY: 'auto', border: `1px solid ${C.border}`, borderRadius: 3, marginBottom: 16 }}>
                {users.length === 0 && <div style={{ padding: 12, fontSize: 12.5, color: C.textMuted }}>No non-admin team members yet (add them in Settings → Users).</div>}
                {users.map(u => (
                  <label key={u.id} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '8px 12px', fontSize: 13, cursor: 'pointer', borderBottom: `1px solid ${C.border}` }}>
                    <input type="checkbox" checked={memberIds.includes(u.id)} onChange={e => setMemberIds(e.target.checked ? [...memberIds, u.id] : memberIds.filter(x => x !== u.id))} />
                    <span style={{ fontWeight: 600 }}>{u.displayName}</span><span style={{ color: C.textMuted }}>{u.email}</span>
                  </label>
                ))}
              </div>
            </>
          )}
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>Review</div>
          <div style={{ border: `1px solid ${C.border}`, borderRadius: 3, padding: '4px 14px', fontSize: 13 }}>
            {[
              ['Business', details.name || '—'],
              ['Industry', details.industry || '—'],
              ['Contact', [details.contactName, details.contactPhone].filter(Boolean).join(' · ') || '—'],
              ['WhatsApp', skipWa ? 'Connect later' : `Phone Number ID ${wa.phoneNumberId}`],
              ['Automation', autoOn ? (autoName.trim() || defaultAutoName) : 'None'],
              ['Team', canPickTeam ? `${memberIds.length} member(s)` : 'Admins'],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', padding: '8px 0', borderBottom: `1px solid ${C.border}` }}>
                <div style={{ width: 100, color: C.textSecondary }}>{k}</div><div style={{ flex: 1, fontWeight: 600, wordBreak: 'break-word' }}>{v}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </Modal>
  );
}

/* ───────────────────────── other modals ───────────────────────── */

function EditBusinessModal({ id, onClose, onSaved, isAdmin }) {
  const [b, setB] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { api.businesses.get(id).then(setB).catch(e => setError(errMsg(e))); }, [id]);
  const save = async () => {
    setBusy(true); setError('');
    try {
      await api.businesses.update(id, {
        name: b.name, industry: b.industry, website: b.website, contactName: b.contactName, contactEmail: b.contactEmail,
        contactPhone: b.contactPhone, address: b.address, timezone: b.timezone, notes: b.notes, logoUrl: b.logoUrl, plan: b.plan,
        ...(isAdmin ? { dailyMessageLimit: b.dailyMessageLimit ? String(b.dailyMessageLimit) : '' } : {}),
      });
      onSaved(); onClose();
    } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  const set = (k) => (e) => setB({ ...b, [k]: e.target.value });
  return (
    <Modal title="Edit business" onClose={onClose} footer={<><button style={btn('ghost')} onClick={onClose}>Cancel</button><button style={btn('primary')} onClick={save} disabled={busy || !b}>Save changes</button></>}>
      {error && <Notice>{error}</Notice>}
      {!b ? <div style={{ color: C.textMuted, fontSize: 13 }}>Loading…</div> : (
        <>
          <Field label="Business name"><input style={inputStyle} value={b.name || ''} onChange={set('name')} /></Field>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}><Field label="Industry"><input style={inputStyle} value={b.industry || ''} onChange={set('industry')} /></Field></div>
            <div style={{ flex: 1 }}><Field label="Plan"><input style={inputStyle} value={b.plan || ''} onChange={set('plan')} /></Field></div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <div style={{ flex: 1 }}><Field label="Contact person"><input style={inputStyle} value={b.contactName || ''} onChange={set('contactName')} /></Field></div>
            <div style={{ flex: 1 }}><Field label="Contact phone"><input style={inputStyle} value={b.contactPhone || ''} onChange={set('contactPhone')} /></Field></div>
          </div>
          {isAdmin && (
            <Field label="Daily message limit" hint="Max WhatsApp messages this business can SEND per day (automations, AI, chats and bulk together). Resets at midnight in the business time zone. Leave blank for unlimited.">
              <input style={inputStyle} type="number" min="1" step="1" value={b.dailyMessageLimit || ''} onChange={set('dailyMessageLimit')} placeholder="Unlimited" />
            </Field>
          )}
          <Field label="Contact email"><input style={inputStyle} value={b.contactEmail || ''} onChange={set('contactEmail')} /></Field>
          <Field label="Website"><input style={inputStyle} value={b.website || ''} onChange={set('website')} /></Field>
          <Field label="Logo URL"><input style={inputStyle} value={b.logoUrl || ''} onChange={set('logoUrl')} placeholder="https://…/logo.png" /></Field>
          <Field label="Notes"><textarea style={{ ...inputStyle, height: 70, padding: 10, resize: 'vertical' }} value={b.notes || ''} onChange={set('notes')} /></Field>
        </>
      )}
    </Modal>
  );
}

function ConnectWhatsAppModal({ biz, onClose, onSaved }) {
  const [detail, setDetail] = useState(null);
  const [wa, setWa] = useState(EMPTY_WA);
  const [test, setTest] = useState(null);
  const [testing, setTesting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(null);
  useEffect(() => { api.businesses.get(biz.id).then(setDetail).catch(() => {}); }, [biz.id]);

  const runTest = async () => {
    setTesting(true); setTest(null);
    try { setTest(await api.businesses.testWhatsapp(wa.phoneNumberId.trim(), wa.accessToken.trim())); }
    catch (e) { setTest({ ok: false, error: errMsg(e) }); } finally { setTesting(false); }
  };
  const save = async () => {
    setBusy(true); setError('');
    try { setSaved(await api.businesses.connectWhatsapp(biz.id, wa)); onSaved(); }
    catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  const remove = async (acc) => {
    if (!window.confirm(`Disconnect ${acc.displayPhoneNumber || acc.displayName}?`)) return;
    try { await api.businesses.removeWhatsapp(biz.id, acc.id); onSaved(); setDetail(await api.businesses.get(biz.id)); }
    catch (e) { setError(errMsg(e)); }
  };

  return (
    <Modal title={`WhatsApp · ${biz.name}`} subtitle="Connect or update a WhatsApp Cloud API number" onClose={onClose}
      footer={saved ? <button style={btn('primary')} onClick={onClose}>Done</button>
        : <><button style={btn('ghost')} onClick={onClose}>Cancel</button>
          <button style={btn('primary')} onClick={save} disabled={busy || !wa.phoneNumberId || !wa.wabaId || !wa.accessToken}>{busy ? 'Verifying…' : 'Connect number'}</button></>}>
      {error && <Notice>{error}</Notice>}
      {saved ? (
        <>
          <Notice kind="ok">Connected <b>{saved.account.displayPhoneNumber ? `+${saved.account.displayPhoneNumber}` : saved.account.displayName}</b>.</Notice>
          <div style={{ fontSize: 12.5, color: C.textSecondary, marginBottom: 10 }}>Make sure this webhook is set in Meta (subscribe to <b>messages</b>):</div>
          <CopyBox label="Callback URL" value={saved.webhook.callbackUrl} />
          {wa.verifyToken && <CopyBox label="Verify token" value={wa.verifyToken} />}
        </>
      ) : (
        <>
          {detail?.accounts?.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 6 }}>Connected numbers</div>
              {detail.accounts.map(a => (
                <div key={a.id} style={{ display: 'flex', alignItems: 'center', gap: 10, border: `1px solid ${C.border}`, borderRadius: 3, padding: '8px 12px', marginBottom: 6, fontSize: 13 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 3, background: (HEALTH[a.healthStatus] || HEALTH.unknown).color }} />
                  <div style={{ flex: 1 }}><b>{a.displayPhoneNumber ? `+${a.displayPhoneNumber}` : a.displayName}</b>
                    <div style={{ fontSize: 11.5, color: C.textMuted }}>{a.isDefault ? 'Default · ' : ''}{(HEALTH[a.healthStatus] || HEALTH.unknown).label} · token {a.tokenMasked}</div></div>
                  {detail.accounts.length > 1 && <button style={btn('ghost', { height: 28, padding: '0 9px', fontSize: 12 })} onClick={() => remove(a)}>Remove</button>}
                </div>
              ))}
              <div style={{ fontSize: 11.5, color: C.textMuted }}>To refresh an expired token, enter the same Phone Number ID below with the new token.</div>
            </div>
          )}
          <WhatsAppFields wa={wa} setWa={(v) => { setWa(v); setTest(null); }} onTest={runTest} testing={testing} test={test} />
        </>
      )}
    </Modal>
  );
}

function TeamAccessModal({ biz, onClose, onSaved }) {
  const [users, setUsers] = useState([]);
  const [sel, setSel] = useState({}); // userId -> role
  const [roles, setRoles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    Promise.all([api.users.list(), api.businesses.members(biz.id), api.permissionCatalog()]).then(([u, m, cat]) => {
      setRoles(cat.roles || []);
      setUsers((Array.isArray(u) ? u : u.users || []).filter(x => x.isActive !== false));
      setSel(Object.fromEntries(m.map(x => [x.userId, x.role])));
    }).catch(e => setError(errMsg(e)));
  }, [biz.id]);
  const save = async () => {
    setBusy(true); setError('');
    try {
      await api.businesses.setMembers(biz.id, Object.entries(sel).map(([userId, role]) => ({ userId: Number(userId), role })));
      onSaved(); onClose();
    } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  return (
    <Modal title={`Team access · ${biz.name}`} subtitle="Choose which team members can open this business" onClose={onClose}
      footer={<><button style={btn('ghost')} onClick={onClose}>Cancel</button><button style={btn('primary')} onClick={save} disabled={busy}>Save access</button></>}>
      {error && <Notice>{error}</Notice>}
      <div style={{ border: `1px solid ${C.border}`, borderRadius: 3 }}>
        {users.map(u => (
          <div key={u.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderBottom: `1px solid ${C.border}`, fontSize: 13 }}>
            <input type="checkbox" disabled={u.role === 'admin'} checked={u.role === 'admin' || sel[u.id] != null}
              onChange={e => { const n = { ...sel }; if (e.target.checked) n[u.id] = 'support_agent'; else delete n[u.id]; setSel(n); }} />
            <div style={{ flex: 1 }}><b>{u.displayName}</b><div style={{ fontSize: 11.5, color: C.textMuted }}>{u.email} · {u.role}</div></div>
            {u.role === 'admin' ? <span style={{ fontSize: 11.5, color: C.textMuted }}>All businesses</span> : sel[u.id] != null && (
              <select value={sel[u.id]} onChange={e => setSel({ ...sel, [u.id]: e.target.value })} style={{ ...inputStyle, width: 160, height: 30 }}>
                {roles.map(r => <option key={r.key} value={r.key}>{r.label}</option>)}
              </select>
            )}
          </div>
        ))}
      </div>
      <div style={{ fontSize: 11.5, color: C.textMuted, marginTop: 8, lineHeight: 1.5 }}>
        {roles.map(r => <div key={r.key}><b>{r.label}</b> — {r.description}</div>)}
        <div style={{ marginTop: 6 }}>To fine-tune individual permissions, use <b>Team → Edit member</b>.</div>
      </div>
    </Modal>
  );
}

function AutomationModal({ biz, onClose, onSaved, onOpen }) {
  const [templates, setTemplates] = useState([]);
  const [name, setName] = useState(`${biz.name} – `);
  const [templateId, setTemplateId] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { api.businesses.automationTemplates().then(setTemplates).catch(() => {}); }, []);
  const save = async () => {
    setBusy(true); setError('');
    try { await api.businesses.addAutomation(biz.id, { name, templateId: templateId || undefined }); onSaved(); onOpen(biz.id, 'chatbot-builder'); onClose(); }
    catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  return (
    <Modal title={`New automation · ${biz.name}`} subtitle="A separate flow that only runs for this business" onClose={onClose}
      footer={<><button style={btn('ghost')} onClick={onClose}>Cancel</button><button style={btn('primary')} onClick={save} disabled={busy || !name.trim()}>Create & open builder</button></>}>
      {error && <Notice>{error}</Notice>}
      <Field label="Automation name"><input style={inputStyle} value={name} onChange={e => setName(e.target.value)} autoFocus /></Field>
      <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Start from</div>
      {[{ id: '', name: 'Blank greeting', description: 'hi → greeting message' }, ...templates].map(t => (
        <div key={t.id} onClick={() => setTemplateId(String(t.id))} style={{ border: `1.5px solid ${String(templateId) === String(t.id) ? C.primary : C.border}`, borderRadius: 3, padding: '9px 12px', marginBottom: 7, cursor: 'pointer' }}>
          <div style={{ fontSize: 13, fontWeight: 700 }}>{t.name}</div><div style={{ fontSize: 12, color: C.textSecondary }}>{t.description}</div>
        </div>
      ))}
    </Modal>
  );
}

function ActivityModal({ biz, onClose }) {
  const [rows, setRows] = useState(null);
  useEffect(() => { api.businesses.auditLog(biz.id).then(setRows).catch(() => setRows([])); }, [biz.id]);
  return (
    <Modal title={`Activity · ${biz.name}`} subtitle="Who changed what" onClose={onClose} footer={<button style={btn('ghost')} onClick={onClose}>Close</button>}>
      {rows == null ? <div style={{ color: C.textMuted, fontSize: 13 }}>Loading…</div> : rows.length === 0 ? <div style={{ color: C.textMuted, fontSize: 13 }}>Nothing yet.</div> : rows.map(r => (
        <div key={r.id} style={{ display: 'flex', gap: 10, padding: '8px 0', borderBottom: `1px solid ${C.border}`, fontSize: 13 }}>
          <div style={{ width: 150, color: C.textMuted, fontSize: 12 }}>{new Date(r.at).toLocaleString('en-IN')}</div>
          <div style={{ flex: 1 }}><b>{r.action}</b>{r.by ? ` · ${r.by}` : ''}</div>
        </div>
      ))}
    </Modal>
  );
}

function ArchiveModal({ biz, onClose, onDone }) {
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const go = async () => {
    setBusy(true); setError('');
    try { await api.businesses.archive(biz.id, text.trim()); onDone(); onClose(); }
    catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };
  return (
    <Modal title="Archive business" onClose={onClose} width={480}
      footer={<><button style={btn('ghost')} onClick={onClose}>Cancel</button><button style={btn('danger')} disabled={busy || text.trim() !== biz.slug} onClick={go}>Archive</button></>}>
      {error && <Notice>{error}</Notice>}
      <Notice kind="warn"><b>{biz.name}</b> will disappear from the dashboard and its WhatsApp numbers will stop receiving messages. Data is kept.</Notice>
      <Field label={<>Type <code>{biz.slug}</code> to confirm</>}><input style={inputStyle} value={text} onChange={e => setText(e.target.value)} /></Field>
    </Modal>
  );
}

/* ───────────────────────── CRM connection ───────────────────────── */

function SecretBox({ label, value, hint }) {
  const [show, setShow] = useState(false);
  const [done, setDone] = useState(false);
  return (
    <div style={{ marginBottom: 12 }}>
      <div style={{ fontSize: 11.5, fontWeight: 600, color: C.textSecondary, marginBottom: 4 }}>{label}</div>
      <div style={{ display: 'flex', gap: 6 }}>
        <input readOnly type={show ? 'text' : 'password'} value={value} style={{ ...inputStyle, fontFamily: 'ui-monospace, monospace', fontSize: 12 }} onFocus={e => e.target.select()} />
        <button style={btn('ghost', { height: 38 })} onClick={() => setShow(v => !v)}>{show ? 'Hide' : 'Show'}</button>
        <button style={btn('ghost', { height: 38 })} onClick={() => { navigator.clipboard?.writeText(value); setDone(true); setTimeout(() => setDone(false), 1500); }}>
          {done ? <Check size={14} /> : <Copy size={14} />}
        </button>
      </div>
      {hint && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 4 }}>{hint}</div>}
    </div>
  );
}

// "Connect to CRM": Rarevo generates an API URL + API key + API password for THIS business.
// Paste them into the Rarevo CRM — it can then read (view only) this business's leads.
// The credentials are saved until you press Disconnect.
function CrmModal({ biz, onClose, onChanged }) {
  const [d, setD] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState('');
  const load = useCallback(() => { api.businesses.crmConnection(biz.id).then(setD).catch(e => setError(errMsg(e))); }, [biz.id]);
  useEffect(load, [load]);

  const run = async (fn) => {
    setBusy(true); setError('');
    try { const r = await fn(); setD(r); setConfirm(''); onChanged(); } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };

  return (
    <Modal title={`Connect to CRM · ${biz.name}`} subtitle="View-only link — the CRM can read this business's leads, never change them" onClose={onClose} width={640}
      footer={<>
        {d?.connected && confirm !== 'ask' && <button style={btn('ghost', { color: '#DC2626' })} disabled={busy} onClick={() => setConfirm('ask')}>Disconnect</button>}
        {confirm === 'ask' && <>
          <span style={{ fontSize: 12.5, color: '#B91C1C' }}>Delete the key and stop CRM access?</span>
          <button style={btn('ghost')} onClick={() => setConfirm('')}>No</button>
          <button style={btn('danger')} disabled={busy} onClick={() => run(() => api.businesses.disconnectCrm(biz.id))}>Yes, disconnect</button>
        </>}
        <div style={{ flex: 1 }} />
        <button style={btn('ghost')} onClick={onClose}>Close</button>
      </>}>
      {error && <Notice>{error}</Notice>}
      {!d && !error && <div style={{ color: C.textMuted, fontSize: 13 }}>Loading…</div>}

      {d && !d.connected && (
        <>
          <Notice kind="warn">This business is <b>not connected</b> to a CRM yet. Click <b>Generate connection</b> to create an API key and password, then enter them in the Rarevo CRM.</Notice>
          <div style={{ fontSize: 13, color: C.textSecondary, lineHeight: 1.55, marginBottom: 14 }}>
            The CRM will be able to fetch every lead (name, number, tags, last message) for <b>{biz.name}</b> only. It cannot send messages or edit anything.
          </div>
          <button style={btn('primary')} disabled={busy} onClick={() => run(() => api.businesses.connectCrm(biz.id))}>
            {busy ? <Loader2 size={14} className="spin" /> : <Link2 size={14} />} Generate connection
          </button>
        </>
      )}

      {d?.connected && (
        <>
          <Notice kind="ok">Connected{d.connectedAt ? ` ${relativeTime(d.connectedAt)}` : ''}. {d.lastUsedAt ? `Last fetched by the CRM ${relativeTime(d.lastUsedAt)} (${fmt(d.requestCount)} requests).` : 'The CRM has not fetched data yet.'} Credentials stay saved until you disconnect.</Notice>
          <CopyBox label="API URL" value={d.apiUrl} />
          <SecretBox label="API key" value={d.apiKey} />
          <SecretBox label="API password" value={d.apiPassword} hint="Enter the API URL, key and password in the CRM's “Connect Rarevo” screen." />
          <div style={{ background: C.surfaceAlt, border: `1px solid ${C.border}`, borderRadius: 3, padding: '10px 12px', fontSize: 12, color: C.textSecondary, lineHeight: 1.6 }}>
            <b style={{ color: C.text }}>For the CRM developer</b> — send two headers on every GET request:<br />
            <code>Authorization: Bearer &lt;API key&gt;</code> · <code>X-Api-Password: &lt;API password&gt;</code><br />
            <code>GET /contacts</code> (leads, paged) · <code>/contacts/:number</code> · <code>/contacts/:number/messages</code> · <code>/summary</code> · <code>/ping</code>
          </div>
          <div style={{ marginTop: 12 }}>
            <button style={btn('ghost')} disabled={busy} onClick={() => { if (window.confirm('Regenerate? The old key and password stop working immediately.')) run(() => api.businesses.connectCrm(biz.id)); }}>
              Regenerate key & password
            </button>
          </div>
        </>
      )}
    </Modal>
  );
}

/* ───────────────────────── business card ───────────────────────── */

function CardMenu({ items, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [onClose]);
  return (
    <div ref={ref} style={{
      position: 'absolute', top: 38, right: 10, zIndex: 20, width: 214, background: C.cardBg, borderRadius: 3,
      border: `1px solid ${C.border}`, boxShadow: C.shadowMd, padding: 5, fontFamily: FONT,
    }}>
      {items.filter(Boolean).map((it, i) => it.divider
        ? <div key={i} style={{ height: 1, background: C.border, margin: '4px 0' }} />
        : (
          <div key={it.label} onClick={() => { onClose(); it.onClick(); }} style={{
            display: 'flex', alignItems: 'center', gap: 9, padding: '8px 10px', borderRadius: 3, fontSize: 13, cursor: 'pointer',
            color: it.danger ? '#DC2626' : C.text, fontWeight: 500,
          }} onMouseEnter={e => e.currentTarget.style.background = C.hover} onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            <it.Icon size={14} />{it.label}
          </div>
        ))}
    </div>
  );
}

function BusinessCard({ b, isAdmin, onOpen, onAction }) {
  const [menu, setMenu] = useState(false);
  const st = STATUS_STYLE[b.status] || STATUS_STYLE.active;
  const main = b.accounts?.[0];
  const health = main ? (HEALTH[main.healthStatus] || HEALTH.unknown) : null;
  const canManage = isAdmin || b.myRole === 'business_manager';
  const Stat = ({ Icon, value, label }) => (
    <div style={{ flex: 1, textAlign: 'center' }}>
      <div style={{ fontSize: 16, fontWeight: 800, color: C.text, letterSpacing: '-.01em' }}>{value}</div>
      <div style={{ fontSize: 10.5, color: C.textMuted, display: 'flex', gap: 3, justifyContent: 'center', alignItems: 'center' }}><Icon size={10} />{label}</div>
    </div>
  );
  const items = [
    { label: 'Open workspace', Icon: ExternalLink, onClick: () => onOpen(b.id, 'home') },
    { divider: true },
    canManage && { label: 'Edit details', Icon: Pencil, onClick: () => onAction('edit', b) },
    isAdmin && { label: 'Connect WhatsApp', Icon: Phone, onClick: () => onAction('whatsapp', b) },
    canManage && { label: b.crmConnected ? 'CRM connection' : 'Connect to CRM', Icon: Link2, onClick: () => onAction('crm', b) },
    canManage && { label: 'Add automation', Icon: Zap, onClick: () => onAction('automation', b) },
    isAdmin && { label: 'Team access', Icon: UserCog, onClick: () => onAction('team', b) },
    { divider: true },
    isAdmin && (b.status === 'paused'
      ? { label: 'Resume business', Icon: Play, onClick: () => onAction('resume', b) }
      : { label: 'Pause business', Icon: Pause, onClick: () => onAction('pause', b) }),
    isAdmin && { label: 'Activity log', Icon: History, onClick: () => onAction('activity', b) },
    isAdmin && { label: 'Archive', Icon: Archive, danger: true, onClick: () => onAction('archive', b) },
  ];
  return (
    <div style={{
      position: 'relative', background: C.cardBg, border: `1px solid ${C.border}`, borderRadius: 3, padding: 16,
      boxShadow: C.shadowSm, display: 'flex', flexDirection: 'column', gap: 12, fontFamily: FONT, opacity: b.status === 'paused' ? 0.82 : 1,
    }}>
      <button aria-label="More actions" onClick={() => setMenu(m => !m)} style={{
        position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: 3, border: 'none', background: menu ? C.hover : 'transparent', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', color: C.textSecondary,
      }}><MoreVertical size={17} /></button>
      {menu && <CardMenu items={items} onClose={() => setMenu(false)} />}

      <div style={{ display: 'flex', gap: 12, alignItems: 'center', paddingRight: 28 }}>
        <Avatar b={b} />
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 800, color: C.text, letterSpacing: '-.01em', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{b.name}</div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginTop: 3 }}>
            <span style={{ fontSize: 11, fontWeight: 700, background: st.bg, color: st.fg, padding: '2px 8px', borderRadius: 3 }}>{st.label}</span>
            {b.industry && <span style={{ fontSize: 11.5, color: C.textMuted }}>{b.industry}</span>}
          </div>
        </div>
      </div>

      {main ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: C.surfaceAlt, borderRadius: 3, padding: '8px 10px', fontSize: 12.5 }}>
          <Phone size={13} color={C.textSecondary} />
          <b style={{ flex: 1 }}>{main.displayPhoneNumber ? `+${main.displayPhoneNumber}` : main.displayName}{b.accounts.length > 1 ? ` (+${b.accounts.length - 1})` : ''}</b>
          <span title={health.label} style={{ display: 'flex', alignItems: 'center', gap: 5, color: C.textSecondary, fontSize: 11.5 }}>
            <span style={{ width: 8, height: 8, borderRadius: 3, background: health.color }} />{health.label}
          </span>
        </div>
      ) : (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#FFFBEB', borderRadius: 3, padding: '8px 10px', fontSize: 12.5, color: '#92400E' }}>
          <AlertTriangle size={13} /><span style={{ flex: 1 }}>WhatsApp not connected</span>
          {isAdmin && <button onClick={() => onAction('whatsapp', b)} style={{ ...btn('ghost', { height: 26, padding: '0 9px', fontSize: 11.5 }) }}>Connect</button>}
        </div>
      )}

      <div style={{ display: 'flex', borderTop: `1px solid ${C.border}`, borderBottom: `1px solid ${C.border}`, padding: '10px 0' }}>
        <Stat Icon={Users} value={fmt(b.stats.contacts)} label="Contacts" />
        <Stat Icon={MessageCircle} value={fmt(b.stats.messages7d)} label="Msgs 7d" />
        <Stat Icon={Zap} value={`${b.stats.automationsActive}/${b.stats.automationsTotal}`} label="Automations" />
        <Stat Icon={KanbanSquare} value={fmt(b.stats.openDeals)} label="Open deals" />
      </div>

      {(() => {
        const lim = b.dailyMessageLimit; const used = b.stats.sentToday || 0;
        const pct = lim ? Math.min(100, Math.round((used / lim) * 100)) : 0;
        const hot = lim && used >= lim; const warn = lim && pct >= 80;
        return (
          <div style={{ marginBottom: 10 }}>
            <div style={{ display: 'flex', fontSize: 11.5, color: hot ? '#B91C1C' : C.textSecondary, fontWeight: 600, marginBottom: 4 }}>
              <span style={{ flex: 1 }}>Sent today</span>
              <span>{fmt(used)}{lim ? ` / ${fmt(lim)}` : ' · no limit'}{hot ? ' · LIMIT REACHED' : ''}</span>
            </div>
            {lim && <div style={{ height: 5, background: C.hover, borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: `${pct}%`, height: '100%', background: hot ? '#DC2626' : warn ? '#D97706' : '#16A34A' }} />
            </div>}
          </div>
        );
      })()}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ flex: 1, fontSize: 11.5, color: C.textMuted }}>{b.stats.lastActivity ? `Last activity ${relativeTime(b.stats.lastActivity)}` : 'No activity yet'}</div>
        <button style={btn('ghost', { height: 32, padding: '0 11px', fontSize: 12.5 })} onClick={() => onAction('crm', b)}><Link2 size={13} /> {b.crmConnected ? 'CRM ✓' : 'CRM'}</button>
        <button style={btn('primary', { height: 32, padding: '0 12px', fontSize: 12.5 })} onClick={() => onOpen(b.id, 'home')}>Open <ChevronRight size={14} /></button>
      </div>
    </div>
  );
}


/* ───────────────────────── bulk import ───────────────────────── */

const IMPORT_COLS = ['name', 'industry', 'contactName', 'contactPhone', 'contactEmail', 'website', 'notes', 'phoneNumberId', 'wabaId', 'accessToken', 'verifyToken'];
const norm = (h) => String(h || '').toLowerCase().replace(/[^a-z]/g, '');
const COL_BY_NORM = Object.fromEntries(IMPORT_COLS.map(c => [norm(c), c]).concat([['business', 'name'], ['store', 'name'], ['storename', 'name'], ['businessname', 'name'], ['phone', 'contactPhone'], ['email', 'contactEmail'], ['contact', 'contactName'], ['token', 'accessToken'], ['waba', 'wabaId'], ['phonenumberid', 'phoneNumberId']]));

function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',' || ch === '\t') { row.push(cell); cell = ''; }
    else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(cell); cell = ''; if (row.some(c => c.trim())) rows.push(row); row = []; }
    else cell += ch;
  }
  row.push(cell); if (row.some(c => c.trim())) rows.push(row);
  return rows;
}

function ImportModal({ onClose, onDone }) {
  const [text, setText] = useState('');
  const [progress, setProgress] = useState(null);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const parsed = useMemo(() => {
    const t = parseCsv(text);
    if (t.length < 2) return { rows: [], unknown: [] };
    const head = t[0].map(h => COL_BY_NORM[norm(h)] || null);
    const unknown = t[0].filter((h, i) => !head[i] && h.trim());
    const rows = t.slice(1).map(r => Object.fromEntries(head.map((c, i) => [c, (r[i] || '').trim()]).filter(([c]) => c)));
    return { rows, unknown, hasName: head.includes('name') };
  }, [text]);

  const template = () => {
    const csv = IMPORT_COLS.join(',') + '\nSharma Electronics,Retail,Rahul Sharma,919800000000,rahul@example.com,,,109876543210987,102938475610293,EAAG...,my-verify-token\n';
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'businesses-template.csv'; a.click();
  };
  const onFile = (f) => { if (f) f.text().then(setText); };

  const run = async () => {
    setError(''); setResult(null);
    const all = []; let created = 0;
    try {
      const CH = 200;
      for (let i = 0; i < parsed.rows.length; i += CH) {
        setProgress({ done: i, total: parsed.rows.length });
        const r = await api.businesses.bulkImport(parsed.rows.slice(i, i + CH));
        created += r.created;
        r.results.forEach(x => all.push({ ...x, row: x.row + i }));
      }
      setProgress(null);
      setResult({ created, failed: all.filter(x => !x.ok) });
      onDone();
    } catch (e) { setProgress(null); setError(errMsg(e)); }
  };

  return (
    <Modal title="Import businesses" subtitle="Add up to 1000 businesses at once from a CSV / spreadsheet" onClose={onClose} width={680}
      footer={result ? <button style={btn('primary')} onClick={onClose}>Done</button> : <>
        <button style={btn('ghost')} onClick={template}>Download template</button><div style={{ flex: 1 }} />
        <button style={btn('ghost')} onClick={onClose}>Cancel</button>
        <button style={btn('primary')} disabled={!parsed.rows.length || !parsed.hasName || !!progress} onClick={run}>
          {progress ? `Importing ${progress.done}/${progress.total}…` : `Import ${parsed.rows.length || ''} business(es)`}
        </button></>}>
      {error && <Notice>{error}</Notice>}
      {result ? (
        <>
          <Notice kind="ok"><b>{result.created}</b> business(es) created{result.failed.length ? `, ${result.failed.length} failed` : ''}.</Notice>
          {result.failed.slice(0, 50).map(f => <div key={f.row} style={{ fontSize: 12.5, color: '#B91C1C', padding: '3px 0' }}>Row {f.row}{f.name ? ` (${f.name})` : ''}: {f.error}</div>)}
          <Notice kind="warn">Imported WhatsApp credentials are saved but not yet checked with Meta. Use a card's ⋮ → <b>Connect WhatsApp</b> to verify a number.</Notice>
        </>
      ) : (
        <>
          <div style={{ fontSize: 12.5, color: C.textSecondary, marginBottom: 8, lineHeight: 1.5 }}>
            First row = column names. Only <b>name</b> is required. Add <b>phoneNumberId, wabaId, accessToken</b> to connect WhatsApp in the same step; rows without them are created as <i>Onboarding</i>.
          </div>
          <input type="file" accept=".csv,.tsv,.txt" onChange={e => onFile(e.target.files?.[0])} style={{ marginBottom: 8, fontSize: 12.5 }} />
          <textarea value={text} onChange={e => setText(e.target.value)} placeholder="…or paste rows here (comma or tab separated)" style={{ ...inputStyle, height: 160, padding: 10, fontFamily: 'ui-monospace, monospace', fontSize: 12 }} />
          {text && !parsed.hasName && <div style={{ marginTop: 8 }}><Notice>Couldn't find a <b>name</b> column in the first row.</Notice></div>}
          {parsed.unknown?.length > 0 && <div style={{ marginTop: 8 }}><Notice kind="warn">Ignoring unknown columns: {parsed.unknown.join(', ')}</Notice></div>}
          {parsed.rows.length > 0 && parsed.hasName && <div style={{ marginTop: 8, fontSize: 12.5, color: C.textSecondary }}>{parsed.rows.length} row(s) ready. First: <b>{parsed.rows[0].name}</b></div>}
        </>
      )}
    </Modal>
  );
}

/* ───────────────────────── page ───────────────────────── */

export default function BusinessesPage({ user, onOpenBusiness, onNavigate }) {
  const isAdmin = user?.role === 'admin';
  const [data, setData] = useState(null); // { items, total, page, pageSize, counts }
  const [overview, setOverview] = useState(null);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  const [dq, setDq] = useState('');
  const [filter, setFilter] = useState('all');
  const [page, setPage] = useState(1);
  const [modal, setModal] = useState(null); // { type, biz? }
  const PAGE_SIZE = 24;

  // debounce the search box so typing doesn't hit the server on every key
  useEffect(() => { const t = setTimeout(() => { setDq(q.trim()); setPage(1); }, 250); return () => clearTimeout(t); }, [q]);

  const load = useCallback(async () => {
    try {
      setData(await api.businesses.list({ page, pageSize: PAGE_SIZE, q: dq, status: filter }));
      setError('');
      if (isAdmin) api.businesses.overview().then(setOverview).catch(() => {});
    } catch (e) { setError(errMsg(e)); setData(d => d || { items: [], total: 0, counts: {} }); }
  }, [isAdmin, page, dq, filter]);
  useEffect(() => { load(); }, [load]);

  const list = data?.items || null;
  const shown = list || [];
  const counts = { all: 0, active: 0, onboarding: 0, paused: 0, ...(data?.counts || {}) };
  const totalPages = Math.max(1, Math.ceil((data?.total || 0) / PAGE_SIZE));

  const onAction = async (type, b) => {
    if (type === 'pause' || type === 'resume') {
      try { await api.businesses.setStatus(b.id, type === 'pause' ? 'paused' : 'active'); load(); } catch (e) { setError(errMsg(e)); }
      return;
    }
    setModal({ type, biz: b });
  };
  const close = () => setModal(null);
  const Stat = ({ label, value, sub, warn }) => (
    <div style={{ flex: 1, minWidth: 150, background: C.cardBg, border: `1px solid ${warn ? '#FCA5A5' : C.border}`, borderRadius: 3, padding: '12px 15px' }}>
      <div style={{ fontSize: 11.5, color: C.textSecondary, fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-.02em', color: warn ? '#B91C1C' : C.text }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: C.textMuted }}>{sub}</div>}
    </div>
  );

  return (
    <div style={{ padding: '26px 30px 40px', fontFamily: FONT, maxWidth: 1400, width: '100%', boxSizing: 'border-box' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap', marginBottom: 18 }}>
        <div style={{ flex: 1, minWidth: 220 }}>
          <div style={{ fontSize: 24, fontWeight: 800, letterSpacing: '-.02em', color: C.text, display: 'flex', alignItems: 'center', gap: 10 }}><Building2 size={24} /> Businesses</div>
          <div style={{ fontSize: 13, color: C.textSecondary, marginTop: 3 }}>Every client you run on Rarevo — each with its own WhatsApp number, automations and a view-only CRM link.</div>
        </div>
        {isAdmin && onNavigate && <button style={btn('ghost', { height: 40, padding: '0 16px', fontSize: 13.5 })} onClick={() => onNavigate('team')}><UserCog size={15} /> Team</button>}
        {isAdmin && <button style={btn('ghost', { height: 40, padding: '0 16px', fontSize: 13.5 })} onClick={() => setModal({ type: 'import' })}>Import CSV</button>}
        {isAdmin && <button style={btn('primary', { height: 40, padding: '0 18px', fontSize: 14 })} onClick={() => setModal({ type: 'add', k: Date.now() })}><Plus size={16} /> Add Business</button>}
      </div>

      {error && <Notice>{error}</Notice>}

      {isAdmin && overview && (
        <>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 12 }}>
            <Stat label="Businesses" value={overview.businesses} sub={`${overview.active} active · ${overview.onboarding} onboarding · ${overview.paused} paused`} />
            <Stat label="WhatsApp numbers" value={overview.numbers} sub={overview.numbersUnhealthy ? `${overview.numbersUnhealthy} need attention` : 'All healthy'} warn={overview.numbersUnhealthy > 0} />
            <Stat label="Messages today" value={fmt(overview.messagesToday)} sub={`${fmt(overview.messages7d)} in 7 days`} />
            <Stat label="Contacts (all)" value={fmt(overview.contacts)} />
            <Stat label="Active automations" value={fmt(overview.automationsActive)} />
          </div>
          {overview.attention.length > 0 && (
            <Notice>
              <b>Needs attention:</b> {overview.attention.map(a => `${a.name} (${a.display_phone_number ? '+' + a.display_phone_number : 'number'} — ${(HEALTH[a.health_status] || {}).label || a.health_status})`).join(' · ')}
            </Notice>
          )}
        </>
      )}

      <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap', margin: '16px 0' }}>
        <div style={{ position: 'relative', width: 300, maxWidth: '100%' }}>
          <Search size={15} style={{ position: 'absolute', left: 11, top: 12, color: C.textMuted }} />
          <input style={{ ...inputStyle, paddingLeft: 33 }} placeholder="Search name, industry, number…" value={q} onChange={e => setQ(e.target.value)} />
        </div>
        {['all', 'active', 'onboarding', 'paused'].map(f => (
          <button key={f} onClick={() => { setFilter(f); setPage(1); }} style={btn(filter === f ? 'primary' : 'ghost', { height: 32, padding: '0 12px', fontSize: 12.5, textTransform: 'capitalize' })}>
            {f} <span style={{ opacity: .75 }}>{counts[f]}</span>
          </button>
        ))}
      </div>

      {data == null ? (
        <div style={{ color: C.textMuted, fontSize: 14, padding: 40, textAlign: 'center' }}>Loading businesses…</div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(330px, 1fr))', gap: 16 }}>
          {shown.map(b => <BusinessCard key={b.id} b={b} isAdmin={isAdmin} onOpen={onOpenBusiness} onAction={onAction} />)}
          {isAdmin && page === 1 && !dq && filter === 'all' && (
            <div onClick={() => setModal({ type: 'add', k: Date.now() })} style={{
              border: `2px dashed ${C.borderDark}`, borderRadius: 3, minHeight: 250, display: 'flex', flexDirection: 'column', gap: 8,
              alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: C.textSecondary, fontWeight: 700, fontSize: 14,
            }}>
              <div style={{ width: 44, height: 44, borderRadius: 3, background: C.primaryLight, color: C.primary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Plus size={22} /></div>
              Add Business
              <div style={{ fontSize: 12, fontWeight: 500, color: C.textMuted }}>Details · WhatsApp · Automation</div>
            </div>
          )}
          {shown.length === 0 && !isAdmin && (
            <div style={{ gridColumn: '1/-1', textAlign: 'center', color: C.textMuted, padding: 50, fontSize: 14 }}>
              <Sparkles size={22} style={{ marginBottom: 6 }} /><div>No businesses assigned to you yet. Ask an admin for access.</div>
            </div>
          )}
        </div>
      )}

      {data && data.total > PAGE_SIZE && (
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, marginTop: 22, fontSize: 13 }}>
          <button style={btn('ghost')} disabled={page <= 1} onClick={() => setPage(p => p - 1)}><ChevronLeft size={15} /> Prev</button>
          <span style={{ color: C.textSecondary }}>Page <b>{page}</b> of {totalPages} · {fmt(data.total)} businesses</span>
          <button style={btn('ghost')} disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next <ChevronRight size={15} /></button>
        </div>
      )}
      {data && data.total === 0 && (dq || filter !== 'all') && <div style={{ textAlign: 'center', color: C.textMuted, padding: 30, fontSize: 14 }}>No businesses match.</div>}

      {modal?.type === 'add' && <AddBusinessWizard key={modal.k} canPickTeam={isAdmin} onClose={close} onCreated={() => { setPage(1); setFilter('all'); setQ(''); load(); }} onAddAnother={() => setModal({ type: 'add', k: Date.now() })} />}
      {modal?.type === 'import' && <ImportModal onClose={close} onDone={() => { setPage(1); load(); }} />}
      {modal?.type === 'edit' && <EditBusinessModal id={modal.biz.id} onClose={close} onSaved={load} isAdmin={isAdmin} />}
      {modal?.type === 'whatsapp' && <ConnectWhatsAppModal biz={modal.biz} onClose={close} onSaved={load} />}
      {modal?.type === 'team' && <TeamAccessModal biz={modal.biz} onClose={close} onSaved={load} />}
      {modal?.type === 'automation' && <AutomationModal biz={modal.biz} onClose={close} onSaved={load} onOpen={onOpenBusiness} />}
      {modal?.type === 'activity' && <ActivityModal biz={modal.biz} onClose={close} />}
      {modal?.type === 'archive' && <ArchiveModal biz={modal.biz} onClose={close} onDone={load} />}
      {modal?.type === 'crm' && <CrmModal biz={modal.biz} onClose={close} onChanged={load} />}
    </div>
  );
}
