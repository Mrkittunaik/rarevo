import { useState } from 'react';
import { X, KeyRound, AlertTriangle } from 'lucide-react';
import { api } from '../api.js';
import { C, FONT } from '../constants.js';

const errMsg = (e) => {
  const raw = String(e?.message || e || 'Something went wrong');
  const m = raw.match(/^\d{3}\s+([\s\S]*)$/); const body = m ? m[1] : raw;
  try { const j = JSON.parse(body); if (j?.error) return j.error; } catch { /* plain text */ }
  return body;
};

const field = {
  width: '100%', height: 38, borderRadius: 3, border: `1.5px solid ${C.border}`, padding: '0 11px', fontFamily: FONT,
  fontSize: 13, background: C.cardBg, color: C.text, boxSizing: 'border-box', outline: 'none',
};

/** Slim, non-blocking reminder shown while the account still has an admin-set or default password. */
export function PasswordBanner({ user, onChange }) {
  if (!user?.mustChangePassword) return null;
  return (
    <div style={{ flexShrink: 0, background: '#FEF3C7', color: '#92400E', borderBottom: '1px solid #FDE68A', padding: '7px 18px', fontFamily: FONT, fontSize: 12.5, display: 'flex', alignItems: 'center', gap: 10 }}>
      <AlertTriangle size={14} />
      <span><b>Choose your own password.</b> This account is using a password that was set for you (or a known default).</span>
      <button onClick={onChange} style={{ marginLeft: 'auto', height: 26, padding: '0 12px', borderRadius: 3, border: 'none', background: '#92400E', color: '#fff', fontFamily: FONT, fontSize: 12, fontWeight: 700, cursor: 'pointer' }}>Change password</button>
    </div>
  );
}

export default function ChangePasswordModal({ onClose, onChanged }) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [again, setAgain] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  const save = async () => {
    setError('');
    if (next !== again) { setError('The new passwords do not match.'); return; }
    setBusy(true);
    try {
      await api.auth.changePassword(current, next);
      setDone(true); onChanged?.();
    } catch (e) { setError(errMsg(e)); } finally { setBusy(false); }
  };

  return (
    <div onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{ position: 'fixed', inset: 0, background: 'rgba(15,15,16,.55)', zIndex: 1100, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 16 }}>
      <div style={{ width: '100%', maxWidth: 420, background: C.cardBg, borderRadius: 3, boxShadow: C.shadowLg, fontFamily: FONT, overflow: 'hidden' }}>
        <div style={{ padding: '15px 20px', borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', gap: 8 }}>
          <KeyRound size={16} />
          <div style={{ flex: 1, fontSize: 16, fontWeight: 800 }}>Change password</div>
          <button onClick={onClose} aria-label="Close" style={{ width: 30, height: 30, border: `1.5px solid ${C.border}`, background: C.cardBg, borderRadius: 3, cursor: 'pointer' }}><X size={14} /></button>
        </div>
        {done ? (
          <div style={{ padding: 20 }}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 6 }}>Password changed</div>
            <div style={{ fontSize: 13, color: C.textSecondary, marginBottom: 16 }}>You were signed out of your other devices. This session stays signed in.</div>
            <button onClick={onClose} style={{ height: 36, padding: '0 16px', border: 'none', borderRadius: 3, background: C.primary, color: '#fff', fontFamily: FONT, fontSize: 13, fontWeight: 600, cursor: 'pointer' }}>Done</button>
          </div>
        ) : (
          <form onSubmit={e => { e.preventDefault(); if (!busy) save(); }} style={{ padding: 20, display: 'grid', gap: 12 }}>
            {error && <div style={{ background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 3, padding: '9px 12px', fontSize: 12.5 }}>{error}</div>}
            <label style={{ fontSize: 12, fontWeight: 600 }}>Current password
              <input style={{ ...field, marginTop: 5 }} type="password" value={current} onChange={e => setCurrent(e.target.value)} autoComplete="current-password" autoFocus />
            </label>
            <label style={{ fontSize: 12, fontWeight: 600 }}>New password
              <input style={{ ...field, marginTop: 5 }} type="password" value={next} onChange={e => setNext(e.target.value)} autoComplete="new-password" />
            </label>
            <label style={{ fontSize: 12, fontWeight: 600 }}>Repeat new password
              <input style={{ ...field, marginTop: 5 }} type="password" value={again} onChange={e => setAgain(e.target.value)} autoComplete="new-password" />
            </label>
            <div style={{ fontSize: 11.5, color: C.textMuted }}>At least 8 characters. Avoid common passwords and your email name.</div>
            <button type="submit" disabled={busy || !current || !next || !again}
              style={{ height: 38, border: 'none', borderRadius: 3, background: C.primary, color: '#fff', fontFamily: FONT, fontSize: 13, fontWeight: 700, cursor: 'pointer', opacity: busy || !current || !next || !again ? 0.6 : 1 }}>
              {busy ? 'Saving…' : 'Change password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
