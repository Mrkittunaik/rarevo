import {
  Home, Zap, LayoutTemplate, MessageCircle, Users,
  Megaphone, Image as ImageIcon, Info, KanbanSquare, Bot,
  ChevronLeft, ChevronRight, Building2, ArrowLeft, ClipboardList,
} from 'lucide-react';
import { C, FONT } from '../constants.js';

const NAV_ITEMS = [
  { id: 'home', label: 'Home', Icon: Home },
  { id: 'chatbot-builder', label: 'Automations', Icon: Zap },
  { id: 'ai-agent-builder', label: 'AI Agents', Icon: Bot },
  { id: 'template-builder', label: 'Template Builder', Icon: LayoutTemplate },
  { id: 'media-library', label: 'Media', Icon: ImageIcon },
  { id: 'chats', label: 'Chats', Icon: MessageCircle },
  { id: 'records', label: 'Records', Icon: ClipboardList },
  { id: 'contacts', label: 'Contacts', Icon: Users },
  { id: 'pipelines', label: 'Pipelines', Icon: KanbanSquare },
  { id: 'bulk-message', label: 'Bulk Message', Icon: Megaphone },
  { id: 'about', label: 'About Us', Icon: Info },
];

export default function Sidebar({ activePage, onPageChange, collapsed, setCollapsed, user, business, onAllBusinesses }) {
  // Admins see every nav item; other roles see only the pages granted to them
  // (user.pages from the session). Falls back to all items if pages is missing.
  const visibleItems = (user?.role === 'admin' || !Array.isArray(user?.pages))
    ? NAV_ITEMS
    : NAV_ITEMS.filter(item => user.pages.includes(item.id));
  return (
    <div style={{
      width: collapsed ? 68 : 224,
      minHeight: '100%',
      background: C.sidebarBg,
      borderRight: `1px solid ${C.sidebarBorder}`,
      display: 'flex',
      flexDirection: 'column',
      flexShrink: 0,
      transition: 'width .25s ease',
      overflow: 'hidden',
      position: 'relative',
    }}>
      {/* Current business + back to the platform dashboard */}
      <div
        onClick={onAllBusinesses}
        title="Back to all businesses"
        style={{
          margin: collapsed ? '10px 8px 0' : '12px 10px 0', padding: collapsed ? '9px 0' : '9px 12px', borderRadius: 3,
          background: '#fff', border: `1px solid ${C.sidebarBorder}`, cursor: 'pointer', display: 'flex', alignItems: 'center',
          gap: 9, justifyContent: collapsed ? 'center' : 'flex-start', fontFamily: FONT, overflow: 'hidden',
        }}
      >
        {collapsed ? <Building2 size={16} /> : (
          <>
            <ArrowLeft size={14} style={{ flexShrink: 0, color: '#888' }} />
            <div style={{ minWidth: 0, lineHeight: 1.2 }}>
              <div style={{ fontSize: 9.5, fontWeight: 700, color: '#999', letterSpacing: '.06em', textTransform: 'uppercase' }}>All businesses</div>
              <div style={{ fontSize: 13, fontWeight: 800, color: '#111', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{business?.name || 'Select…'}</div>
            </div>
          </>
        )}
      </div>

      {/* Nav items */}
      <div style={{ padding: collapsed ? '10px 8px' : '14px 10px', flex: 1 }}>
        {visibleItems.map(item => {
          const active = activePage === item.id;
          return (
            <div
              key={item.id}
              onClick={() => onPageChange(item.id)}
              title={collapsed ? item.label : ''}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: collapsed ? 0 : 11,
                padding: collapsed ? '11px 0' : '10px 12px',
                borderRadius: 3,
                cursor: 'pointer',
                transition: 'all .15s',
                marginBottom: 2,
                background: active ? C.primary : 'transparent',
                color: active ? '#fff' : '#111',
                justifyContent: collapsed ? 'center' : 'flex-start',
                fontFamily: FONT,
                fontSize: 13,
                fontWeight: active ? 700 : 500,
                whiteSpace: 'nowrap',
                overflow: 'hidden',
                userSelect: 'none',
              }}
              onMouseEnter={e => {
                if (!active) {
                  e.currentTarget.style.background = '#EFEEE6';
                  e.currentTarget.style.color = '#111';
                }
              }}
              onMouseLeave={e => {
                e.currentTarget.style.background = active ? C.primary : 'transparent';
                e.currentTarget.style.color = active ? '#fff' : '#111';
              }}
            >
              <span style={{
                width: 20,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                flexShrink: 0,
                opacity: active ? 1 : 0.75,
              }}>
                <item.Icon size={16} />
              </span>
              {!collapsed && <span style={{ letterSpacing: '-.01em' }}>{item.label}</span>}
            </div>
          );
        })}
      </div>

      {/* Collapse button + watermark */}
      <div style={{ borderTop: `1px solid #F0F0EA` }}>
        <div
          onClick={() => setCollapsed(p => !p)}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            padding: collapsed ? '12px 0' : '11px 14px',
            cursor: 'pointer',
            justifyContent: collapsed ? 'center' : 'flex-start',
            transition: 'background .15s',
          }}
          onMouseEnter={e => e.currentTarget.style.background = '#EFEEE6'}
          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
          title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          <span style={{ display: 'flex', alignItems: 'center', color: '#888', lineHeight: 1 }}>
            {collapsed ? <ChevronRight size={22} strokeWidth={2.5} /> : <ChevronLeft size={22} strokeWidth={2.5} />}
          </span>
          {!collapsed && (
            <span style={{ fontSize: 15, fontWeight: 600, color: '#888', fontFamily: FONT, lineHeight: 1 }}>
              Collapse
            </span>
          )}
        </div>
        {!collapsed && (
          <div style={{ padding: '0 14px 10px' }}>
            <span style={{
              fontSize: 9,
              fontWeight: 600,
              color: '#ccc',
              fontFamily: FONT,
              letterSpacing: '.06em',
              textTransform: 'uppercase',
            }}>
              Rarevo
            </span>
          </div>
        )}
        {collapsed && (
          <div style={{ padding: '0 0 8px', textAlign: 'center' }}>
            <span style={{
              fontSize: 7,
              fontWeight: 600,
              color: '#ddd',
              fontFamily: FONT,
              letterSpacing: '.04em',
              textTransform: 'uppercase',
            }}>
              RAREVO
            </span>
          </div>
        )}
      </div>
    </div>
  );
}
