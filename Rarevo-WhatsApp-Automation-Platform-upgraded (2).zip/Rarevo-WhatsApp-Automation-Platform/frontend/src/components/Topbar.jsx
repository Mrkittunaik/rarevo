import { useState, useRef, useEffect } from 'react';
import { Info, LogOut, Settings, AlertTriangle, Building2, ChevronDown, Check, KeyRound } from 'lucide-react';
import { C, FONT } from '../constants.js';
import RarevoMark from './RarevoMark.jsx';
import { api } from '../api.js';

function BusinessSwitcher({ business, onSelect, onAll }) {
  const [open, setOpen] = useState(false);
  const [list, setList] = useState([]);
  const ref = useRef(null);
  useEffect(() => {
    const h = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  const [sq, setSq] = useState('');
  useEffect(() => {
    if (!open) return undefined;
    const t = setTimeout(() => {
      api.businesses.list({ pageSize: 30, q: sq, slim: true }).then(r => setList(r.items || [])).catch(() => {});
    }, 200);
    return () => clearTimeout(t);
  }, [open, sq]);
  return (
    <div ref={ref} style={{ position: 'relative', marginLeft: 14 }}>
      <button onClick={() => setOpen(o => !o)} style={{
        height: 36, borderRadius: 3, padding: '0 12px', background: C.headerSurface, border: `1.5px solid ${C.headerBorder}`,
        cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, color: C.headerText, fontFamily: FONT, fontSize: 13, fontWeight: 700,
        maxWidth: 280,
      }}>
        <Building2 size={15} />
        <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{business ? business.name : 'All businesses'}</span>
        <ChevronDown size={14} />
      </button>
      {open && (
        <div style={{
          position: 'absolute', top: 42, left: 0, width: 280, maxHeight: 360, overflowY: 'auto', background: C.cardBg, color: C.text,
          border: `1px solid ${C.border}`, borderRadius: 3, boxShadow: C.shadowMd, padding: 5, zIndex: 300, fontFamily: FONT,
        }}>
          <div onClick={() => { setOpen(false); onAll(); }} style={{ padding: '9px 10px', borderRadius: 3, fontSize: 13, fontWeight: 700, cursor: 'pointer' }}>
            ← All businesses
          </div>
          <input value={sq} onChange={e => setSq(e.target.value)} placeholder="Search stores…" autoFocus
            style={{ width: '100%', boxSizing: 'border-box', height: 32, margin: '4px 0', padding: '0 9px', border: `1px solid ${C.border}`, borderRadius: 3, fontFamily: FONT, fontSize: 12.5, outline: 'none' }} />
          <div style={{ height: 1, background: C.border, margin: '3px 0' }} />
          {list.length === 0 && <div style={{ padding: '8px 10px', fontSize: 12.5, color: C.textMuted }}>No matches</div>}
          {list.map(b => (
            <div key={b.id} onClick={() => { setOpen(false); onSelect(b.id); }} style={{
              padding: '8px 10px', borderRadius: 3, fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8,
              background: business?.id === b.id ? C.hover : 'transparent',
            }}>
              <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', fontWeight: 600 }}>{b.name}</span>
              {b.status !== 'active' && <span style={{ fontSize: 10.5, color: C.textMuted }}>{b.status}</span>}
              {business?.id === b.id && <Check size={14} />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Topbar({ user, onLogout, onNavigate, business, onSelectBusiness, onAllBusinesses, onChangePassword }) {
  const [userOpen, setUserOpen] = useState(false);
  const [unhealthyAccounts, setUnhealthyAccounts] = useState([]);
  const ref = useRef(null);

  useEffect(() => {
    const handleClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setUserOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Poll account health every 60s so the banner appears within a minute
  // of Meta rejecting a token. Cleared instantly when token is updated.
  useEffect(() => {
    if (!business) { setUnhealthyAccounts([]); return undefined; } // account health is per business
    let cancelled = false;
    const check = () => {
      api.whatsappAccounts.list()
        .then(accs => { if (!cancelled) setUnhealthyAccounts(accs.filter(a => a.healthStatus === 'invalid_token')); })
        .catch(() => {});
    };
    check();
    const t = setInterval(check, 60000);
    return () => { cancelled = true; clearInterval(t); };
  }, [business?.id]);

  return (
    <>
    {unhealthyAccounts.length > 0 && (
      <div
        onClick={() => onNavigate('admin-settings')}
        style={{
          background: '#A32D2D', color: '#fff', padding: '8px 16px',
          fontSize: 12, fontFamily: FONT, display: 'flex', alignItems: 'center',
          justifyContent: 'center', gap: 8, cursor: 'pointer', fontWeight: 500,
        }}
      >
        <AlertTriangle size={14} />
        <span>
          Access token expired for {unhealthyAccounts.map(a => a.displayName).join(', ')} — click to update in Settings → WhatsApp Accounts
        </span>
      </div>
    )}
    <div style={{
      height: 56,
      background: C.headerBg,
      display: 'flex',
      alignItems: 'center',
      paddingLeft: 0,
      paddingRight: 20,
      borderBottom: `1px solid ${C.headerBorder}`,
      flexShrink: 0,
      zIndex: 100,
      position: 'relative',
    }}>
      {/* Logo area — aligns with sidebar */}
      <button
        onClick={() => onNavigate('businesses')}
        style={{
          width: 224,
          flexShrink: 0,
          display: 'flex',
          alignItems: 'center',
          paddingLeft: 15,
          gap: 8,
          borderRight: `1px solid ${C.headerBorder}`,
          height: '100%',
          background: 'transparent',
          border: 'none',
          borderRightWidth: 1,
          borderRightStyle: 'solid',
          cursor: 'pointer',
          textAlign: 'left',
        }}
      >
        <RarevoMark size={34} />
        <div style={{ lineHeight: 1.1 }}>
          <div style={{
            fontSize: 16,
            fontWeight: 900,
            color: C.headerText,
            fontFamily: FONT,
            letterSpacing: '-0.01em',
            textTransform: 'uppercase',
            lineHeight: 1,
            display: 'inline-flex',
            alignItems: 'center',
            gap: 6,
          }}>
            RAREVO
            <span style={{
              background: C.primary,
              color: '#fff',
              padding: '2px 7px',
              borderRadius: 3,
              lineHeight: 1.2,
              display: 'inline-block',
            }}>WhatsApp</span>
          </div>
        </div>
      </button>

      <BusinessSwitcher business={business} onSelect={onSelectBusiness} onAll={onAllBusinesses} />

      <div style={{ flex: 1 }} />

      {/* Right controls */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {/* About Us */}
        <button
          onClick={() => onNavigate('about')}
          title="About Us"
          style={{
            width: 36,
            height: 36,
            borderRadius: 3,
            background: C.headerSurface,
            border: `1.5px solid ${C.headerBorder}`,
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Info size={16} color={C.headerText} />
        </button>

        {/* User avatar */}
        <div ref={ref} style={{ position: 'relative' }}>
          <button
            onClick={() => setUserOpen(p => !p)}
            style={{
              width: 36,
              height: 36,
              borderRadius: 3,
              background: 'linear-gradient(135deg, #534AB7, #7B72E0)',
              border: userOpen ? '2px solid #fff' : `1.5px solid ${C.headerBorder}`,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 15,
              fontWeight: 700,
              color: '#fff',
              fontFamily: FONT,
              transition: 'border .15s',
              padding: 0,
              overflow: 'hidden',
            }}
          >
            {(user.displayName || user.username).charAt(0).toUpperCase()}
          </button>

          {userOpen && (
            <div style={{
              position: 'absolute',
              top: 44,
              right: 0,
              background: C.cardBg,
              border: `1px solid ${C.border}`,
              borderRadius: 3,
              boxShadow: C.shadowMd,
              padding: 6,
              minWidth: 180,
              zIndex: 200,
            }}>
              <div style={{ padding: '8px 12px', borderBottom: `1px solid ${C.border}`, marginBottom: 4 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>
                  {user.displayName || user.username}
                </div>
                <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>
                  Owner
                </div>
              </div>
              <button
                onClick={() => { setUserOpen(false); onNavigate('admin-settings'); }}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 12px',
                  borderRadius: 3,
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: C.text,
                  fontSize: 13,
                  fontWeight: 600,
                  fontFamily: FONT,
                  marginBottom: 4,
                }}
              >
                <Settings size={14} />
                Settings
              </button>
              {onChangePassword && (
                <button
                  onClick={() => { setUserOpen(false); onChangePassword(); }}
                  style={{
                    width: '100%', display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', borderRadius: 3,
                    background: 'transparent', border: 'none', cursor: 'pointer', color: C.text, fontSize: 13, fontWeight: 600,
                    fontFamily: FONT, marginBottom: 4,
                  }}
                >
                  <KeyRound size={14} />
                  Change password
                </button>
              )}
              <button
                onClick={() => { setUserOpen(false); onLogout(); }}
                style={{
                  width: '100%',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '8px 12px',
                  borderRadius: 3,
                  background: 'transparent',
                  border: 'none',
                  cursor: 'pointer',
                  color: C.primary,
                  fontSize: 13,
                  fontWeight: 600,
                  fontFamily: FONT,
                }}
              >
                <LogOut size={14} />
                Sign out
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
    </>
  );
}
