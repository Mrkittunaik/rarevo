// Rarevo brand mark: an "R" with a message-notification dot. Inline SVG, so it
// needs no image file and stays crisp at any size. Same artwork as /favicon.svg.
export default function RarevoMark({ size = 36 }) {
  const id = `rv-g-${size}`;
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="Rarevo" style={{ flexShrink: 0, display: 'block' }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#f05252" />
          <stop offset="1" stopColor="#b91c1c" />
        </linearGradient>
      </defs>
      <rect width="64" height="64" rx="16" fill={`url(#${id})`} />
      <g fill="none" stroke="#fff" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 47V18h12a10 10 0 0 1 0 20H21" />
        <path d="M34 38l10 9" />
      </g>
      <circle cx="50.5" cy="13.5" r="4.5" fill="#fff" />
    </svg>
  );
}
