// Current-business store + request plumbing for the multi-business platform.
//
// The workspace always works inside ONE business. Its id lives in localStorage and
// is attached to every /api request as X-Business-Id (and ?businessId= for the
// SSE stream, which cannot send headers). The backend verifies the user may
// access that business and scopes every query to it.

const KEY = 'forgechat.businessId';
const EVT = 'forgechat:business';

export function getBusinessId() {
  try { return localStorage.getItem(KEY) || ''; } catch { return ''; }
}

export function setBusinessId(id) {
  try {
    if (id) localStorage.setItem(KEY, String(id)); else localStorage.removeItem(KEY);
  } catch { /* storage blocked: selection lives for this page load only */ }
  window.dispatchEvent(new CustomEvent(EVT, { detail: String(id || '') }));
}

export function onBusinessChange(fn) {
  const h = (e) => fn(e.detail);
  window.addEventListener(EVT, h);
  return () => window.removeEventListener(EVT, h);
}

// ── fetch: add X-Business-Id to same-origin /api calls ─────────────────────
// Platform-level endpoints ignore it, so it is safe to send everywhere.
if (typeof window !== 'undefined' && !window.__forgechatTenantPatched) {
  window.__forgechatTenantPatched = true;

  const origFetch = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const url = typeof input === 'string' ? input : input?.url;
    if (typeof input === 'string' && url.startsWith('/api/') && !url.startsWith('/api/auth')) {
      const bid = getBusinessId();
      if (bid) {
        const headers = new Headers(init?.headers || {});
        if (!headers.has('X-Business-Id')) headers.set('X-Business-Id', bid);
        init = { ...(init || {}), headers };
      }
    }
    const res = await origFetch(input, init);
    // The selected business vanished / access was removed: drop back to the dashboard.
    if ((res.status === 403 || res.status === 404 || res.status === 400) && typeof url === 'string' && url.startsWith('/api/')) {
      try {
        const body = await res.clone().json();
        if (body?.code === 'BUSINESS_FORBIDDEN' || body?.code === 'BUSINESS_NOT_FOUND') {
          setBusinessId('');
          window.location.hash = '#/businesses';
        }
      } catch { /* not JSON */ }
    }
    return res;
  };

  const OrigES = window.EventSource;
  if (OrigES) {
    window.EventSource = function PatchedEventSource(url, opts) {
      let u = String(url);
      const bid = getBusinessId();
      if (bid && u.startsWith('/api/') && !u.includes('businessId=')) {
        u += (u.includes('?') ? '&' : '?') + 'businessId=' + encodeURIComponent(bid);
      }
      return new OrigES(u, opts);
    };
    window.EventSource.prototype = OrigES.prototype;
    ['CONNECTING', 'OPEN', 'CLOSED'].forEach(k => { window.EventSource[k] = OrigES[k]; });
  }
}
